﻿using System;
using System.Data;
using System.IO;
using System.Web.UI;
using System.Xml;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{
    public partial class AddEditStatus : System.Web.UI.Page
	{
		GeneralFunctions ObjclsFrms = new GeneralFunctions();
		public int ResponseID
		{
			get
			{
				int ResponseID;
				int.TryParse(Request.Params["ID"], out ResponseID);

				return ResponseID;
			}
		}
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				Resourses();
                Forms();
                FillForm();

            }
		}
		public void FillForm()
		{
			try
			{
				DataTable lstDatas = ObjclsFrms.loadList("SelectStatusByID", "sp_Masters", ResponseID.ToString());
				if (lstDatas.Rows.Count > 0)
				{
					string name, code, forms,Res;
					name = lstDatas.Rows[0]["sts_Name"].ToString();
					code = lstDatas.Rows[0]["sts_Code"].ToString();
                    forms = lstDatas.Rows[0]["Forms"].ToString();
                    Res = lstDatas.Rows[0]["Resourse"].ToString();
                    string[] ar = forms.Split('-');
                    string[] aray = Res.Split('-');


                    txtcode.Enabled = false;
					txtcode.Text = code.ToString();
					txtname.Text = name.ToString();


                    for (int i = 0; i < ar.Length; i++)
                    {
                        foreach (RadComboBoxItem items in ddlForms.Items)
                        {
                            if (items.Text == ar[i])
                            {
                                items.Checked = true;
                            }
                        }
                    }

                    for (int i = 0; i < aray.Length; i++)
                    {
                        foreach (RadComboBoxItem items in ddlRes.Items)
                        {
                            if (items.Text == aray[i])
                            {
                                items.Checked = true;
                            }
                        }
                    }


                }
            }
			catch (Exception ex)
			{
				String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
				ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditStatus.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

			}
		}
		protected void Save()
		{
			try
			{

			string name, code, user, forms,Resourse;

			name = txtname.Text.ToString();
			code = txtcode.Text.ToString();
			user = UICommon.GetCurrentUserID().ToString();
            forms = GetItemFromGrid();
                Resourse = GetItemFromGrid1();



                if (ResponseID.Equals("") || ResponseID == 0)
			{


				string[] arr = { name.ToString(),  user.ToString(), forms, Resourse };
				string Value = ObjclsFrms.SaveData("sp_Masters", "InsertStatus", code.ToString(), arr);
				int res = Int32.Parse(Value.ToString());
				if (res > 0)
					{
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Status Updated Successfully');</script>", false);

                    }
                
				else
				{
					ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
				}
			}

			else
			{
				string id = ResponseID.ToString();
				string[] arr = { code.ToString(), name.ToString(), forms, user.ToString(), Resourse };
				string Value = ObjclsFrms.SaveData("sp_Masters", "UpdateStatus", id.ToString(), arr);
				int res = Int32.Parse(Value.ToString());
				if (res > 0)

				{
					ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Status Updated Successfully');</script>", false);
				}
                       
				else
				{
					ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
				}
			}

			}
			catch (Exception ex)
			{
				String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
				ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditStatus.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

			}
		}

		protected void save_Click(object sender, EventArgs e)
		{
			Save();
		}

		protected void btnOK_Click(object sender, EventArgs e)
		{
			Response.Redirect("ListStatus.aspx");
		}

		protected void lnkAdd_Click(object sender, EventArgs e)
		{
			ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
		}

		protected void lnkCancel_Click(object sender, EventArgs e)
		{
			Response.Redirect("ListStatus.aspx");
		}

		protected void txtcode_TextChanged(object sender, EventArgs e)
		{
			try
			{
				string code = this.txtcode.Text.ToString();
				DataTable lstCodeChecker = ObjclsFrms.loadList("CheckStatusCode", "sp_Masters", code);
				if (lstCodeChecker.Rows.Count > 0)
				{
					lblCodeDupli.Text = "Code Already Exist";
					lnkAdd.Enabled = false;
					lblCodeDupli.Visible = true;
				}
				else
				{
					lnkAdd.Enabled = true;
					lblCodeDupli.Visible = false;
				}
			}
			catch (Exception ex)
			{
				String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
				ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditStatus.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

			}


		}

        public void Forms()
        {
			string ID = ResponseID.ToString();
            DataTable dt = ObjclsFrms.loadList("SelectForms", "sp_Masters");
            ddlForms.DataSource = dt;
            ddlForms.DataTextField = "Name";
            ddlForms.DataValueField = "frm_ID";
            ddlForms.DataBind();

        }

        public void Resourses()
        {
           
            string ID = ResponseID.ToString();
            DataTable dt = ObjclsFrms.loadList("SelectResourseforTransaction", "sp_Transactions");
            ddlRes.DataSource = dt;
            ddlRes.DataTextField = "FirstName";
            ddlRes.DataValueField = "ID";
            ddlRes.DataBind();
        }

        public string GetItemFromGrid()
        {
            using (var sw = new StringWriter())
            {
                using (var writer = XmlWriter.Create(sw))
                {
                    writer.WriteStartDocument(true);
                    writer.WriteStartElement("r");
                    int c = 0;

                    var ColelctionMarkets = ddlForms.CheckedItems;
                    string cusIDs = "";
                    int i = 0;
                    int MarCount = ColelctionMarkets.Count;
                    if (MarCount > 0)
                    {
                        foreach (var item in ColelctionMarkets)
                        {
                            //where 1 = 1
                            createNode(item.Value, writer);
                            c++;

                        }
                    }

                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                    writer.Close();
                    if (c == 0)
                    {
                        return "";
                    }
                    else
                    {
                        string ss = sw.ToString();
                        return sw.ToString();
                    }
                }
            }
        }

        public string GetItemFromGrid1()
        {
            using (var sw = new StringWriter())
            {
                using (var writer = XmlWriter.Create(sw))
                {
                    writer.WriteStartDocument(true);
                    writer.WriteStartElement("r");
                    int c = 0;

                    var ColelctionMarkets = ddlRes.CheckedItems;
                    string cusIDs = "";
                    int i = 0;
                    int MarCount = ColelctionMarkets.Count;
                    if (MarCount > 0)
                    {
                        foreach (var item in ColelctionMarkets)
                        {
                            //where 1 = 1
                            createNode1(item.Value, writer);
                            c++;

                        }
                    }

                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                    writer.Close();
                    if (c == 0)
                    {
                        return "";
                    }
                    else
                    {
                        string ss = sw.ToString();
                        return sw.ToString();
                    }
                }
            }
        }

        private void createNode(string frm_ID, XmlWriter writer)
        {
            writer.WriteStartElement("Values");


            writer.WriteStartElement("frm_ID");
            writer.WriteString(frm_ID);
            writer.WriteEndElement();



            writer.WriteEndElement();
        }

        private void createNode1(string ID, XmlWriter writer)
        {
            writer.WriteStartElement("Values");


            writer.WriteStartElement("ID");
            writer.WriteString(ID);
            writer.WriteEndElement();



            writer.WriteEndElement();
        }

    }
}