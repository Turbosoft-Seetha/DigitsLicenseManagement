﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{
    public partial class AddEditProjectPlatformMapping : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        public int ResponseID
        {
            get
            {
                int ResponseID;
                int.TryParse(Request.Params["ID"], out ResponseID);

                return ResponseID;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Project();
                Platforms();
                FillForm();

            }
        }
        public void FillForm()
        {
            try
            {
                DataTable lstDatas = ObjclsFrms.loadList("SelectProjectPlatformMappingByID", "sp_Masters", ResponseID.ToString());
                if (lstDatas.Rows.Count > 0)
                {
                    string project, platform, status;
                    project = lstDatas.Rows[0]["project"].ToString();
                    platform = lstDatas.Rows[0]["platform"].ToString();
                    status = lstDatas.Rows[0]["Status"].ToString();
                    string[] ar = platform.Split('-');

                    ddlProject.SelectedValue = project.ToString();
                    ddlPlatform.SelectedValue = platform.ToString();
                    ddlStatus.SelectedValue = status.ToString();

                    for (int i = 0; i < ar.Length; i++)
                    {
                        foreach (RadComboBoxItem items in ddlPlatform.Items)
                        {
                            if (items.Value == ar[i])
                            {
                                items.Checked = true;
                            }
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditProjectPlatformMapping.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }
        public string platformcolumns()
        {

            using (var sw = new StringWriter())
            {
                using (var writer = XmlWriter.Create(sw))
                {
                    writer.WriteStartDocument(true);
                    writer.WriteStartElement("r");
                    int c = 0;

                    var ColelctionMarkets = ddlPlatform.CheckedItems;
                    int MarCount = ColelctionMarkets.Count;
                    if (ColelctionMarkets.Count > 0)
                    {
                        foreach (var item in ColelctionMarkets)
                        {
                            //where 1 = 1
                            createNode(item.Value, writer);
                            c++;

                        }
                    }

                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                    writer.Close();
                    if (c == 0)
                    {
                        return "";
                    }
                    else
                    {
                        string ss = sw.ToString();
                        return sw.ToString();
                    }
                }
            }

        }
        private void createNode(string prp_plf_ID, XmlWriter writer)
        {
            writer.WriteStartElement("Values");
            writer.WriteStartElement("prp_plf_ID");
            writer.WriteString(prp_plf_ID);
            writer.WriteEndElement();
            writer.WriteEndElement();
        }

        protected void Save()
        {
            try
            {


                string user, project, platform, status;

                user = UICommon.GetCurrentUserID().ToString();
                project = ddlProject.SelectedValue.ToString();
                platform = platformcolumns();
                status = ddlStatus.SelectedValue.ToString();


                if (ResponseID.Equals("") || ResponseID == 0)
                {
                    string[] arr = { project.ToString(), platform.ToString(), status.ToString() };
                    string Value = ObjclsFrms.SaveData("sp_Masters", "InsertProjectPlatform", user.ToString(), arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Mapping Saved Successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }
                }



                else
                {
                    string id = ResponseID.ToString();
                    string[] arr = { project.ToString(), platform.ToString(), status.ToString() };
                    string Value = ObjclsFrms.SaveData("sp_Masters", "UpdateProjectPlatform", id.ToString(), arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)

                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Mapping Updated Successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }
                }
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditProjectPlatformMapping.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }

        protected void save_Click(object sender, EventArgs e)
        {
            Save();
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListProjectPlatformMapping.aspx");
        }

        protected void lnkAdd_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
        }

        protected void lnkCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListProjectPlatformMapping.aspx");
        }


        public void Platforms()
        {
            try
            {
                string[] arr = { ResponseID.ToString() };
                DataTable dt = ObjclsFrms.loadList("SelectPlatformForProjectMapping", "sp_Masters");
                ddlPlatform.DataSource = dt;
                ddlPlatform.DataTextField = "plf_Name";
                ddlPlatform.DataValueField = "plf_ID";
                ddlPlatform.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditProjectPlatformMapping.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }

        public void Project()
        {
            try
            {
                string[] arr = { ResponseID.ToString() };
                DataTable dt = ObjclsFrms.loadList("SelectProjectForMapping", "sp_Masters");
                ddlProject.DataSource = dt;
                ddlProject.DataTextField = "prt_Name";
                ddlProject.DataValueField = "prt_ID";
                ddlProject.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditProjectPlatformMapping.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }
               
    }
}