﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Documents.SpreadsheetStreaming;
using Telerik.Web.UI;
using static Telerik.Web.Apoc.Render.Pdf.PdfRendererOptions;
using Telerik.Windows.Documents.Spreadsheet.Expressions.Functions;

namespace DigitsTracker.BO_Digits.en
{
    public partial class AttendenceReport : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        public int Mode
        {
            get
            {
                int Mode;
                int.TryParse(Request.Params["mode"], out Mode);
                return Mode;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Mode == 1)
                {
                    try
                    {
                        if (Session["FromDate"] != null)
                        {
                            rdfromDate.SelectedDate = DateTime.Parse(Session["FromDate"].ToString());
                        }
                        if (Session["ToDate"] != null)
                        {
                            rdendDate.SelectedDate = DateTime.Parse(Session["ToDate"].ToString());
                        }
                    }
                    catch
                    {
                        Response.Redirect("~/Login.aspx");
                    }
                }
                else
                {
                    try
                    {
                        rdfromDate.SelectedDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                        if (Session["ARTDate"] != null)
                        {
                            rdendDate.SelectedDate = DateTime.Parse(Session["ARTDate"].ToString());
                        }
                        else
                        {
                            rdendDate.SelectedDate = DateTime.Now;
                        }
                        rdendDate.MaxDate = DateTime.Now;
                    }
                    catch (Exception ex)
                    {
                        Response.Redirect("~/Login.aspx");
                    }

                    LoadData();
                    try
                    {
                        GetGridSession(grvRpt, "AR");
                        grvRpt.Rebind();
                    }
                    catch (Exception ex)
                    {
                        Response.Redirect("~/Login.aspx");
                    }
                }
            }
        }


        public void LoadData()
        {
            DataTable lstDatas = new DataTable();
            string fromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("dd-MMM-yyyy");
            string endDate = DateTime.Parse(rdendDate.SelectedDate.ToString()).ToString("dd-MMM-yyyy");

            string[] arr = { endDate.ToString() };
            lstDatas = ObjclsFrms.loadList("SelAttendenceReport", "sp_Transactions", fromDate.ToString(), arr);

            if (lstDatas.Rows.Count > 0)
            {
                grvRpt.DataSource = lstDatas;
                lblWorkingDaysCount.Text = lstDatas.Rows[0]["TotalWorkDays"].ToString();
            }
            else
            {
                grvRpt.DataSource = new DataTable();
                lblWorkingDaysCount.Text = "0";               
            }
        }



        protected void lnkDOwnload_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["ARFDate"] != null)
                {
                    string fromdate = rdfromDate.SelectedDate.ToString();
                    if (fromdate == Session["ARFDate"].ToString())
                    {
                        rdfromDate.SelectedDate = DateTime.Parse(Session["ARFDate"].ToString());
                    }
                    else
                    {
                        Session["ARFDate"] = DateTime.Parse(rdfromDate.SelectedDate.ToString());
                    }
                }
                else
                {
                    rdfromDate.SelectedDate = DateTime.Parse(DateTime.Now.ToString("MMM-yyyy"));
                    Session["ARFDate"] = DateTime.Parse(rdfromDate.SelectedDate.ToString());
                }
                rdfromDate.MaxDate = DateTime.Now;

                if (Session["ARTDate"] != null)
                {
                    string todate = rdendDate.SelectedDate.ToString();
                    if (todate == Session["ARTDate"].ToString())
                    {
                        rdendDate.SelectedDate = DateTime.Parse(Session["ARTDate"].ToString());
                    }
                    else
                    {
                        Session["ARTDate"] = DateTime.Parse(rdendDate.SelectedDate.ToString());
                    }

                }
                else
                {
                    rdendDate.SelectedDate = DateTime.Parse(rdendDate.SelectedDate.ToString());
                    Session["ARTDate"] = DateTime.Parse(rdendDate.SelectedDate.ToString());
                }
                rdendDate.MaxDate = DateTime.Now.AddDays(1);
            }
            catch (Exception)
            {
                Response.Redirect("~/Login.aspx");
            }
            LoadData();
            grvRpt.Rebind();            
        }

        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            LoadData();
        }

        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;
                SetGridSession(grd, "AR");
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AttendenceReport.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }           
        }
        public void SetGridSession(RadGrid grd, string SessionPrefix)
        {
            try
            {
                foreach (GridColumn column in grd.MasterTableView.Columns)
                {
                    if (column is GridBoundColumn boundColumn)
                    {
                        string columnName = boundColumn.UniqueName;
                        string filterValue = column.CurrentFilterValue;
                        Session[SessionPrefix + columnName] = filterValue;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }
        }
        public void GetGridSession(RadGrid grd, string SessionPrefix)
        {
            try
            {
                string filterExpression = string.Empty;
                foreach (GridColumn column in grd.MasterTableView.Columns)
                {
                    if (column is GridBoundColumn boundColumn)
                    {
                        string columnName = boundColumn.UniqueName;
                        if (Session[SessionPrefix + columnName] != null)
                        {
                            string filterValue = Session[SessionPrefix + columnName].ToString();
                            if (filterValue != "")
                            {
                                column.CurrentFilterValue = filterValue;
                                if (!string.IsNullOrEmpty(filterExpression))
                                {
                                    filterExpression += " AND ";
                                }
                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);
                            }
                        }
                    }
                }
                if (filterExpression != string.Empty)
                {
                    grvRpt.MasterTableView.FilterExpression = filterExpression;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }
        }

        protected void grvRpt_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                GridDataItem dataItem = (GridDataItem)e.Item;
                bool isHalfDay = System.Convert.ToBoolean(DataBinder.Eval(dataItem.DataItem, "HalfDay"));
                bool isPLDay = System.Convert.ToBoolean(DataBinder.Eval(dataItem.DataItem, "PLDay"));
                bool isULDay = System.Convert.ToBoolean(DataBinder.Eval(dataItem.DataItem, "ULDay"));
                bool isALDay = System.Convert.ToBoolean(DataBinder.Eval(dataItem.DataItem, "ALDay"));
                if (isHalfDay || isPLDay || isULDay || isALDay )
                {
                    dataItem.Style["background-color"] = "#FFCCCC";
                }
                else
                {
                    dataItem.Style["background-color"] = "#CCFFCC";
                }
            }
        }
    }
}