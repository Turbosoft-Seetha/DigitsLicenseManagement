﻿using ProcessExcel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{
	public partial class ListStatus : System.Web.UI.Page
	{
		GeneralFunctions ObjclsFrms = new GeneralFunctions();
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
                try
                {
                    GetGridSession(grvRpt, "LSTS");

                    grvRpt.Rebind();
                }

                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }
            }
		}
		public void LoadList()
		{
			try
			{
				DataTable lstUser = default(DataTable);
				lstUser = ObjclsFrms.loadList("ListStatus", "sp_Masters");
				grvRpt.DataSource = lstUser;
			}
			catch (Exception ex)
			{
				String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
				ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListStatus.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

			}

		}
		protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
		{
			LoadList();
		}

		protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
		{
            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "LSTS");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }
            if (e.CommandName.Equals("Edit"))
			{
				GridDataItem dataItem = e.Item as GridDataItem;
				string ID = dataItem.GetDataKeyValue("sts_ID").ToString();
				Response.Redirect("AddEditStatus.aspx?Id=" + ID);
			}
            if (e.CommandName.Equals("MyClick1"))
            {
                try
                {
                    foreach (GridDataItem di in grvRpt.MasterTableView.Items)
                    {
                        di.BackColor = Color.Transparent;
                    }

                    GridDataItem item = grvRpt.MasterTableView.Items[Convert.ToInt32(e.CommandArgument)];
                    string ID = item.GetDataKeyValue("sts_ID").ToString();
                   

                    Session["ID"] = ID.ToString();
                    
                    item.BackColor = System.Drawing.ColorTranslator.FromHtml("#eaf8fb");

                    DataTable lstUser = default(DataTable);
                    lstUser = ObjclsFrms.loadList("SelectEmployeesMapped", "sp_Masters", ID);
                    //  string resource = lstUser.Rows[0]["trk_AssignedEmp_ID"].ToString();
                    EmpGrid.DataSource = lstUser;
                    EmpGrid.DataBind();
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 3 ");

                    Employees();
                    
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);

                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 4 ");

                }
                catch (Exception ex)
                {
                    String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListStatus.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
                }

            }
        }

		protected void lnkSubCat_Click(object sender, EventArgs e)
		{
			Response.Redirect("AddEditStatus.aspx?Id=0");
		}

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            DataTable dt = default(DataTable);
            dt = ObjclsFrms.loadList("ListStatusForExcel", "sp_Masters");

            BuildExcel excel = new BuildExcel();

            byte[] output = excel.SpreadSheetProcess(dt, "Status");

            Response.ContentType = ContentType;

            Response.Headers.Remove("Content-Disposition");

            Response.AppendHeader("Content-Disposition", string.Format("attachment; filename={0}.{1}", "Status", "Xlsx"));

            Response.BinaryWrite(output);

            Response.End();
        }

        public void Employees()
        {
            try
            {
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 2 ");
                string ID = Session["ID"].ToString();
                ddlEmployee.DataSource = ObjclsFrms.loadList("ListEmployees", "sp_Masters", ID);
                ddlEmployee.DataTextField = "Name";
                ddlEmployee.DataValueField = "ID";
                ddlEmployee.DataBind();
            }
            catch (Exception ex)
            {
                // Handle exceptions if needed
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListStatus.aspx Resource()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        
        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/ListStatus.aspx");
        }

        protected void lnkSave_Click1(object sender, EventArgs e)
        {
            try
            {
                string User, Employee, ID;

                User = UICommon.GetCurrentUserID().ToString();
                Employee = ddlEmployee.SelectedValue.ToString();
                ID = Session["ID"].ToString();

                string[] arr = { Employee, User };
                string Value = ObjclsFrms.SaveData("sp_Masters", "AddEmployeeStatus", ID.ToString(), arr);
                int res = Int32.Parse(Value.ToString());
                if (res > 0)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Employee Added Successfully');</script>", false);
                }
                else if (res == 0)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                }

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListStatus.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        public void GetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                string filterExpression = string.Empty;

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        if (Session[SessionPrefix + columnName] != null)

                        {

                            string filterValue = Session[SessionPrefix + columnName].ToString();



                            if (filterValue != "")
                            {

                                column.CurrentFilterValue = filterValue;



                                if (!string.IsNullOrEmpty(filterExpression))

                                {

                                    filterExpression += " AND ";

                                }

                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);

                            }

                        }

                    }

                }

                if (filterExpression != string.Empty)

                {

                    grvRpt.MasterTableView.FilterExpression = filterExpression;

                }



            }

            catch (Exception ex)

            {



            }

        }


        public void SetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        string filterValue = column.CurrentFilterValue;

                        Session[SessionPrefix + columnName] = filterValue;

                    }

                }

            }

            catch (Exception ex)

            {




            }



        }
    }
}