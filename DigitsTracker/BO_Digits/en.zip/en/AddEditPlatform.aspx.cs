﻿using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace DigitsTracker.BO_Digits.en
{
    public partial class AddEditPlatform : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        public int ResponseID
        {
            get
            {
                int ResponseID;
                int.TryParse(Request.Params["ID"], out ResponseID);

                return ResponseID;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

                FillForm();

            }
        }
        public void FillForm()
        {
            try
            {
                DataTable lstDatas = ObjclsFrms.loadList("SelectPlatformByID", "sp_Masters", ResponseID.ToString());
                if (lstDatas.Rows.Count > 0)
                {
                    string name, code;
                    name = lstDatas.Rows[0]["plf_Name"].ToString();
                    code = lstDatas.Rows[0]["plf_Code"].ToString();
                    txtcode.Enabled = false;



                    txtcode.Text = code.ToString();
                    txtname.Text = name.ToString();

                }
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditPlatform.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }
        protected void Save()
        {
            try
            {


                string name, code, user;

                name = txtname.Text.ToString();
                code = txtcode.Text.ToString();
                user = UICommon.GetCurrentUserID().ToString();



                if (ResponseID.Equals("") || ResponseID == 0)
                {


                    string[] arr = { name.ToString(), user.ToString() };
                    string Value = ObjclsFrms.SaveData("sp_Masters", "InsertPlatform", code.ToString(), arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Platform Saved Successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }
                }

                else
                {
                    string id = ResponseID.ToString();
                    string[] arr = { code.ToString(), name.ToString() };
                    string Value = ObjclsFrms.SaveData("sp_Masters", "UpdatePlatform", id.ToString(), arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)

                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Platform Updated Successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }
                }
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditPlatform.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }

        protected void save_Click(object sender, EventArgs e)
        {
            Save();
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListPlatforms.aspx");
        }

        protected void lnkAdd_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
        }

        protected void lnkCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListPlatforms.aspx");
        }

        protected void txtcode_TextChanged(object sender, EventArgs e)
        {
            try
            {

                string code = this.txtcode.Text.ToString();
                DataTable lstCodeChecker = ObjclsFrms.loadList("CheckPlatformCode", "sp_Masters", code);
                if (lstCodeChecker.Rows.Count > 0)
                {
                    lblCodeDupli.Text = "Code Already Exist";
                    lnkAdd.Enabled = false;
                    lblCodeDupli.Visible = true;
                }
                else
                {
                    lnkAdd.Enabled = true;
                    lblCodeDupli.Visible = false;
                }

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditPlatform.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }


    }
}