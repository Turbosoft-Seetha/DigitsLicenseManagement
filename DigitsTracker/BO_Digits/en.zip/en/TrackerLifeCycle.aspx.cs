﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Pdf;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{
    public partial class TrackerLifeCycle : System.Web.UI.Page
    {
        GeneralFunctions obj = new GeneralFunctions();
        public int ResponseID
        {
            get
            {
                int ResponseID;
                int.TryParse(Request.Params["ID"], out ResponseID);

                return ResponseID;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ListData();
                HeaderData();

            }
        }


        public void HeaderData()
        {
            DataTable lstDatas = new DataTable();
            lstDatas = obj.loadList("ListTrackerLifeCycleByID", "sp_Transactions", ResponseID.ToString());
            if (lstDatas.Rows.Count > 0)
            {
                RadPanelItem rp = RadPanelBar0.Items[0];

                Label lblTracker = (Label)rp.FindControl("lblTracker");
                Label lblRes = (Label)rp.FindControl("lblRes");
                Label lblDec = (Label)rp.FindControl("lblDec");
                Label lblpage = (Label)rp.FindControl("lblpage");
                Label lblPlf = (Label)rp.FindControl("lblPlf");
                Label lblEffort = (Label)rp.FindControl("lblEffort");
                Label lblActual = (Label)rp.FindControl("lblActual");

                lblTracker.Text = lstDatas.Rows[0]["trk_TicketNumber"].ToString();
                lblRes.Text = lstDatas.Rows[0]["Resource"].ToString();
                lblDec.Text = lstDatas.Rows[0]["trk_Desc"].ToString();
                lblpage.Text = lstDatas.Rows[0]["trk_Page"].ToString();
                lblPlf.Text = lstDatas.Rows[0]["plf_Name"].ToString();
                lblEffort.Text = lstDatas.Rows[0]["trk_ExpectedEffort"].ToString();
                lblActual.Text = lstDatas.Rows[0]["trk_ActualEffort"].ToString();

            }
        }

        public void ListData()
        {
            try
            {
                DataTable lstUser = obj.loadList("ListTrackerLifeCycle", "sp_Transactions", ResponseID.ToString());                
                rptTimeline.DataSource = lstUser;
                rptTimeline.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                obj.LogMessageToFile(UICommon.GetLogFileName(), "TrackerLifeCycle.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }





    }
}