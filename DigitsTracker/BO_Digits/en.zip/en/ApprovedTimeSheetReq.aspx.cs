﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{
    public partial class ApprovedTimeSheetReq : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //rdfromDate.SelectedDate = DateTime.Now;
                //rdendDate.SelectedDate = DateTime.Now;

                try
                {
                    if (Session["ATSFDate"] != null)
                    {

                        rdfromDate.SelectedDate = DateTime.Parse(Session["ATSFDate"].ToString());
                    }
                    else
                    {
                        rdfromDate.SelectedDate = DateTime.Now.AddDays(-30);
                    }


                    if (Session["ATSTDate"] != null)
                    {

                        rdendDate.SelectedDate = DateTime.Parse(Session["ATSTDate"].ToString());
                    }
                    else
                    {
                        rdendDate.SelectedDate = DateTime.Now;

                    }
                    rdendDate.MaxDate = DateTime.Now;
                }
                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }


                try
                {
                    GetGridSession(grvRpt, "ATSR");

                    grvRpt.Rebind();
                }

                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }
            }
        }

        public void LoadList()
        {
            try
            {
                string FromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                string EndDate = DateTime.Parse(rdendDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                string User = UICommon.GetCurrentUserID().ToString();

                DataTable lstUser = default(DataTable);
                string[] arr = { EndDate, User };
                lstUser = ObjclsFrms.loadList("SelectTimeSheetRequestApproval", "sp_Transactions", FromDate, arr);
                grvRpt.DataSource = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "TimeSheet.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }

        protected void Filter_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["ATSFDate"] != null)
                {
                    string fromdate = rdfromDate.SelectedDate.ToString();
                    if (fromdate == Session["ATSFDate"].ToString())
                    {
                        rdfromDate.SelectedDate = DateTime.Parse(Session["ATSFDate"].ToString());
                    }
                    else
                    {
                        Session["ATSFDate"] = DateTime.Parse(rdfromDate.SelectedDate.ToString());
                    }
                }
                else
                {

                    Session["ATSFDate"] = DateTime.Parse(rdfromDate.SelectedDate.ToString());

                }
                rdfromDate.MaxDate = DateTime.Now;

                if (Session["ATSTDate"] != null)
                {
                    string todate = rdendDate.SelectedDate.ToString();
                    if (todate == Session["ATSTDate"].ToString())
                    {
                        rdendDate.SelectedDate = DateTime.Parse(Session["ATSTDate"].ToString());
                    }
                    else
                    {
                        Session["ATSTDate"] = DateTime.Parse(rdendDate.SelectedDate.ToString());
                    }

                }
                else
                {
                    rdendDate.SelectedDate = DateTime.Parse(rdendDate.SelectedDate.ToString());
                    Session["ATSTDate"] = DateTime.Parse(rdendDate.SelectedDate.ToString());
                }
                rdendDate.MaxDate = DateTime.Now.AddDays(1);
            }
            catch (Exception)
            {
                Response.Redirect("~/SignIn.aspx");
            }


            LoadList();
            grvRpt.Rebind();
        }

        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            LoadList();
        }

        public void Save()
        {
            string ID = ViewState["ID"].ToString();
            string Status = ViewState["Status"].ToString();
            string user = UICommon.GetCurrentUserID().ToString();
            string remark = txtRemarks.InnerText.ToString();
            DataTable lstData = new DataTable();
            string[] arr = { user, Status, remark };
            string resp = ObjclsFrms.SaveData("sp_Transactions", "UpdateTimeSheetRequest", ID.ToString(), arr);
            int res = Int32.Parse(resp);

            if (res > 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>successModal('Time Sheet request updated successfully');</script>", false);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>failedModal('Something went wrong, please try again later.');</script>", false);
            }


        }

        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "ATSR");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }

          
            if (e.CommandName.Equals("Reject"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("tst_ID").ToString();
                ViewState["Status"] = "R";
                ViewState["ID"] = ID;
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
            }
        }

        protected void save_Click(object sender, EventArgs e)
        {
            Save();
        }


        public void SetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        string filterValue = column.CurrentFilterValue;

                        Session[SessionPrefix + columnName] = filterValue;

                    }

                }

            }

            catch (Exception ex)

            {




            }



        }
        public void GetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                string filterExpression = string.Empty;

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        if (Session[SessionPrefix + columnName] != null)

                        {

                            string filterValue = Session[SessionPrefix + columnName].ToString();



                            if (filterValue != "")
                            {

                                column.CurrentFilterValue = filterValue;



                                if (!string.IsNullOrEmpty(filterExpression))

                                {

                                    filterExpression += " AND ";

                                }

                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);

                            }

                        }

                    }

                }

                if (filterExpression != string.Empty)

                {

                    grvRpt.MasterTableView.FilterExpression = filterExpression;

                }



            }

            catch (Exception ex)

            {



            }

        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("ApprovedTimeSheetReq.aspx");
        }
    }
}