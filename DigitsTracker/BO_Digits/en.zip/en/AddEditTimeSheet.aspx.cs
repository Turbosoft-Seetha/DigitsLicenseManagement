﻿using GoogleApi.Entities.Common.Enums;
using Org.BouncyCastle.Utilities.Zlib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Policy;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DigitsTracker.BO_Digits.en
{
    public partial class AddEditTimeSheet : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        public int ResponseID
        {
            get
            {
                int ResponseID;
                int.TryParse(Request.Params["Id"], out ResponseID);

                return ResponseID;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ddlDelDate.MinDate = DateTime.Now.AddDays(-4);
                ddlDelDate.MaxDate = DateTime.Now;

                Project();
            }
        }       
        public void Project()
        {
            try
            {
                ddlProject.DataSource = ObjclsFrms.loadList("SelProjectForTimeSheetDropdown", "sp_Transactions");
                ddlProject.DataTextField = "prt_Name";
                ddlProject.DataValueField = "prt_ID";
                ddlProject.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx Project()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }
        protected void lnkCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/TimeSheet.aspx");
        }

        protected void lnkAdd_Click(object sender, EventArgs e)
        {
            Save();
        }
        protected void Save()
        {
            try
            {
                string CreatedBy, Desc, Project, Effort,DelDate, Status;

                CreatedBy = UICommon.GetCurrentUserID().ToString();
                Desc = txtDesc.Text.ToString();
                Project = ddlProject.SelectedValue.ToString();
                string ProjectName = ddlProject.SelectedItem.Text.ToString();
                Effort = txtEffort.Text.ToString();
                DelDate = DateTime.Parse(ddlDelDate.SelectedDate.ToString()).ToString("dd-MMM-yyyy");
                Status = "Y";
                string TodaysDate = DateTime.Parse(DateTime.Now.ToString()).ToString("dd-MMM-yyyy"); 
                string YesterdaysDate = DateTime.Parse(DateTime.Now.AddDays(-1).ToString()).ToString("dd-MMM-yyyy"); 

                if (DelDate == TodaysDate)
                {
                    if (ResponseID.Equals("") || ResponseID == 0)
                    {
                        string[] arr = { Project, Effort, DelDate, CreatedBy, Status };
                        string Value = ObjclsFrms.SaveData("sp_Transactions", "InsTimeSheet", Desc, arr);
                        int res = Int32.Parse(Value.ToString());
                        if (res > 0)
                        {
                            string script = "<script type='text/javascript'>SuccessModal('" + Effort + "','" + Desc + "','" + ProjectName + "','" + DelDate + "');</script>";
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", script, false);
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                        }


                    }
                }
                else if(DelDate == YesterdaysDate)
                {
                    if (ResponseID.Equals("") || ResponseID == 0)
                    {
                        string[] arr = { Project, Effort, DelDate, CreatedBy, Status };
                        string Value = ObjclsFrms.SaveData("sp_Transactions", "InsTimeSheet", Desc, arr);
                        int res = Int32.Parse(Value.ToString());
                        if (res > 0)
                        {
                            string script = "<script type='text/javascript'>SuccessModal('" + Effort + "','" + Desc + "','" + ProjectName + "','" + DelDate + "');</script>";
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", script, false);
                        }

                        else
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                        }
                    }
                }
                else
                {
                    if (ResponseID.Equals("") || ResponseID == 0)
                    {
                        Status = "N";
                        string[] arr = { Project, Effort, DelDate, CreatedBy, Status };
                        string Value = ObjclsFrms.SaveData("sp_Transactions", "InsTimeSheet", Desc, arr);
                        int res = Int32.Parse(Value.ToString());
                        if (res > 0)
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Time Sheet Request Sent for Approval');</script>", false);
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                        }
                    }
                }

                

                
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx Save()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }

        protected void save_Click(object sender, EventArgs e)
        {
            Save();
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/TimeSheet.aspx");
        }

        protected void ddlDelDate_SelectedDateChanged(object sender, Telerik.Web.UI.Calendar.SelectedDateChangedEventArgs e)
        {
            string user = UICommon.GetCurrentUserID().ToString();
           string  date = DateTime.Parse(ddlDelDate.SelectedDate.ToString()).ToString("dd-MMM-yyyy");
            DataTable lstUser = default(DataTable);
            string[] arr = { date };
            lstUser = ObjclsFrms.loadList("SelectTotalEffortForTimesheet", "sp_Transactions", user,arr);
            if (lstUser.Rows.Count > 0)
            {
                // Access the value from the first row, first column
                ddleffort.Text = lstUser.Rows[0][0].ToString();
                plhFilter.Visible = true;
            }
        }
    }
}