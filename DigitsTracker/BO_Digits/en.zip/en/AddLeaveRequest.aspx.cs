﻿using Org.BouncyCastle.Utilities.Zlib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{

    public partial class AddLeaveRequest : System.Web.UI.Page

    {
        GeneralFunctions obj = new GeneralFunctions();

        public int ResponseID
        {
            get
            {
                int ResponseID;
                int.TryParse(Request.Params["Id"], out ResponseID);

                return ResponseID;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ddlFromDate.MinDate = DateTime.Now;

               // DateTime selectedFromDate = ddlFromDate.SelectedDate ?? DateTime.Now.AddDays(2);
               // ddlToDate.MinDate = selectedFromDate;

                ddlToDate.MinDate = DateTime.Now;

            }
        }

        protected void lnkCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/ListLeaveReq.aspx");

        }

        protected void lnkAdd_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);

        }


        protected void Save()
        {
            try
            {


                string  user, FromDate,ToDate, date, Type, Reason;

                user = UICommon.GetCurrentUserID().ToString();
                FromDate= DateTime.Parse(ddlFromDate.SelectedDate.ToString()).ToString("dd-MMM-yyyy"); 
                ToDate= DateTime.Parse(ddlToDate.SelectedDate.ToString()).ToString("dd-MMM-yyyy");               
               // Type = ddlType.SelectedValue.ToString();
                Reason = txtResn.Text.ToString();



                if (ResponseID.Equals("") || ResponseID == 0)
                {


                    string[] arr = { Reason.ToString() ,FromDate.ToString(), ToDate.ToString()};
                    string Value = obj.SaveData("sp_Masters", "InsertLeaveRequest", user.ToString(), arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Leave Requested Successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }
                }

              
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                obj.LogMessageToFile(UICommon.GetLogFileName(), "AddLeaveRequest.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/AddLeaveRequest.aspx");
        }

        protected void save_Click(object sender, EventArgs e)
        {
            Save();
        }


        public void LoadList()
        {
            try
            {
                string User = UICommon.GetCurrentUserID().ToString();

              
                DataTable lstUser = default(DataTable);
                lstUser = obj.loadList("ListApprovedLeaveRequest", "sp_Masters", User);
                grvRpt.DataSource = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                obj.LogMessageToFile(UICommon.GetLogFileName(), "ApprovedLeaveReq.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }



        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            LoadList();
        }

        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {

        }

        protected void grvRpt_ItemDataBound(object sender, Telerik.Web.UI.GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                GridDataItem item = (GridDataItem)e.Item;
                string status = item["Status"].Text;

                // Check the value of the "Status" column and set the text color accordingly
                switch (status)
                {
                    case "Approved":
                        item["Status"].ForeColor = System.Drawing.Color.Green;
                        break;
                    case "Pending":
                        item["Status"].ForeColor = System.Drawing.Color.DarkOrange;
                        break;
                    case "Reject":
                        item["Status"].ForeColor = System.Drawing.Color.Red;
                        break;
                        // Add additional cases as needed
                }
            }
        }
    }
}