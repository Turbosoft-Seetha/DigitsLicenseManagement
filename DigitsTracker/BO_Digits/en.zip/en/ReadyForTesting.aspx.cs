﻿using GoogleApi.Entities.Search.Video.Common;
using ProcessExcel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.Analytics;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{
    public partial class ReadyForTesting : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Project();
                string proID = pro();
                string project = " epl_prt_ID in (" + proID + ")";
                Platforms(project);
                string plfID = plf();
                string platform = " and epl_plf_ID in (" + plfID + ")";
                Resourses(project, platform);

                try
                {
                    if (Session["RTFDate"] != null)
                    {

                        rdfromDate.SelectedDate = DateTime.Parse(Session["RTFDate"].ToString());
                    }
                    else
                    {
                        rdfromDate.SelectedDate = DateTime.Now;

                    }

                }
                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }

                try
                {
                    // Handle selected project IDs
                    if (Session["RTSelectedProjectID"] != null)
                    {
                        string projectID = Session["RTSelectedProjectID"].ToString();
                        foreach (RadComboBoxItem item in rdproject.Items)
                        {
                            if (projectID.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                            else
                            {
                                item.Checked = false; // Uncheck if not in session
                            }
                        }

                        project = " epl_prt_ID in (" + projectID + ")";
                        Platforms(project);
                    }
                    else
                    {
                        string pID = pro();
                        string routeCondition = " trk_prt_ID in (" + pID + ")";
                    }
                                      
                    if (Session["RTSelectedPlatformID"] != null)
                    {
                        string platformID = Session["RTSelectedPlatformID"].ToString();
                        foreach (RadComboBoxItem item in rdPlatform.Items)
                        {
                            if (platformID.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                            else
                            {
                                item.Checked = false; 
                            }
                        }

                        platform = " and epl_plf_ID in (" + platformID + ")";
                        Resourses(project, platform);
                    }
                    else
                    {
                        string pID = pro();
                        string routeCondition = " trk_plf_ID in (" + pID + ")";
                    }

                    if (Session["RTSelectedResources"] != null)
                    {
                        string[] selectedResourceIDs = Session["RTSelectedResources"].ToString().Split(',');
                        foreach (RadComboBoxItem item in rdResourse.Items)
                        {
                            if (selectedResourceIDs.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                            else
                            {
                                item.Checked = false;
                            }
                        }
                    }
                    else
                    {
                        string res = Res();
                        string routeCondition = " trk_AssignedEmp_ID in (" + res + ")";
                    }
                }
                catch (Exception ex)
                {
                    
                }

                try
                {
                    GetGridSession(grvRpt, "RT");
                    grvRpt.Rebind();
                }
                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }
            }
        }

        public void ListData()
        {
            try
            {
                string mainCondition = "";
                mainCondition = mainConditions();
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("SelectReadyForTesting", "sp_Transactions", mainCondition);
                grvRpt.DataSource = lstUser;
                Session["lstTracker"] = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ReadyForTesting.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }
        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            ListData();
        }

        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "RT");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }

            if (e.CommandName.Equals("MyClick1"))
            {
                string user = UICommon.GetCurrentUserID().ToString();
                DataTable dtUserStatus = ObjclsFrms.loadList("SelectUserRoles", "sp_User", user);

                if (dtUserStatus.Rows[0]["LoweredRoleName"].ToString() == "admin")

                {

                    try
                    {

                        foreach (GridDataItem di in grvRpt.MasterTableView.Items)
                        {
                            di.BackColor = Color.Transparent;
                        }

                        GridDataItem item = grvRpt.MasterTableView.Items[Convert.ToInt32(e.CommandArgument)];
                        string ID = item.GetDataKeyValue("trk_ID").ToString();
                        string Status = item["Status"].Text.ToString();
                        Session["ID"] = ID.ToString();
                      

                        Session["Status"] = Status.ToString();

                        //Status();
                        HeaderData();
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);

                    }
                    catch (Exception ex)
                    {
                        String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                        ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ReadyForTesting.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
                    }


                }

                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>RejectEdit();</script>", false);
                }

            }

            if (e.CommandName.Equals("LifeCycle"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("trk_ID").ToString();
                Response.Redirect("ReadyForTestingLifeCycle.aspx?Id=" + ID);
            }
        }
        public void HeaderData()
        {
            string Id = Session["ID"].ToString();
            DataTable lstDatas = new DataTable();
            lstDatas = ObjclsFrms.loadList("ListTrackerLifeCycleByID", "sp_Transactions", Id);
            if (lstDatas.Rows.Count > 0)
            {
                RadPanelItem rp = RadPanelBar0.Items[0];

                Label lblTracker = (Label)rp.FindControl("lblTracker");
                Label lblRes = (Label)rp.FindControl("lblRes");
                Label lblDec = (Label)rp.FindControl("lblDec");
                Label lblpage = (Label)rp.FindControl("lblpage");
                Label lblPlf = (Label)rp.FindControl("lblPlf");
                Label lblEffort = (Label)rp.FindControl("lblEffort");
                Label lblActual = (Label)rp.FindControl("lblActual");




                lblTracker.Text = lstDatas.Rows[0]["trk_TicketNumber"].ToString();
                lblRes.Text = lstDatas.Rows[0]["Resource"].ToString();
                lblDec.Text = lstDatas.Rows[0]["trk_Desc"].ToString();
                lblpage.Text = lstDatas.Rows[0]["trk_Page"].ToString();
                lblPlf.Text = lstDatas.Rows[0]["plf_Name"].ToString();
                lblEffort.Text = lstDatas.Rows[0]["trk_ExpectedEffort"].ToString();
                lblActual.Text = lstDatas.Rows[0]["trk_ActualEffort"].ToString();


            }
        }       

        protected void lnkFilter_Click(object sender, EventArgs e)
        {
            try
            {
                string projectID = pro();
                Session["RTSelectedProjectID"] = projectID;
                string platformID = plf();
                Session["RTSelectedPlatformID"] = platformID;
                string selectedResources = Res();
                Session["RTSelectedResources"] = selectedResources;              
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");

            }
            ListData();
            grvRpt.Rebind();
        }

        public void Platforms(string project)
        {
            rdPlatform.DataSource = ObjclsFrms.loadList("SelectPlatformforTransaction", "sp_Transactions", project);
            rdPlatform.DataTextField = "plf_Name";
            rdPlatform.DataValueField = "epl_plf_ID";
            rdPlatform.DataBind();
        }

        public void Resourses( string project, string platform)
        {
            string[] arr = { platform.ToString() }; 
            rdResourse.DataSource = ObjclsFrms.loadList("SelectResourseforTransaction", "sp_Transactions", project,arr);
            rdResourse.DataTextField = "FirstName";
            rdResourse.DataValueField = "ID";
            rdResourse.DataBind();
        }
              

        public string mainConditions()
        {

            string Resourse = Res();
            string Project = pro();
            string Platform = plf();
            string mainCondition = "";
            string ResourseCondition = "";
            string ProjectCondition = "";
            string PlatformCondition = "";
            string dateCondition = "";
            try
            {
                string fromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");

                dateCondition = " and (  cast(trk_ActualDelDate as date) <= cast('" + fromDate + "' as date))";

                if (Resourse.Equals("0"))
                {
                    ResourseCondition = "";
                }
                else
                {
                    ResourseCondition = " and trk_AssignedEmp_ID in (" + Resourse + ")";
                }


                if (Project.Equals("0"))
                {
                    ProjectCondition = "";
                }
                else
                {
                    ProjectCondition = " and trk_prt_ID in (" + Project + ")";
                }

                if (Platform.Equals("0"))
                {
                    PlatformCondition = "";
                }
                else
                {
                    PlatformCondition = " and trk_plf_ID in (" + Platform + ")";
                }

            }
            catch (Exception ex)
            {

            }
            mainCondition += ResourseCondition;
            mainCondition += ProjectCondition;
            mainCondition += PlatformCondition;
            mainCondition += dateCondition;
            return mainCondition;
        }

        public string Res()
        {
            var CollectionMarket = rdResourse.CheckedItems;
            string ResID = "";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        ResID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        ResID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        ResID += item.Value;
                    }
                    j++;
                }
                return ResID;
            }
            else
            {
                return "trk_AssignedEmp_ID";
            }

        }

        protected void XLdownload_Click(object sender, ImageClickEventArgs e)
        {
            string mainCondition = "";
            mainCondition = mainConditions();
            DataTable dt = default(DataTable);
            dt = ObjclsFrms.loadList("ListReadyForTestingForExcel", "sp_Transactions", mainCondition);

            BuildExcel excel = new BuildExcel();

            byte[] output = excel.SpreadSheetProcess(dt, "ReadyForTesting");

            Response.ContentType = ContentType;

            Response.Headers.Remove("Content-Disposition");

            Response.AppendHeader("Content-Disposition", string.Format("attachment; filename={0}.{1}", "ReadyForTesting", "Xlsx"));

            Response.BinaryWrite(output);

            Response.End();
        }

        protected void lnkSave_Click(object sender, EventArgs e)
        {
          


            try
            {
                string User, Status, ID,Remark,PrvStatus;

                // Attempt to find the GridDataItem by traversing up the control tree

                User = UICommon.GetCurrentUserID().ToString();
                Status = rblStatus.SelectedValue;

                PrvStatus = Session["Status"].ToString();
                ID = Session["ID"].ToString();
                Remark = txtRemarks.InnerText.ToString();
                string[] arr = { Status, Remark, PrvStatus };
                string lstUser = ObjclsFrms.SaveData("sp_Transactions", "UpdateStatus", ID.ToString(), arr);
                int res = Int32.Parse(lstUser.ToString());

                if (res > 0)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>showSuccessToast('Status Updated Successfully');  window.location.href = 'ReadyForTesting.aspx';</script>", false);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                }
            
               
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ReadyForTesting.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

     
        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/ReadyForTesting.aspx");
        }

        public void GetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                string filterExpression = string.Empty;

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        if (Session[SessionPrefix + columnName] != null)

                        {

                            string filterValue = Session[SessionPrefix + columnName].ToString();



                            if (filterValue != "")
                            {

                                column.CurrentFilterValue = filterValue;



                                if (!string.IsNullOrEmpty(filterExpression))

                                {

                                    filterExpression += " AND ";

                                }

                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);

                            }

                        }

                    }

                }

                if (filterExpression != string.Empty)

                {

                    grvRpt.MasterTableView.FilterExpression = filterExpression;

                }
            }

            catch (Exception ex)

            {



            }

        }


        public void SetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        string filterValue = column.CurrentFilterValue;

                        Session[SessionPrefix + columnName] = filterValue;

                    }

                }

            }

            catch (Exception ex)

            {




            }



        }

        protected void grvRpt_ItemDataBound(object sender, GridItemEventArgs e)
        {

            try
            {

                if (e.Item is GridDataItem)
                {
                    GridDataItem item = (GridDataItem)e.Item;

                    string actualEffortText = item["trk_ActualEffort"].Text;
                    string expectedEffortText = item["trk_ExpectedEffort"].Text;

                    decimal actualEffort;
                    decimal expectedEffort;
                    if (!decimal.TryParse(actualEffortText, out actualEffort))
                    {                        
                        Console.WriteLine("Error parsing Actual Effort: " + actualEffortText);
                        return; 
                    }

                    if (!decimal.TryParse(expectedEffortText, out expectedEffort))
                    {
                        Console.WriteLine("Error parsing Expected Effort: " + expectedEffortText);
                        return; 
                    }

                    if (actualEffort > expectedEffort)
                    {
                        item.Style["background-color"] = "#FFCCCC"; // Red color
                    }
                    else if (actualEffort < expectedEffort)
                    {
                        item.Style["background-color"] = "#CCFFCC"; // Green color
                    }
                    else
                    {
                        item.Style["background-color"] = "#CCCCFF"; // Blue color
                    }
                }
            }
            catch (Exception ex)

            {




            }

        }

        protected void TrackerReset_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
               
                ClearGridFilterConditions(grvRpt, "RT");               
                foreach (RadComboBoxItem item in rdproject.Items)
                {
                    item.Checked = false;
                }
                foreach (RadComboBoxItem item in rdPlatform.Items)
                {
                    item.Checked = false;
                }
                foreach (RadComboBoxItem item in rdResourse.Items)
                {
                    item.Checked = false;
                }

                string mainCondition = mainConditions();
                DataTable lstUser = ObjclsFrms.loadList("SelectReadyForTesting", "sp_Transactions", mainCondition);

                grvRpt.DataSource = lstUser;
                grvRpt.DataBind();

                Session["lstTracker"] = lstUser;
            }
            catch (Exception ex)
            {
                string errorMessage = ex.Message;
                if (ex.InnerException != null)
                {
                    errorMessage += " Inner Exception: " + ex.InnerException.Message;
                }
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListTracker.aspx", "TrackerReset_Click Error: " + errorMessage);
          
            }
        }




        private void ClearGridFilterConditions(RadGrid grd, string SessionPrefix)
        {
            try
            {
                foreach (GridColumn column in grd.MasterTableView.Columns)
                {
                    if (column is GridBoundColumn boundColumn)
                    {
                        string columnName = boundColumn.UniqueName;
                        column.CurrentFilterValue = string.Empty;

                        Session[SessionPrefix + columnName] = null;
                    }
                }
                grd.MasterTableView.FilterExpression = string.Empty;
            }
            catch (Exception ex)
            {

            }
        }


        public void Project()
        {
            rdproject.DataSource = ObjclsFrms.loadList("SelectProjectforTransaction", "sp_Transactions");
            rdproject.DataTextField = "project";
            rdproject.DataValueField = "prt_ID";
            rdproject.DataBind();
        }


        public string pro()
        {
            var CollectionMarket = rdproject.CheckedItems;
            string ProID = " ";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        ProID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        ProID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        ProID += item.Value;
                    }
                    j++;
                }
                return ProID;
            }
            else
            {
                return "trk_prt_ID";
            }

        }

        public string plf()
        {
            var CollectionMarket = rdPlatform.CheckedItems;
            string plfID = " ";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        plfID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        plfID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        plfID += item.Value;
                    }
                    j++;
                }
                return plfID;
            }
            else
            {
                return "trk_plf_ID";
            }

        }

        protected void rdproject_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            string proID  = pro();
            if (proID.Equals("epl_prt_ID"))
            {
                proID = "0";
            }
            string project = " epl_prt_ID in (" + proID + ")";
            Platforms(project);            
        }

        protected void rdPlatform_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            string proID = pro();
            if (proID.Equals("epl_prt_ID"))
            {
                proID = "0";
            }
            string project = " epl_prt_ID in (" + proID + ")";
            string plfID = plf();
            if (plfID.Equals("epl_plf_ID"))
            {
                plfID = "0";
            }
            string platform = " and epl_plf_ID in (" + plfID + ")";
            Resourses(project,platform);
        }
    }
}