﻿using System;
using System.Data;
using System.Web.UI;
using Telerik.Web.UI;
using ProcessExcel;

namespace DigitsTracker.BO_Digits.en
{
    public partial class ListCustomer : System.Web.UI.Page
	{
		GeneralFunctions ObjclsFrms = new GeneralFunctions();
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
                try
                {
                    GetGridSession(grvRpt, "LC");

                    grvRpt.Rebind();
                }

                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }

            }
        }
		public void LoadList()
		{
			try
			{
				DataTable lstUser = default(DataTable);
				lstUser = ObjclsFrms.loadList("ListCustomer", "sp_Masters");
				grvRpt.DataSource = lstUser;
				ViewState["lstUser"] = lstUser;
			}
			catch (Exception ex)
			{
				String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
				ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListCustomer.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

			}

		}
		protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
		{
			LoadList();
		}

		protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
		{

            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "LC");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }
            if (e.CommandName.Equals("Edit"))
			{
				GridDataItem dataItem = e.Item as GridDataItem;
				string ID = dataItem.GetDataKeyValue("cus_ID").ToString();
				Response.Redirect("AddEditCustomer.aspx?Id=" + ID);
			}
		}



		protected void lnkSubCat_Click(object sender, EventArgs e)
		{
			Response.Redirect("AddEditCustomer.aspx?Id=0");
		}
				
        
        protected void Excel_Click(object sender, ImageClickEventArgs e)
        {
            DataTable dt = default(DataTable);
            dt = ObjclsFrms.loadList("ListCustomerForExcel", "sp_Masters");

            BuildExcel excel = new BuildExcel();

            byte[] output = excel.SpreadSheetProcess(dt, "Customers");

            Response.ContentType = ContentType;

            Response.Headers.Remove("Content-Disposition");

            Response.AppendHeader("Content-Disposition", string.Format("attachment; filename={0}.{1}", "Customers", "Xlsx"));

            Response.BinaryWrite(output);

            Response.End();
        }


        public void GetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                string filterExpression = string.Empty;

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        if (Session[SessionPrefix + columnName] != null)

                        {

                            string filterValue = Session[SessionPrefix + columnName].ToString();



                            if (filterValue != "")
                            {

                                column.CurrentFilterValue = filterValue;



                                if (!string.IsNullOrEmpty(filterExpression))

                                {

                                    filterExpression += " AND ";

                                }

                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);

                            }

                        }

                    }

                }

                if (filterExpression != string.Empty)

                {

                    grvRpt.MasterTableView.FilterExpression = filterExpression;

                }



            }

            catch (Exception ex)

            {



            }

        }


        public void SetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        string filterValue = column.CurrentFilterValue;

                        Session[SessionPrefix + columnName] = filterValue;

                    }

                }

            }

            catch (Exception ex)

            {




            }



        }
    }
}