﻿using ProcessExcel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{
    public partial class HoldPoints : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Project();
                string proID = pro();
                string project = " epl_prt_ID in (" + proID + ")";
                Platforms(project);
                string plfID = plf();
                string platform = " and epl_plf_ID in (" + plfID + ")";
                Resourses(project, platform);

                try
                {
                    if (Session["SelectedProid"] != null)
                    {
                        string projectID = Session["SelectedProid"].ToString();
                        foreach (RadComboBoxItem item in rdproject.Items)
                        {
                            if (projectID.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                        }

                        project = " and epl_prt_ID in (" + projectID + ")";
                        Platforms(project);
                    }
                    else
                    {
                        string pID = pro();
                        string routeCondition = " trk_prt_ID in (" + pID + ")";
                    }

                    if (Session["SelectedPlatID"] != null)
                    {
                        string projectID = Session["SelectedProid"].ToString();
                        foreach (RadComboBoxItem item in rdproject.Items)
                        {
                            if (projectID.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                        }

                        project = " epl_prt_ID in (" + projectID + ")";
                        Platforms(project);

                        string platformID = Session["SelectedPlatID"].ToString();
                        foreach (RadComboBoxItem item in rdPlatform.Items)
                        {
                            if (platformID.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                        }

                        platform = " and epl_plf_ID in (" + platformID + ")";
                        Resourses(project, platform);
                    }
                    else
                    {
                        string pID = pro();
                        string routeCondition = " trk_plf_ID in (" + pID + ")";
                    }

                    if (Session["SelectedResID"] != null)
                    {
                        string[] selectedResourceIDs = Session["SelectedResID"].ToString().Split(',');
                        foreach (RadComboBoxItem item in rdResourse.Items)
                        {
                            if (selectedResourceIDs.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                        }
                    }

                    else
                    {
                        string res = Res();
                        string routeCondition = " trk_AssignedEmp_ID in (" + res + ")";
                    }
                    //invType

                }
                catch (Exception ex)
                {

                }
                try
                {
                    GetGridSession(grvRpt, "HP");

                    grvRpt.Rebind();
                }

                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");

                }
            }
        }
        public void ListData()
        {
            try
            {
                string mainCondition = "";
                mainCondition = mainConditions();
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("SelectHoldPoints", "sp_Transactions", mainCondition);
                grvRpt.DataSource = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "HoldPoints.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }
        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            ListData();
        }

        public void SetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        string filterValue = column.CurrentFilterValue;

                        Session[SessionPrefix + columnName] = filterValue;

                    }

                }

            }

            catch (Exception ex)

            {




            }



        }
        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "HP");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");

            }
            if (e.CommandName.Equals("MyClick1"))
            {
                try
                {
                    foreach (GridDataItem di in grvRpt.MasterTableView.Items)
                    {
                        di.BackColor = Color.Transparent;
                    }

                    GridDataItem item = grvRpt.MasterTableView.Items[Convert.ToInt32(e.CommandArgument)];
                    string ID = item.GetDataKeyValue("trk_ID").ToString();
                    string prtID = item["trk_prt_ID"].Text.ToString();
                    string plfID = item["trk_plf_ID"].Text.ToString();
                    string res = item["Resource"].Text.ToString();
                    string prvStatus = item["trk_PreviousStatus"].Text.ToString();

                    if (prvStatus == "Open")
                    {

                        Session["ID"] = ID.ToString();
                        Session["ProjectID"] = prtID.ToString();
                        Session["PlatformID"] = plfID.ToString();
                        item.BackColor = System.Drawing.ColorTranslator.FromHtml("#eaf8fb");

                        DataTable lstUser = default(DataTable);
                        lstUser = ObjclsFrms.loadList("SelectTrackerPointByID", "sp_Transactions", ID);
                        string resource = lstUser.Rows[0]["trk_AssignedEmp_ID"].ToString();
                        ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 3 ");

                        Resource();
                        Statuses();
                        HeaderData();

                        ddlResource.SelectedValue = resource;


                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);

                        ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 4 ");
                    }
                    else
                    {
                        Session["ID"] = ID.ToString();
                        Session["ProjectID"] = prtID.ToString();
                        Session["PlatformID"] = plfID.ToString();
                        item.BackColor = System.Drawing.ColorTranslator.FromHtml("#eaf8fb");

                        DataTable lstUser = default(DataTable);
                        lstUser = ObjclsFrms.loadList("SelectTrackerPointByID", "sp_Transactions", ID);
                        string resource = lstUser.Rows[0]["trk_AssignedEmp_ID"].ToString();
                        ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 3 ");

                        Resource();
                        Sta();
                        HeaderData();

                        ddlResource.SelectedValue = resource;


                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);

                        ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 4 ");
                    }

                }
                catch (Exception ex)
                {
                    String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "HoldPoints.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
                }

            }

        }

        protected void lnkFilter_Click(object sender, EventArgs e)
        {
            try
            {
                string projectID = pro();
                Session["SelectedProid"] = projectID;
                string platformID = plf();
                Session["SelectedPlatID"] = platformID;
                string SelectedRes = Res();
                Session["SelectedResID"] = SelectedRes;
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");

            }
            ListData();
            grvRpt.Rebind();
        }



        public void Resourses()
        {
            rdResourse.DataSource = ObjclsFrms.loadList("SelectResourseforTransaction", "sp_Transactions");
            rdResourse.DataTextField = "FirstName";
            rdResourse.DataValueField = "ID";
            rdResourse.DataBind();
        }



        public string mainConditions()
        {

            string Resourse = Res();
            string Project = pro();
            string platform = plf();

            string mainCondition = "";
            string ResourseCondition = "";
            string ProjectCondition = "";
            string platformCondition = "";

            try
            {


                if (Resourse.Equals("0"))
                {
                    ResourseCondition = "";
                }
                else
                {
                    ResourseCondition = " and trk_AssignedEmp_ID in (" + Resourse + ")";
                }


                if (Project.Equals("0"))
                {
                    ProjectCondition = "";
                }
                else
                {
                    ProjectCondition = " and trk_prt_ID in (" + Project + ")";
                }

                if (platform.Equals("0"))
                {
                    platformCondition = "";
                }
                else
                {
                    platformCondition = " and trk_plf_ID in (" + platform + ")";
                }

            }
            catch (Exception ex)
            {

            }
            mainCondition += ResourseCondition;
            mainCondition += ProjectCondition;
            mainCondition += platformCondition;
            return mainCondition;
        }

        public string Res()
        {
            var CollectionMarket = rdResourse.CheckedItems;
            string ResID = "";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        ResID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        ResID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        ResID += item.Value;
                    }
                    j++;
                }
                return ResID;
            }
            else
            {
                return "trk_AssignedEmp_ID";
            }

        }

      

        protected void xldwload_Click(object sender, ImageClickEventArgs e)
        {
            string mainCondition = "";
            mainCondition = mainConditions();
            DataTable dt = default(DataTable);
            dt = ObjclsFrms.loadList("ListHoldPointsForExcel", "sp_Transactions", mainCondition);

            BuildExcel excel = new BuildExcel();

            byte[] output = excel.SpreadSheetProcess(dt, "HoldPoints");

            Response.ContentType = ContentType;

            Response.Headers.Remove("Content-Disposition");

            Response.AppendHeader("Content-Disposition", string.Format("attachment; filename={0}.{1}", "HoldPoints", "Xlsx"));

            Response.BinaryWrite(output);

            Response.End();
        }

        public void GetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                string filterExpression = string.Empty;

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        if (Session[SessionPrefix + columnName] != null)

                        {

                            string filterValue = Session[SessionPrefix + columnName].ToString();



                            if (filterValue != "")
                            {

                                column.CurrentFilterValue = filterValue;



                                if (!string.IsNullOrEmpty(filterExpression))

                                {

                                    filterExpression += " AND ";

                                }

                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);

                            }

                        }

                    }

                }

                if (filterExpression != string.Empty)

                {

                    grvRpt.MasterTableView.FilterExpression = filterExpression;

                }



            }

            catch (Exception ex)

            {



            }

        }

        public void Resource()
        {
            try
            {
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 2 ");


                string projectId = Session["ProjectID"].ToString();
                string platformId = Session["PlatformID"].ToString();
                string[] arr = { platformId.ToString() };
                ddlResource.DataSource = ObjclsFrms.loadList("SelResourceForDropdown", "sp_Transactions", projectId, arr);
                ddlResource.DataTextField = "Name";
                ddlResource.DataValueField = "ID";
                ddlResource.DataBind();
            }
            catch (Exception ex)
            {
                // Handle exceptions if needed
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "HoldPoints.aspx Resource()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }


        public void HeaderData()
        {
            string Id = Session["ID"].ToString();
            DataTable lstDatas = new DataTable();
            lstDatas = ObjclsFrms.loadList("ListTrackerLifeCycleByID", "sp_Transactions", Id);
            if (lstDatas.Rows.Count > 0)
            {
                RadPanelItem rp = RadPanelBar0.Items[0];

                Label lblTracker = (Label)rp.FindControl("lblTracker");
                Label lblRes = (Label)rp.FindControl("lblRes");
                Label lblDec = (Label)rp.FindControl("lblDec");
                Label lblpage = (Label)rp.FindControl("lblpage");
                Label lblPlf = (Label)rp.FindControl("lblPlf");
                Label lblEffort = (Label)rp.FindControl("lblEffort");




                lblTracker.Text = lstDatas.Rows[0]["trk_TicketNumber"].ToString();
                lblRes.Text = lstDatas.Rows[0]["Resource"].ToString();
                lblDec.Text = lstDatas.Rows[0]["trk_Desc"].ToString();
                lblpage.Text = lstDatas.Rows[0]["trk_Page"].ToString();
                lblPlf.Text = lstDatas.Rows[0]["plf_Name"].ToString();
                lblEffort.Text = lstDatas.Rows[0]["trk_ExpectedEffort"].ToString();


            }
        }
        public void Statuses()
        {
            try
            {               
                ddlStatus.DataSource = ObjclsFrms.loadList("SelStatusForDropdownHP", "sp_Transactions");
                ddlStatus.DataTextField = "Name";
                ddlStatus.DataValueField = "ID";
                ddlStatus.DataBind();
            }
            catch (Exception ex)
            {
                // Handle exceptions if needed
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "HoldPoints.aspx Resource()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }


        public void Sta()
        {
            try
            {
                ddlStatus.DataSource = ObjclsFrms.loadList("SelStatusForDropdownRT", "sp_Transactions");
                ddlStatus.DataTextField = "Name";
                ddlStatus.DataValueField = "ID";
                ddlStatus.DataBind();
            }
            catch (Exception ex)
            {
                // Handle exceptions if needed
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "HoldPoints.aspx Resource()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        protected void lnkSave_Click(object sender, EventArgs e)
        {
            try
            {
                string User, Resource, ID, Sts;

                User = UICommon.GetCurrentUserID().ToString();
                Resource = ddlResource.SelectedValue.ToString();
                ID = Session["ID"].ToString();
                Sts = ddlStatus.SelectedValue.ToString();

                string[] arr = { Resource, User, Sts };
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("UpdateResourceHP", "sp_Transactions", ID.ToString(), arr);
                string res = lstUser.Rows[0]["Res"].ToString();
                // int res = Int32.Parse(Value.ToString());
                if (lstUser.Rows.Count > 0)
                {
                    if (res == "1")
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Tracker updated successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('Something went wrong, please try again later.');</script>", false);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('Something went wrong, please try again later.');</script>", false);
                }

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "HoldPoints.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/HoldPoints.aspx");
        }

        protected void rdproject_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            string proID = pro();
            if (proID.Equals("epl_prt_ID"))
            {
                proID = "0";
            }
            string project = " epl_prt_ID in (" + proID + ")";
            Platforms(project);
        }

        protected void rdPlatform_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            string proID = pro();
            if (proID.Equals("epl_prt_ID"))
            {
                proID = "0";
            }
            string project = " epl_prt_ID in (" + proID + ")";
            string plfID = plf();
            if (plfID.Equals("epl_plf_ID"))
            {
                plfID = "0";
            }
            string platform = " and epl_plf_ID in (" + plfID + ")";
            Resourses(project, platform);
        }



        public void Project()
        {
            rdproject.DataSource = ObjclsFrms.loadList("SelectProjectforTransaction", "sp_Transactions");
            rdproject.DataTextField = "project";
            rdproject.DataValueField = "prt_ID";
            rdproject.DataBind();
        }

        public void Platforms(string project)
        {
            rdPlatform.DataSource = ObjclsFrms.loadList("SelectPlatformforTransaction", "sp_Transactions", project);
            rdPlatform.DataTextField = "plf_Name";
            rdPlatform.DataValueField = "epl_plf_ID";
            rdPlatform.DataBind();
        }

        public string pro()
        {
            var CollectionMarket = rdproject.CheckedItems;
            string ProID = " ";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        ProID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        ProID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        ProID += item.Value;
                    }
                    j++;
                }
                return ProID;
            }
            else
            {
                return "trk_prt_ID";
            }

        }

        public string plf()
        {
            var CollectionMarket = rdPlatform.CheckedItems;
            string plfID = " ";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        plfID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        plfID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        plfID += item.Value;
                    }
                    j++;
                }
                return plfID;
            }
            else
            {
                return "trk_plf_ID";
            }

        }

        public void Resourses(string project, string platform)
        {
            string[] arr = { platform.ToString() };
            rdResourse.DataSource = ObjclsFrms.loadList("SelectResourseforTransaction", "sp_Transactions", project, arr);
            rdResourse.DataTextField = "FirstName";
            rdResourse.DataValueField = "ID";
            rdResourse.DataBind();
        }

        private void ClearGridFilterConditions(RadGrid grd, string SessionPrefix)
        {
            try
            {
                foreach (GridColumn column in grd.MasterTableView.Columns)
                {
                    if (column is GridBoundColumn boundColumn)
                    {
                        string columnName = boundColumn.UniqueName;
                        column.CurrentFilterValue = string.Empty;

                        Session[SessionPrefix + columnName] = null;
                    }
                }
                grd.MasterTableView.FilterExpression = string.Empty;
            }
            catch (Exception ex)
            {

            }
        }

        protected void TrackerReset_Click(object sender, ImageClickEventArgs e)
        {
            try
            {

                ClearGridFilterConditions(grvRpt, "CP");
                foreach (RadComboBoxItem item in rdproject.Items)
                {
                    item.Checked = false;
                }
                foreach (RadComboBoxItem item in rdPlatform.Items)
                {
                    item.Checked = false;
                }
                foreach (RadComboBoxItem item in rdResourse.Items)
                {
                    item.Checked = false;
                }

                string mainCondition = mainConditions();
                DataTable lstUser = ObjclsFrms.loadList("SelectHoldPoints", "sp_Transactions", mainCondition);

                grvRpt.DataSource = lstUser;
                grvRpt.DataBind();

                Session["lstTracker"] = lstUser;
            }
            catch (Exception ex)
            {
                string errorMessage = ex.Message;
                if (ex.InnerException != null)
                {
                    errorMessage += " Inner Exception: " + ex.InnerException.Message;
                }
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "HoldPoints.aspx", "TrackerReset_Click Error: " + errorMessage);

            }

        }
    }
}