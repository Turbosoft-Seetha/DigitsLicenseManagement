﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{
    public partial class AddUnAssignedTracker : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        private bool isSaving = false;
        public int ResponseID
        {
            get
            {
                int ResponseID;
                int.TryParse(Request.Params["Id"], out ResponseID);

                return ResponseID;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                RestoreSessionValues();
              

              
                Project();
                Platform();
                ListData();
            }
        }

        public void Project()
        {
            try
            {
                ddlProject.DataSource = ObjclsFrms.loadList("SelProjectForDropdown", "sp_Transactions");
                ddlProject.DataTextField = "prt_Name";
                ddlProject.DataValueField = "prt_ID";
                ddlProject.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddUnAssignedTracker.aspx Project()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }

        public void Platform()
        {
            try
            {
                string projectId = ddlProject.SelectedValue.ToString();
                ddlPlatform.DataSource = ObjclsFrms.loadList("SelPlatformForDropdown", "sp_Transactions", projectId);
                ddlPlatform.DataTextField = "plf_Name";
                ddlPlatform.DataValueField = "plf_ID";
                ddlPlatform.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddUnAssignedTracker.aspx Platform()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }
        //protected void lnkCancel_Click(object sender, EventArgs e)
        //{

        //}

        protected void lnkreset_Click(object sender, EventArgs e)
        {
            RefreshSession();
            Response.Redirect("AddUnAssignedTracker.aspx?Id=" + 0);
        }

        protected void lnkProceed_Click(object sender, EventArgs e)
        {
            if (ResponseID.Equals("") || ResponseID == 0)
            {
                DataTable dsc = (DataTable)ViewState["DataTable"];
                if (dsc == null)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(),
                        "tmp", "<script type='text/javascript'>Failure('Add Atleast one record');</script>", false);
                    return;
                }
                else
                {


                    //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
                    SaveData();
                }
            }
            else
            {
                //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
                SaveData();

            }
        }

        protected void ddlProject_SelectedIndexChanged(object sender, Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs e)
        {
            try
            {

                Session["trk_prt_ID"] = ddlProject.SelectedValue.ToString();
                string projectId = Session["trk_prt_ID"].ToString();
                if (ResponseID.Equals("") || ResponseID == 0)
                {
                  
                    ddlPlatform.Text = "";
                }
                else
                {
                    refreshform();
                } 
                // grvRpt.Rebind();
                Platform();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx ddlProject_SelectedIndexChanged", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        public void refreshform()
        {
         // Clear items in ddlStatus

            ddlPlatform.Text = "";
            txtDesc.Text = "";
            txtPage.Text = "";
          

        }

        public void RefreshSession()
        {
            Session["ID"] = null;
            Session["PlatformID"] = null;
            Session["trk_plf_ID"] = null;
            Session["trk_AssignedEmp_ID"] = null;
            Session["trk_prt_ID"] = null;
            Session["ExpectedDelDate"] = null;
        }

        private void RestoreSessionValues()
        {

            if (Session["trk_prt_ID"] != null)
            {

                string selectedProject = Session["trk_prt_ID"].ToString();
                ddlProject.SelectedValue = selectedProject;
                Platform();


                if (Session["trk_plf_ID"] != null)
                {
                    string selectedPlatform = Session["trk_plf_ID"].ToString();
                    ddlPlatform.SelectedValue = selectedPlatform;

                }

             
              


            }
        }
        protected void lnkAdd_Click(object sender, EventArgs e)
        {         
            lnkAdd.Attributes.Add("onclick", "this.disabled=true;" + ClientScript.GetPostBackEventReference(lnkAdd, null) + ";");
            SaveData();
        }


        //public void addTable()
        //{
        //    string platform,  platformval, page,  ID;
        //    int id;

        //    DataTable dts;

        //    if (ViewState["DataTable"] == null)
        //    {
        //        dts = new DataTable();
        //        dts.Columns.Add("ID");
        //        dts.Columns.Add("Platform");
        //        dts.Columns.Add("Platformval");

        //        dts.Columns.Add("Page");

        //    }
        //    else
        //    {
        //        dts = (DataTable)ViewState["DataTable"];
        //    }

        //    id = GetNextId(dts); // Use a function to get the next unique ID

        //    ID = id.ToString();
        //    platform = ddlPlatform.SelectedItem.Text.ToString();
        //    platformval = ddlPlatform.SelectedValue.ToString();

        //    page = txtPage.Text.ToString();

        //    dts.Rows.Add(ID, platform, platformval, page);

        //    ViewState["DataTable"] = dts;
        //    Session["DataTable"] = dts;
        //    grvRpt.DataSource = dts;
        //    grvRpt.DataBind();

        //    ddlPlatform.Text = "";

        //    txtPage.Text = "";
        //}


        private int GetNextId(DataTable dataTable)
        {
            int nextId = 1;

            if (dataTable.Rows.Count > 0)
            {
                // Find the maximum ID in the DataTable and increment it
                nextId = dataTable.AsEnumerable().Max(row => int.Parse(row["ID"].ToString())) + 1;
            }

            return nextId;
        }

        public void ListData()
        {

            try
            {

                string Project = ddlProject.SelectedValue.ToString();
                string ProjectCondition = " ";
                if (Project == "")
                {
                    ProjectCondition = " ";
                }
                else
                {
                    ProjectCondition = " and trk_prt_ID in (" + Project + ")";
                }

                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("SelectTracker", "sp_Transactions", ProjectCondition);
                //grvRpt.DataSource = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListTracker.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }
        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            ListData();
        }

        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            if (e.CommandName.Equals("Delete"))
            {
                ViewState["DeleteID"] = null;
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("ID").ToString();
                ViewState["delID"] = ID;
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>delConfim();</script>", false);
            }
        }

        protected void lnkSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveData();

            }
            catch (Exception ex)
            {

            }
        }

        protected void Save()
        {
            try
            {
               
                string CreatedBy, Desc, Project, Platform, Page;

                CreatedBy = UICommon.GetCurrentUserID().ToString();
                Desc = txtDesc.Text.ToString();
                Project = ddlProject.SelectedValue.ToString();
                Platform = ddlPlatform.SelectedValue.ToString();
                Page = txtPage.Text.ToString();
                // Responsibility = ddlResp.SelectedValue.ToString(); 
                string selectedProjectBeforeSave = Project;


                if (ResponseID.Equals("") || ResponseID == 0)
                {
                    string[] arr = { Project, Platform, Page,  CreatedBy };
                    string Value = ObjclsFrms.SaveData("sp_Transactions", "InsertTracker", Desc, arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)
                    {
                     
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Tracker Saved Successfully');</script>", false);
                    }
                    else if (res == 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }
                }

                else
                {
                   
                }
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx Save()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }


        public void SaveData()
        {
            try
            {
                if (isSaving)
                {
                    // Do not allow multiple save operations
                    return;
                }

                // Set the flag to indicate that the save operation is in progress
                isSaving = true;

                string CreatedBy, Desc, Project, Platform, Page;

                CreatedBy = UICommon.GetCurrentUserID().ToString();
                Desc = txtDesc.Text.ToString();
                Project = ddlProject.SelectedValue.ToString();
                Platform = ddlPlatform.SelectedValue.ToString();
                Page = txtPage.Text.ToString();

                string selectedProjectBeforeSave = Project;

                if (ResponseID.Equals("") || ResponseID == 0)
                {
                    string[] arr = {Desc, Platform, Page, CreatedBy };
                    string Value = ObjclsFrms.SaveData("sp_Tracker", "InsertUnassignTracker", Project, arr);
                    int res = Int32.Parse(Value.ToString());

                    if (res > 0)
                    {
                        grvRpt.Rebind();
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>showSuccessToast('Record has been saved successfully');  window.location.href = 'AddUnAssignedTracker.aspx';</script>", false);
                       
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                    }
                }
                else
                {
                   

                }


            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
            finally
            {
                // Reset the flag after the save operation is complete
                isSaving = false;
            }


        }
        public string GetItemFromGrid()
        {
            using (var sw = new StringWriter())
            {
                using (var writer = XmlWriter.Create(sw))
                {
                    writer.WriteStartDocument(true);
                    writer.WriteStartElement("r");
                    int c = 0;
                    DataTable dsc = (DataTable)ViewState["DataTable"];
                    foreach (DataRow row in dsc.Rows)
                    {

                        string ID = row["ID"].ToString();
                        string Platform = row["Platformval"].ToString();
                        //string Resource = row["Resourceval"].ToString();
                        string Page = row["Page"].ToString();
                        //string Effort = row["Effort"].ToString();
                        // string Date = row["Exp.Del.DateVal"].ToString();
                        //string ExpDate = DateTime.Parse(row["Exp.Del.DateVal"].ToString()).ToString("yyyyMMdd");
                        //string uom = row["uom"].ToString();

                        //if (Mode.Equals("0"))
                        //{
                        createNode(ID, Platform,  Page,  writer);
                        //}
                        c++;
                    }

                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                    writer.Close();

                    if (c == 0)
                    {

                        return null;
                    }
                    else
                    {
                        string ss = sw.ToString();
                        return sw.ToString();
                    }
                }
            }
        }

        private void createNode(string ID, string Platform,  string Page,  XmlWriter writer)
        {
            writer.WriteStartElement("Values");


            writer.WriteStartElement("ID");
            writer.WriteString(ID);
            writer.WriteEndElement();

            writer.WriteStartElement("Platform");
            writer.WriteString(Platform);
            writer.WriteEndElement();

          

            writer.WriteStartElement("Page");
            writer.WriteString(Page);
            writer.WriteEndElement();

           


            writer.WriteEndElement();
        }


        protected void btnOK_Click(object sender, EventArgs e)
        {
           // RefreshSession();
            Response.Redirect("AddUnAssignedTracker.aspx");
        }

        protected void BtnConfrmDelete_Click(object sender, EventArgs e)
        {
            string ID = ViewState["delID"].ToString();
            DataTable dts = (DataTable)ViewState["DataTable"];
            for (int i = dts.Rows.Count - 1; i >= 0; i--)
            {
                DataRow dr = dts.Rows[i];
                string dd = dr["ID"].ToString();
                if (dr["ID"].Equals(ID))
                    dr.Delete();
            }
            dts.AcceptChanges();
            ViewState["DataTable"] = dts;
            int x = dts.Rows.Count;
            //grvRpt.DataSource = dts;
            //grvRpt.DataBind();
            //// Uom();
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>successModal();</script>", false);
        }

        protected void lnkdelsuccess_Click(object sender, EventArgs e)
        {

        }

        protected void grvRpt_NeedDataSource1(object sender, GridNeedDataSourceEventArgs e)
        {
            LoadList();
        }


        public void LoadList()
        {
            try
            {
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("ListUnAsssignTrackers", "sp_Tracker");
                grvRpt.DataSource = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddUnAssignedTracker.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }
    }
}