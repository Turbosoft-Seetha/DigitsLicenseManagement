﻿using GoogleApi.Entities.Search.Video.Common;
using Org.BouncyCastle.Asn1.Ocsp;
using Org.BouncyCastle.Asn1.X509;
using ProcessExcel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Documents.SpreadsheetStreaming;
using Telerik.Web.UI;
using Telerik.Web.UI.Chat;

namespace DigitsTracker.BO_Digits.en
{
    public partial class ActionQueue : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    GetGridSession(grvRpt, "AQ");

                    grvRpt.Rebind();
                }

                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }
                Session["ID"] = "";               
                TotalExpEfffort();
             


                rdfromDate.MinDate = DateTime.Now.AddDays(-4);
                rdfromDate.MaxDate = DateTime.Now.AddDays(1);

            }
        }
       
        public void ListData()
        {
            try
            {
                string user = UICommon.GetCurrentUserID().ToString();
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("SelectActionQueue", "sp_Transactions" , user);
                grvRpt.DataSource = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ActionQueue.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }
        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            ListData();
        }             
                     
        protected void grvRpt_ItemCommand(object sender, GridCommandEventArgs e)
        {

            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "AQ");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }
            if (e.CommandName.Equals("AdditionalTime"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("trk_ID").ToString();
                Response.Redirect("TrackerAdditionalTime.aspx?Id=" + ID);
            }

            if (e.CommandName.Equals("LifeCycle"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string Id = dataItem.GetDataKeyValue("trk_ID").ToString();
                Response.Redirect("TrackerLifeCycleAQ.aspx?Id=" + Id);

               
            }

            if (e.CommandName.Equals("AddStatus"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string Id = dataItem.GetDataKeyValue("trk_ID").ToString();

            

                Session["ID"] = Id.ToString();
                HeaderData();
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>UpdateStatus();</script>", false);

            }
        }



        public void TotalExpEfffort()
        {
            try
            {
                string user = UICommon.GetCurrentUserID().ToString();
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("totalExpEffort", "sp_Transactions", user);
                if (lstUser.Rows.Count > 0)
                {
                    // Access the value from the first row, first column
                    ddlexpeffort.Text = lstUser.Rows[0][0].ToString();
                }
                DataTable lstUser2 = default(DataTable);
                lstUser2 = ObjclsFrms.loadList("totalActualEffort", "sp_Transactions", user);
                if (lstUser2.Rows.Count > 0)
                {
                    // Access the value from the first row, first column
                    lblActualEffort.Text = lstUser2.Rows[0][0].ToString();
                }
            }

            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ActionQueue.aspx Status()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }
        public void SetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        string filterValue = column.CurrentFilterValue;

                        Session[SessionPrefix + columnName] = filterValue;

                    }

                }

            }

            catch (Exception ex)

            {




            }



        }
        public void GetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                string filterExpression = string.Empty;

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        if (Session[SessionPrefix + columnName] != null)

                        {

                            string filterValue = Session[SessionPrefix + columnName].ToString();



                            if (filterValue != "")
                            {

                                column.CurrentFilterValue = filterValue;



                                if (!string.IsNullOrEmpty(filterExpression))

                                {

                                    filterExpression += " AND ";

                                }

                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);

                            }

                        }

                    }

                }

                if (filterExpression != string.Empty)

                {

                    grvRpt.MasterTableView.FilterExpression = filterExpression;

                }



            }

            catch (Exception ex)

            {



            }

        }   
        

        protected void lnkSave_Click(object sender, EventArgs e)
        {
            try
            {
                string User, ActualEffort, Status, Id,remark;
                string FromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                User = UICommon.GetCurrentUserID().ToString();               
                ActualEffort = txtActEffort.Text.ToString();           
                Status = rblStatus.SelectedValue;
                Id = Session["ID"].ToString();
                remark = txtRemarks.InnerText.ToString();
                string[] arr = { ActualEffort, Status, Id ,remark, FromDate };
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("UpadateActionQueue", "sp_Transactions", User, arr);
                string res = lstUser.Rows[0]["Res"].ToString();
                // int res = Int32.Parse(Value.ToString());
                if (lstUser.Rows.Count > 0)
                {
                    if (res == "1")
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Sucess2('Tracker updated successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('Something went wrong, please try again later.');</script>", false);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('Something went wrong, please try again later.');</script>", false);
                }

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "TrackerLifeCycleAQ.aspx Save()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/ActionQueue.aspx");
        }


        public void HeaderData()
        {
            string Id = Session["ID"].ToString();
            DataTable lstDatas = new DataTable();
            lstDatas = ObjclsFrms.loadList("ListTrackerLifeCycleByID", "sp_Transactions", Id);
            if (lstDatas.Rows.Count > 0)
            {
                RadPanelItem rp = RadPanelBar0.Items[0];

                Label lblTracker = (Label)rp.FindControl("lblTracker");
                Label lblRes = (Label)rp.FindControl("lblRes");
                Label lblDec = (Label)rp.FindControl("lblDec");
                Label lblpage = (Label)rp.FindControl("lblpage");
                Label lblPlf = (Label)rp.FindControl("lblPlf");
                Label lblEffort = (Label)rp.FindControl("lblEffort");




                lblTracker.Text = lstDatas.Rows[0]["trk_TicketNumber"].ToString();
                lblRes.Text = lstDatas.Rows[0]["Resource"].ToString();
                lblDec.Text = lstDatas.Rows[0]["trk_Desc"].ToString();
                lblpage.Text = lstDatas.Rows[0]["trk_Page"].ToString();
                lblPlf.Text = lstDatas.Rows[0]["plf_Name"].ToString();
                lblEffort.Text = lstDatas.Rows[0]["trk_ExpectedEffort"].ToString();



            }

            DataTable lstDatas2 = new DataTable();
            lstDatas2 = ObjclsFrms.loadList("ConsumedHoursByID", "sp_Transactions", Id);
            if (lstDatas2.Rows.Count > 0)
            {
                RadPanelItem rp = RadPanelBar0.Items[0];
                Label lblConEffort = (Label)rp.FindControl("lblConEffort");
                lblConEffort.Text = lstDatas2.Rows[0]["ConsumedEffort"].ToString();

            }
        }

        protected void grvRpt_ItemDataBound(object sender, GridItemEventArgs e)
        {
            try
            {
                if (e.Item is GridDataItem)
                {
                    GridDataItem item = (GridDataItem)e.Item;
                    string actualEffortText = item["trk_ActualEffort"].Text;
                    string expectedEffortText = item["trk_ExpectedEffort"].Text;
                    string dueDateText = item["ExpectedDelDate"].Text;
                    string today = DateTime.Now.ToString("dd-MMM-yyyy");

                    decimal actualEffort;
                    decimal expectedEffort;

                    if (actualEffortText == "&nbsp;")
                    {
                        actualEffortText = "0";
                    }

                    if (!decimal.TryParse(actualEffortText, out actualEffort))
                    {
                        Console.WriteLine("Error parsing Actual Effort: " + actualEffortText);
                        return;
                    }

                    if (!decimal.TryParse(expectedEffortText, out expectedEffort))
                    {
                        Console.WriteLine("Error parsing Expected Effort: " + expectedEffortText);
                        return;
                    }

                    if (!string.IsNullOrEmpty(dueDateText))
                    {
                        DateTime dueDate = DateTime.Parse(dueDateText);

                        // Check if the due date is before today's date
                        if (dueDate < DateTime.Today && actualEffort == 0)
                        {
                            item.Style["background-color"] = "#ffffe0";

                            return; // Exit early if due date condition is met
                        }
                    }

                    // If due date condition is not met, proceed with other color conditions
                    if (actualEffort > expectedEffort)
                    {
                        item.Style["background-color"] = "#ffffe0";
                        item["trk_TicketNumber"].Style["color"] = "red";

                    }
                    else if (actualEffort < expectedEffort && actualEffort != 0)
                    {
                        item.Style["background-color"] = "#ffffe0";

                        item["trk_TicketNumber"].Style["color"] = "#70e300";
                    }
                    else if (actualEffort == expectedEffort)
                    {
                        item.Style["background-color"] = "#ffffe0";

                        item["trk_TicketNumber"].Style["color"] = "Blue";
                    }
                    else
                    {
                        item.Style["background-color"] = "#FFFFFF00";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the exception
            }
        }
    }
}