﻿using GoogleApi.Entities.Common.Enums;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using Telerik.Web.UI;
using Telerik.Web.UI.Chat;

namespace DigitsTracker.BO_Digits.en
{
    public partial class AddEditEmployeePlatformMapping : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        public int ResponseID
        {
            get
            {
                int ResponseID;
                int.TryParse(Request.Params["ID"], out ResponseID);

                return ResponseID;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Employee();
                Platforms();
                FillForm();

            }
        }
        public void FillForm()
        {
            try
            {
                DataTable lstDatas = ObjclsFrms.loadList("SelectEmployeeplatformMappingByID", "sp_Masters", ResponseID.ToString());
                if (lstDatas.Rows.Count > 0)
                {
                    string employee, platform, status;
                    employee = lstDatas.Rows[0]["employee"].ToString();
                    platform = lstDatas.Rows[0]["platform"].ToString();                    
                    status = lstDatas.Rows[0]["Status"].ToString();
                    string[] ar = platform.Split('-');

                    ddlEmployee.SelectedValue = employee.ToString();
                    ddlPlatform.SelectedValue = platform.ToString();
                    ddlStatus.SelectedValue = status.ToString();

                    for (int i = 0; i < ar.Length; i++)
                    {
                        foreach (RadComboBoxItem items in ddlPlatform.Items)
                        {
                            if (items.Value == ar[i])
                            {
                                items.Checked = true;
                            }
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditEmployeePlatformMapping.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }
        public string platformcolumns()
        {

            using (var sw = new StringWriter())
            {
                using (var writer = XmlWriter.Create(sw))
                {
                    writer.WriteStartDocument(true);
                    writer.WriteStartElement("r");
                    int c = 0;

                    var ColelctionMarkets = ddlPlatform.CheckedItems;                    
                    int MarCount = ColelctionMarkets.Count;
                    if (ColelctionMarkets.Count > 0)
                    {
                        foreach (var item in ColelctionMarkets)
                        {
                            //where 1 = 1
                            createNode(item.Value, writer);
                            c++;

                        }
                    }

                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                    writer.Close();
                    if (c == 0)
                    {
                        return "";
                    }
                    else
                    {
                        string ss = sw.ToString();
                        return sw.ToString();
                    }
                }
            }

        }
            private void createNode(string epl_plf_ID, XmlWriter writer)
            {
                writer.WriteStartElement("Values");
                writer.WriteStartElement("epl_plf_ID");
                writer.WriteString(epl_plf_ID);
                writer.WriteEndElement();
                writer.WriteEndElement();
            }
        
        protected void Save()
        {
            try
            {


                string user,employee,platform,status ;

                user = UICommon.GetCurrentUserID().ToString();
                employee = ddlEmployee.SelectedValue.ToString();
                platform = platformcolumns();
                status = ddlStatus.SelectedValue.ToString();


                if (ResponseID.Equals("") || ResponseID == 0)
                {                   
                        string[] arr = { employee.ToString(), platform.ToString(), status.ToString() };
                        string Value = ObjclsFrms.SaveData("sp_Masters", "InsertEmployeePlatform", user.ToString(), arr);
                        int res = Int32.Parse(Value.ToString());
                        if (res > 0)
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Mapping Saved Successfully');</script>", false);
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                        }
                 }
                    
                

                else
                {
                    string id = ResponseID.ToString();
                    string[] arr = { employee.ToString(), platform.ToString(), status.ToString() };
                    string Value = ObjclsFrms.SaveData("sp_Masters", "UpdateEmployeePlatform", id.ToString(), arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)

                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Mapping Updated Successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }
                }
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditEmployeePlatformMapping.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }

        protected void save_Click(object sender, EventArgs e)
        {
            Save();
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListEmployeePlatformMapping.aspx");
        }

        protected void lnkAdd_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
        }

        protected void lnkCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListEmployeePlatformMapping.aspx");
        }
       
        
        public void Platforms()
        {
            try
            {
                string[] arr = { ResponseID.ToString() };
                DataTable dt = ObjclsFrms.loadList("SelectPlatformForEmployeeMapping", "sp_Masters");
                ddlPlatform.DataSource = dt;
                ddlPlatform.DataTextField = "plf_Name";
                ddlPlatform.DataValueField = "plf_ID";
                ddlPlatform.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditEmployeePlatformMapping.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }

        public void Employee()
        {
            try
            {
                string[] arr = { ResponseID.ToString() };
                DataTable dt = ObjclsFrms.loadList("SelectEmployeeForMapping", "sp_Masters");
                ddlEmployee.DataSource = dt;
                ddlEmployee.DataTextField = "emp_Name";
                ddlEmployee.DataValueField = "ID";
                ddlEmployee.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditEmployeePlatformMapping.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }

        
    }
}