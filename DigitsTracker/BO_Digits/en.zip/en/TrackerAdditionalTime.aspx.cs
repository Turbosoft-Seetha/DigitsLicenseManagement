﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{
    public partial class TrackerAdditionalTime : System.Web.UI.Page
    {
        GeneralFunctions obj = new GeneralFunctions();

        public int ResponseID
        {
            get
            {
                int ResponseID;
                int.TryParse(Request.Params["ID"], out ResponseID);

                return ResponseID;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                HeaderData();

            }
        }

        public void AdditionalEffort()
        {
            string ID = ResponseID.ToString();
            DataTable lstData = default(DataTable);
            lstData = obj.loadList("SelAdditionalEffort", "sp_Transactions", ID);
            EffortGrid.DataSource = lstData;
           



        }

        protected void EffortGrid_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            AdditionalEffort();
           

        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/ActionQueue.aspx");
        }

        protected void lnkSave_Click(object sender, EventArgs e)
        {
            try
            {
                string User,  ID, AddEffort;

                User = UICommon.GetCurrentUserID().ToString();

                ID = ResponseID.ToString();
                AddEffort = ddlAddEffort.Text.ToString();

               
                string[] arr = { AddEffort, User };

                string Value = obj.SaveData("sp_Transactions", "UpadateActionQueueforAddTime", ID, arr);
                 int res = Int32.Parse(Value.ToString());
                if (res > 0)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Tracker updated successfully');</script>", false);

                  
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('Something went wrong, please try again later.');</script>", false);
                }

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                obj.LogMessageToFile(UICommon.GetLogFileName(), "TrackerAdditionalTime.aspx Save()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }



       

        protected void lnkCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ActionQueue.aspx");

        }

        public void HeaderData()
        {
            DataTable lstDatas = new DataTable();
            lstDatas = obj.loadList("ListTrackerLifeCycleByID", "sp_Transactions", ResponseID.ToString());
            if (lstDatas.Rows.Count > 0)
            {
                RadPanelItem rp = RadPanelBar1.Items[0];

                Label lblTracker = (Label)rp.FindControl("lblTracker");
                Label lblRes = (Label)rp.FindControl("lblRes");
                Label lblDec = (Label)rp.FindControl("lblDec");
                Label lblpage = (Label)rp.FindControl("lblpage");
                Label lblPlf = (Label)rp.FindControl("lblPlf");
                Label lblEffort = (Label)rp.FindControl("lblEffort");




                lblTracker.Text = lstDatas.Rows[0]["trk_TicketNumber"].ToString();
                lblRes.Text = lstDatas.Rows[0]["Resource"].ToString();
                lblDec.Text = lstDatas.Rows[0]["trk_Desc"].ToString();
                lblpage.Text = lstDatas.Rows[0]["trk_Page"].ToString();
                lblPlf.Text = lstDatas.Rows[0]["plf_Name"].ToString();
                lblEffort.Text = lstDatas.Rows[0]["trk_ExpectedEffort"].ToString();


            }
        }
    }
}