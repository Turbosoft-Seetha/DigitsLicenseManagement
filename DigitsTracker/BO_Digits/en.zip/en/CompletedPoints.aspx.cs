﻿using ProcessExcel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{
    public partial class CompletedPoints : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Project();
                string proID = pro();
                string project = " epl_prt_ID in (" + proID + ")";
                Platforms(project);
                string plfID = plf();
                string platform = " and epl_plf_ID in (" + plfID + ")";
                Resourses(project, platform);

                try
                {
                    if (Session["SelectedPro"] != null)
                    {
                        string projectID = Session["SelectedPro"].ToString();
                        foreach (RadComboBoxItem item in rdproject.Items)
                        {
                            if (projectID.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                        }

                        project = " and epl_prt_ID in (" + projectID + ")";
                        Platforms(project);
                    }
                    else
                    {
                        string pID = pro();
                        string routeCondition = " trk_prt_ID in (" + pID + ")";
                    }

                    if (Session["SelectedPlat"] != null)
                    {
                        string projectID = Session["SelectedPro"].ToString();
                        foreach (RadComboBoxItem item in rdproject.Items)
                        {
                            if (projectID.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                        }

                        project = " epl_prt_ID in (" + projectID + ")";
                        Platforms(project);

                        string platformID = Session["SelectedPlat"].ToString();
                        foreach (RadComboBoxItem item in rdPlatform.Items)
                        {
                            if (platformID.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                        }

                        platform = " and epl_plf_ID in (" + platformID + ")";
                        Resourses(project, platform);
                    }
                    else
                    {
                        string pID = pro();
                        string routeCondition = " trk_plf_ID in (" + pID + ")";
                    }

                    if (Session["SelectedRes"] != null)
                    {
                        string[] selectedResourceIDs = Session["SelectedRes"].ToString().Split(',');
                        foreach (RadComboBoxItem item in rdResourse.Items)
                        {
                            if (selectedResourceIDs.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                        }
                    }

                    else
                    {
                        string res = Res();
                        string routeCondition = " trk_AssignedEmp_ID in (" + res + ")";
                    }
                    //invType

                }
                catch (Exception ex)
                {

                }
                try
                {
                    GetGridSession(grvRpt, "CP");

                    grvRpt.Rebind();
                }

                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");

                }
            }
        }
        public void ListData()
        {
            try
            {
                string mainCondition = "";
                mainCondition = mainConditions();
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("SelectCompletedPoints", "sp_Transactions", mainCondition);
                grvRpt.DataSource = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "CompletedPoints.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }
        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            ListData();
        }

        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "CP");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }

            //if (e.CommandName.Equals("AdditionalTime"))
            //{
            //    GridDataItem dataItem = e.Item as GridDataItem;
            //    string ID = dataItem.GetDataKeyValue("trk_ID").ToString();
            //    Response.Redirect("AdditionalTimeCP.aspx?Id=" + ID);
            //}

            if (e.CommandName.Equals("LifeCycle"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string Id = dataItem.GetDataKeyValue("trk_ID").ToString();
                Response.Redirect("TrackerLifeCycleCP.aspx?Id=" + Id);


            }

        }

        protected void lnkFilter_Click(object sender, EventArgs e)
        {
            try
            {
                string projectID = pro();
                Session["SelectedPro"] = projectID;
                string platformID = plf();
                Session["SelectedPlat"] = platformID;
                string SelectedRes = Res();
                Session["SelectedRes"] = SelectedRes;
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");

            }
            ListData();
            grvRpt.Rebind();
        }


        public void Resourses()
        {
            rdResourse.DataSource = ObjclsFrms.loadList("SelectResourseforTransaction", "sp_Transactions");
            rdResourse.DataTextField = "FirstName";
            rdResourse.DataValueField = "ID";
            rdResourse.DataBind();
        }



        public string mainConditions()
        {

            string Resourse = Res();
            string Project = pro();
            string platform = plf();

            string mainCondition = "";
            string ResourseCondition = "";
            string ProjectCondition = "";
            string platformCondition = "";

            try
            {


                if (Resourse.Equals("0"))
                {
                    ResourseCondition = "";
                }
                else
                {
                    ResourseCondition = " and trk_AssignedEmp_ID in (" + Resourse + ")";
                }


                if (Project.Equals("0"))
                {
                    ProjectCondition = "";
                }
                else
                {
                    ProjectCondition = " and trk_prt_ID in (" + Project + ")";
                }

                if (platform.Equals("0"))
                {
                    platformCondition = "";
                }
                else
                {
                    platformCondition = " and trk_plf_ID in (" + platform + ")";
                }

            }
            catch (Exception ex)
            {

            }
            mainCondition += ResourseCondition;
            mainCondition += ProjectCondition;
            mainCondition += platformCondition;
            return mainCondition;
        }

        public string Res()
        {
            var CollectionMarket = rdResourse.CheckedItems;
            string ResID = "";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        ResID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        ResID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        ResID += item.Value;
                    }
                    j++;
                }
                return ResID;
            }
            else
            {
                return "trk_AssignedEmp_ID";
            }

        }

      
        protected void XlDownload_Click(object sender, ImageClickEventArgs e)
        {
            string mainCondition = "";
            mainCondition = mainConditions();
            DataTable dt = default(DataTable);
            dt = ObjclsFrms.loadList("ListCompletedPointsForExcel", "sp_Transactions", mainCondition);

            BuildExcel excel = new BuildExcel();

            byte[] output = excel.SpreadSheetProcess(dt, "CompletedPoints");

            Response.ContentType = ContentType;

            Response.Headers.Remove("Content-Disposition");

            Response.AppendHeader("Content-Disposition", string.Format("attachment; filename={0}.{1}", "CompletedPoints", "Xlsx"));

            Response.BinaryWrite(output);

            Response.End();
        }


        public void GetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                string filterExpression = string.Empty;

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        if (Session[SessionPrefix + columnName] != null)

                        {

                            string filterValue = Session[SessionPrefix + columnName].ToString();



                            if (filterValue != "")
                            {

                                column.CurrentFilterValue = filterValue;



                                if (!string.IsNullOrEmpty(filterExpression))

                                {

                                    filterExpression += " AND ";

                                }

                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);

                            }

                        }

                    }

                }

                if (filterExpression != string.Empty)

                {

                    grvRpt.MasterTableView.FilterExpression = filterExpression;

                }



            }

            catch (Exception ex)

            {



            }

        }


        public void SetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        string filterValue = column.CurrentFilterValue;

                        Session[SessionPrefix + columnName] = filterValue;

                    }

                }

            }

            catch (Exception ex)

            {




            }



        }

        protected void grvRpt_ItemDataBound(object sender, GridItemEventArgs e)
        {
            try
            {

                if (e.Item is GridDataItem)
                {
                    GridDataItem item = (GridDataItem)e.Item;

                    // Retrieve the values of the Actual Effort and Expected Effort columns
                    string actualEffortText = item["trk_ActualEffort"].Text;
                    string expectedEffortText = item["trk_ExpectedEffort"].Text;

                    decimal actualEffort;
                    decimal expectedEffort;

                    // Try parsing Actual Effort
                    if (!decimal.TryParse(actualEffortText, out actualEffort))
                    {
                        // Log or handle the error
                        Console.WriteLine("Error parsing Actual Effort: " + actualEffortText);
                        return; // Exit the method to prevent further processing
                    }

                    // Try parsing Expected Effort
                    if (!decimal.TryParse(expectedEffortText, out expectedEffort))
                    {
                        // Log or handle the error
                        Console.WriteLine("Error parsing Expected Effort: " + expectedEffortText);
                        return; // Exit the method to prevent further processing
                    }

                    // Compare Actual Effort with Expected Effort and set row color accordingly
                    if (actualEffort > expectedEffort)
                    {
                        item.Style["background-color"] = "#FFCCCC"; // Red color
                    }
                    else if (actualEffort < expectedEffort)
                    {
                        item.Style["background-color"] = "#CCFFCC"; // Green color
                    }
                    else
                    {
                        item.Style["background-color"] = "#CCCCFF"; // Blue color
                    }
                }
            }
            catch (Exception ex)

            {




            }
        }

        protected void rdproject_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            string proID = pro();
            if (proID.Equals("epl_prt_ID"))
            {
                proID = "0";
            }
            string project = " epl_prt_ID in (" + proID + ")";
            Platforms(project);
        }

        protected void rdPlatform_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            string proID = pro();
            if (proID.Equals("epl_prt_ID"))
            {
                proID = "0";
            }
            string project = " epl_prt_ID in (" + proID + ")";
            string plfID = plf();
            if (plfID.Equals("epl_plf_ID"))
            {
                plfID = "0";
            }
            string platform = " and epl_plf_ID in (" + plfID + ")";
            Resourses(project, platform);
        }

        public void Project()
        {
            rdproject.DataSource = ObjclsFrms.loadList("SelectProjectforTransaction", "sp_Transactions");
            rdproject.DataTextField = "project";
            rdproject.DataValueField = "prt_ID";
            rdproject.DataBind();
        }

        public void Platforms(string project)
        {
            rdPlatform.DataSource = ObjclsFrms.loadList("SelectPlatformforTransaction", "sp_Transactions", project);
            rdPlatform.DataTextField = "plf_Name";
            rdPlatform.DataValueField = "epl_plf_ID";
            rdPlatform.DataBind();
        }

        public string pro()
        {
            var CollectionMarket = rdproject.CheckedItems;
            string ProID = " ";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        ProID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        ProID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        ProID += item.Value;
                    }
                    j++;
                }
                return ProID;
            }
            else
            {
                return "trk_prt_ID";
            }

        }

        public string plf()
        {
            var CollectionMarket = rdPlatform.CheckedItems;
            string plfID = " ";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        plfID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        plfID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        plfID += item.Value;
                    }
                    j++;
                }
                return plfID;
            }
            else
            {
                return "trk_plf_ID";
            }

        }

        public void Resourses(string project, string platform)
        {
            string[] arr = { platform.ToString() };
            rdResourse.DataSource = ObjclsFrms.loadList("SelectResourseforTransaction", "sp_Transactions", project, arr);
            rdResourse.DataTextField = "FirstName";
            rdResourse.DataValueField = "ID";
            rdResourse.DataBind();
        }

        protected void TrackerReset_Click(object sender, ImageClickEventArgs e)
        {
            try
            {

                ClearGridFilterConditions(grvRpt, "CP");
                foreach (RadComboBoxItem item in rdproject.Items)
                {
                    item.Checked = false;
                }
                foreach (RadComboBoxItem item in rdPlatform.Items)
                {
                    item.Checked = false;
                }
                foreach (RadComboBoxItem item in rdResourse.Items)
                {
                    item.Checked = false;
                }

                string mainCondition = mainConditions();
                DataTable lstUser = ObjclsFrms.loadList("SelectCompletedPoints", "sp_Transactions", mainCondition);

                grvRpt.DataSource = lstUser;
                grvRpt.DataBind();

                Session["lstTracker"] = lstUser;
            }
            catch (Exception ex)
            {
                string errorMessage = ex.Message;
                if (ex.InnerException != null)
                {
                    errorMessage += " Inner Exception: " + ex.InnerException.Message;
                }
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListTracker.aspx", "TrackerReset_Click Error: " + errorMessage);

            }


            
        }

        private void ClearGridFilterConditions(RadGrid grd, string SessionPrefix)
        {
            try
            {
                foreach (GridColumn column in grd.MasterTableView.Columns)
                {
                    if (column is GridBoundColumn boundColumn)
                    {
                        string columnName = boundColumn.UniqueName;
                        column.CurrentFilterValue = string.Empty;

                        Session[SessionPrefix + columnName] = null;
                    }
                }
                grd.MasterTableView.FilterExpression = string.Empty;
            }
            catch (Exception ex)
            {

            }
        }
    }
}