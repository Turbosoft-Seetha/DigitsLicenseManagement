﻿//using DocumentFormat.OpenXml.Bibliography;
using GoogleApi.Entities.Common.Enums;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml;
using Telerik.Web.UI;
using Telerik.Web.UI.Skins;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace DigitsTracker.BO_Digits.en
{
    public partial class AddEditTracker : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        public int ResponseID
        {
            get
            {
                int ResponseID;
                int.TryParse(Request.Params["Id"], out ResponseID);

                return ResponseID;
            }
        }

        public int UNASSIGNID
        {
            get
            {
                int UNASSIGNID;
                int.TryParse(Request.Params["UATId"], out UNASSIGNID);

                return UNASSIGNID;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                RestoreSessionValues();
                ViewState["DataTable"] = null;
                if (ResponseID.Equals("") || ResponseID == 0)
                {
                    pnl.Visible = false;
                    pnlStat.Visible = false;
                    ddlExpDelDate.MinDate = DateTime.Now.AddDays(-1);
                    try
                    {
                        if (Session["trk_prt_ID"] == null)
                        {
                            
                        }
                        else
                        {
                           
                            
                        }
                    }
                    catch(Exception ex)
                    {
                        String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                        ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx Project()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
                    }

                }
                else
                {
                    pnl.Visible = true;
                    pnlStat.Visible = true;
                    lnkAdd.Visible = false;
                    lblNote.Visible= false;


                }

                FillForm();
                Project();
                Platform();
                Resource();
                Status();
                ListData();
            }
        }

        public void Project()
        {
            try
            {
                ddlProject.DataSource = ObjclsFrms.loadList("SelProjectForDropdown", "sp_Transactions");
                ddlProject.DataTextField = "prt_Name";
                ddlProject.DataValueField = "prt_ID";
                ddlProject.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx Project()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
           
        }
        public void Platform()
        {
            try
            {
                string projectId = ddlProject.SelectedValue.ToString();
                ddlPlatform.DataSource = ObjclsFrms.loadList("SelPlatformForDropdown", "sp_Transactions", projectId);
                ddlPlatform.DataTextField = "plf_Name";
                ddlPlatform.DataValueField = "plf_ID";
                ddlPlatform.DataBind();
            }
            catch(Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx Platform()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
          
        }
        public void Resource()
        {
            try
            {
                string projectId = ddlProject.SelectedValue.ToString();
                string platformId = ddlPlatform.SelectedValue.ToString();
                string[] arr = { platformId.ToString() };

               
                ddlResource.DataSource = ObjclsFrms.loadList("SelResourceForDropdown", "sp_Tracker", projectId, arr);
                ddlResource.DataTextField = "Name";
                ddlResource.DataValueField = "ID";
                ddlResource.DataBind();
            }
            catch (Exception ex)
            {
                // Handle exceptions if needed
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx AppResource()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        public void Status()
        {
            try
            {
                string ID = ResponseID.ToString();
                ddlStatus.DataSource = ObjclsFrms.loadList("SelStatusForDropdown", "sp_Transactions", ID);
                ddlStatus.DataTextField = "sts_Name";
                ddlStatus.DataValueField = "sts_Code";
                ddlStatus.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx Status()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
          
        }
        public void FillForm()
        {
            try
            {

                if (UNASSIGNID > 0)
                {

                    DataTable lstDatas = ObjclsFrms.loadList("SelectUnAssignTrackerByID", "sp_Transactions", UNASSIGNID.ToString());
                    if (lstDatas.Rows.Count > 0)
                    {
                        string Date, CreatedBy, Desc, Project, Platform, Page, Status;

                        Date = lstDatas.Rows[0]["Date"].ToString();
                        CreatedBy = lstDatas.Rows[0]["CreatedBy"].ToString();
                        Desc = lstDatas.Rows[0]["uat_Desc"].ToString();
                        Project = lstDatas.Rows[0]["uat_prt_ID"].ToString();
                        Session["PRO_ID"] = Project.ToString();

                        Platform = lstDatas.Rows[0]["uat_plf_ID"].ToString();
                        Page = lstDatas.Rows[0]["uat_Page"].ToString();

                        Status = lstDatas.Rows[0]["Status"].ToString();

                        lblDate.Text = Date.ToString();
                        lblCreatedBy.Text = CreatedBy.ToString();


                        txtDesc.Text = Desc.ToString();
                        ddlProject.SelectedValue = Project.ToString();
                        ddlPlatform.SelectedValue = Platform.ToString();
                        txtPage.Text = Page.ToString();
                        // ddlResp.SelectedValue = Responsibility.ToString();
                        ddlStatus.SelectedValue = Status.ToString();


                        pnl.Visible = true;
                        lnkreset.Visible = false;
                        lnkProceed.Visible = false;
                        ProceedContinue.Visible = false;
                        lnknext.Visible = true;
                    }

                }

                else
                {
                    DataTable lstDatas = ObjclsFrms.loadList("SelectTrackerByID", "sp_Transactions", ResponseID.ToString());
                    if (lstDatas.Rows.Count > 0)
                    {
                        string Date, CreatedBy, Desc, Project, Platform, Page, Responsibility, Resource, ExpectedEffort, ExpectedDelDate, Status, TicketNo, atualeffort;

                        Date = lstDatas.Rows[0]["Date"].ToString();
                        CreatedBy = lstDatas.Rows[0]["CreatedBy"].ToString();
                        TicketNo = lstDatas.Rows[0]["trk_TicketNumber"].ToString();
                        Desc = lstDatas.Rows[0]["trk_Desc"].ToString();
                        Project = lstDatas.Rows[0]["trk_prt_ID"].ToString();
                        Platform = lstDatas.Rows[0]["trk_plf_ID"].ToString();
                        Page = lstDatas.Rows[0]["trk_Page"].ToString();
                        Responsibility = lstDatas.Rows[0]["trk_Responsibility"].ToString();
                        Resource = lstDatas.Rows[0]["trk_AssignedEmp_ID"].ToString();
                        ExpectedEffort = lstDatas.Rows[0]["trk_ExpectedEffort"].ToString();
                        ExpectedDelDate = lstDatas.Rows[0]["ExpectedDelDate"].ToString();
                        Status = lstDatas.Rows[0]["Status"].ToString();
                        atualeffort = lstDatas.Rows[0]["trk_ActualEffort"].ToString();


                      

                                lblDate.Text = Date;
                                lblCreatedBy.Text = CreatedBy;
                                lblTicket.Text = TicketNo;

                                txtDesc.Text = Desc;
                                ddlProject.SelectedValue = Project;
                                ddlPlatform.SelectedValue = Platform;
                                txtPage.Text = Page;
                                ddlStatus.SelectedValue = Status;
                                pnlStat.Visible = true;
                                // ddlResp.SelectedValue = Responsibility;
                                ddlResource.SelectedValue = Resource;
                                txtExpEffort.Text = ExpectedEffort;


                        if (string.IsNullOrEmpty(atualeffort))
                        {
                            // Disable ddlExpDelDate
                            DateTime expectedDelDate;
                            if (DateTime.TryParse(ExpectedDelDate, out expectedDelDate))
                            {
                                ddlExpDelDate.SelectedDate = expectedDelDate;
                                txtExpEffort.Enabled = true;
                                ddlExpDelDate.Enabled = true;
                                pnl.Visible = true;
                            }
                           
                        }
                        else
                        {



                            if (!string.IsNullOrEmpty(ExpectedDelDate))
                            {
                                DateTime expectedDelDate;
                                if (DateTime.TryParse(ExpectedDelDate, out expectedDelDate))
                                {
                                    ddlExpDelDate.SelectedDate = expectedDelDate;
                                    txtExpEffort.Enabled = false;
                                    ddlExpDelDate.Enabled = false;
                                    pnl.Visible = true;
                                }
                               
                            }
                           


                        }

                            
                    }
                }
            }
            //else
            //{
            //    DataTable lstDatas = ObjclsFrms.loadList("SelectTrackerByID", "sp_Transactions", ResponseID.ToString());
            //    if (lstDatas.Rows.Count > 0)
            //    {
            //        string Date, CreatedBy, Desc, Project, Platform, Page, Responsibility, Resource, ExpectedEffort, ExpectedDelDate, Status, TicketNo;

            //        Date = lstDatas.Rows[0]["Date"].ToString();
            //        CreatedBy = lstDatas.Rows[0]["CreatedBy"].ToString();
            //        TicketNo = lstDatas.Rows[0]["trk_TicketNumber"].ToString();
            //        Desc = lstDatas.Rows[0]["trk_Desc"].ToString();
            //        Project = lstDatas.Rows[0]["trk_prt_ID"].ToString();
            //        Platform = lstDatas.Rows[0]["trk_plf_ID"].ToString();
            //        Page = lstDatas.Rows[0]["trk_Page"].ToString();
            //        Responsibility = lstDatas.Rows[0]["trk_Responsibility"].ToString();
            //        Resource = lstDatas.Rows[0]["trk_AssignedEmp_ID"].ToString();
            //        ExpectedEffort = lstDatas.Rows[0]["trk_ExpectedEffort"].ToString();
            //        ExpectedDelDate = lstDatas.Rows[0]["ExpectedDelDate"].ToString();
            //        Status = lstDatas.Rows[0]["Status"].ToString();

            //        lblDate.Text = Date.ToString();
            //        lblCreatedBy.Text = CreatedBy.ToString();
            //        lblTicket.Text = TicketNo.ToString();


            //        txtDesc.Text = Desc.ToString();
            //        ddlProject.SelectedValue = Project.ToString();
            //        ddlPlatform.SelectedValue = Platform.ToString();
            //        txtPage.Text = Page.ToString();
            //        // ddlResp.SelectedValue = Responsibility.ToString();
            //        ddlResource.SelectedValue = Resource.ToString();
            //        txtExpEffort.Text = ExpectedEffort.ToString();
            //        ddlExpDelDate.SelectedDate = DateTime.Parse(ExpectedDelDate.ToString());
            //        ddlStatus.SelectedValue = Status.ToString();

            //        txtExpEffort.Enabled = false;
            //        ddlExpDelDate.Enabled = false;
            //        pnl.Visible = true;
            //    }

            //}

            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx FillForm()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }
        //protected void lnkCancel_Click(object sender, EventArgs e)
        //{
        //    RefreshSession();
        //    Response.Redirect("/BO_Digits/en/ListTracker.aspx");
        //}

        protected void lnkSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveData();

            }
            catch (Exception ex)
            {

            }


        }
        protected void Save()
        {
            try
            {
                Session["trk_AssignedEmp_ID"] = ddlResource.SelectedValue.ToString();
                Session["ExpectedDelDate"] = ddlExpDelDate.SelectedDate.ToString();

                string CreatedBy, Desc,Project, Platform, Page, Responsibility, Resource, ExpectedEffort, ExpectedDelDate, Status;

                CreatedBy = UICommon.GetCurrentUserID().ToString();
                Desc = txtDesc.Text.ToString();
                Project = ddlProject.SelectedValue.ToString();
                Platform = ddlPlatform.SelectedValue.ToString();
                Page = txtPage.Text.ToString();
               // Responsibility = ddlResp.SelectedValue.ToString(); 
                Resource = ddlResource.SelectedValue.ToString(); 
                ExpectedEffort = txtExpEffort.Text.ToString(); 
                ExpectedDelDate = DateTime.Parse(ddlExpDelDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                Status = ddlStatus.SelectedValue.ToString(); 
                
                if (ResponseID.Equals("") || ResponseID == 0)
                {
                    string[] arr = { Project , Platform, Page,  Resource, ExpectedEffort, ExpectedDelDate ,CreatedBy };
                    string Value = ObjclsFrms.SaveData("sp_Transactions", "InsertTracker", Desc, arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Tracker Saved Successfully');</script>", false);
                    }
                    else if (res == 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }
                }

                else
                {
                    string ID = ResponseID.ToString();                 
                    string[] arr = {  Platform, Page, Resource, ExpectedEffort, ExpectedDelDate, CreatedBy,  Status, Project ,ID };
                    string Value = ObjclsFrms.SaveData("sp_Transactions", "UpdateTracker", Desc, arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Tracker Updated Successfully');</script>", false);
                    }
                    else if (res == 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }
                }
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx Save()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }

        protected void btnOK_Click(object sender, EventArgs e)
        {


            Response.Redirect("/BO_Digits/en/ListTracker.aspx");
        }

        protected void lnkProceed_Click(object sender, EventArgs e)
        {
            try
            {
                if (ResponseID.Equals("") || ResponseID == 0)
                {
                    DataTable dsc = (DataTable)ViewState["DataTable"];
                    if (dsc == null)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('kindly add at least one assignment and Proceed');</script>", false);
                        return;
                    }
                    else
                    {
                        SaveData();

                        //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
                    }
                }
                else
                {
                    SaveData();
                    //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);

                }
            }
            catch(Exception ex)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('"+ex.Message.ToString()+"');</script>", false);
                return;
            }

        }

        protected void ddlProject_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            try
            {
                
                Session["trk_prt_ID"] = ddlProject.SelectedValue.ToString();
                string projectId = Session["trk_prt_ID"].ToString();
                if (ResponseID.Equals("") || ResponseID == 0)
                {
                    ddlResource.Items.Clear(); // Clear items in ddlResource
                    ddlStatus.Items.Clear();
                    ddlPlatform.Text = "";
                    ddlResource.Text = "";
                }
                else
                {
                    refreshform();
                }
                ListData();
               // grvRpt.Rebind();
                Platform();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx ddlProject_SelectedIndexChanged", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }


        protected void ddlPlatform_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            try
            {
                Session["trk_prt_ID"] = ddlProject.SelectedValue.ToString();
                Session["trk_plf_ID"] = e.Value;
                string projectId = Session["trk_prt_ID"].ToString();
                string platformId = Session["trk_plf_ID"].ToString();

                ddlResource.Items.Clear(); // Clear items in ddlResource
                ddlStatus.Items.Clear();
                ddlResource.Text = "";

                Resource();
            }
            catch (Exception ex)
            {

                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx ddlPlatform_SelectedIndexChanged", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }


        }

        private void RestoreSessionValues()
        {
           
            if (Session["trk_prt_ID"] != null )
            {
                
                string selectedProject = Session["trk_prt_ID"].ToString();
                ddlProject.SelectedValue = selectedProject;               
                Platform();

              
                if (Session["trk_plf_ID"] != null) 
                {                  
                    string selectedPlatform = Session["trk_plf_ID"].ToString();
                    ddlPlatform.SelectedValue = selectedPlatform;
                    Resource();                  
                       
                }

                if (Session["trk_AssignedEmp_ID"] != null)
                {
                    string selectedResource = Session["trk_AssignedEmp_ID"].ToString();
                    ddlResource.SelectedValue = selectedResource;
                                       
                }

                if (Session["Status"] != null)
                {
                    string selectedStatus = Session["Status"].ToString();
                    ddlStatus.SelectedValue = selectedStatus;
                    Status();                                            
                }

                if (Session["ExpectedDelDate"] != null)
                {
                    DateTime selectedDate;
                    if (DateTime.TryParse(Session["ExpectedDelDate"].ToString(), out selectedDate))
                    {
                        ddlExpDelDate.SelectedDate = selectedDate;
                    }
                    else
                    {
                        ddlExpDelDate.SelectedDate = DateTime.Now;
                    }
                }

            }
        }

        protected void grvRpt_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            ListData();
        }

        protected void grvRpt_ItemCommand(object sender, GridCommandEventArgs e)
        {
            if (e.CommandName.Equals("Edit"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("trk_ID").ToString();
                string PayType = e.CommandArgument.ToString();
                Response.Redirect("AddEditTracker.aspx?Id=" + ID);
            }
            if (e.CommandName.Equals("Delete"))
            {
                ViewState["DeleteID"] = null;
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("ID").ToString();
                ViewState["delID"] = ID;
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>delConfim();</script>", false);
            }
            if (e.CommandName.Equals("MyClick1"))
            {
                try
                {
                    foreach (GridDataItem di in grvRpt.MasterTableView.Items)
                    {
                        di.BackColor = Color.Transparent;
                    }

                    GridDataItem item = grvRpt.MasterTableView.Items[Convert.ToInt32(e.CommandArgument)];
                    string ID = item.GetDataKeyValue("trk_ID").ToString();
                    string prtID = item["trk_prt_ID"].Text.ToString();
                    string plfID = item["trk_plf_ID"].Text.ToString();

                    //Session["ID"] = "";
                    //Session["ProjectID"] = "";
                    //Session["PlatformID"] = "";

                    Session["ID"] = ID.ToString();
                    Session["ProjectID"] = prtID.ToString();
                    Session["PlatformID"] = plfID.ToString();
                    item.BackColor = System.Drawing.ColorTranslator.FromHtml("#eaf8fb");

                    DataTable lstUser = default(DataTable);
                    lstUser = ObjclsFrms.loadList("SelectTrackerPointByID", "sp_Transactions", ID);
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 3 ");

                    Resource();
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);

                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 4 ");

                }
                catch (Exception ex)
                {
                    String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ActionQueue.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
                }
            }
        }
        public void ListData()
        {
            
            try
            {
                
                string Project = ddlProject.SelectedValue.ToString();
                string ProjectCondition = " ";
                if (Project=="")
                {
                    ProjectCondition = " ";
                }
                else
                {
                    ProjectCondition = " and trk_prt_ID in (" + Project + ")";
                }
                
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("SelectTracker", "sp_Transactions", ProjectCondition);
                //grvRpt.DataSource = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListTracker.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }

        protected void ddlResource_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            Status();
        }
        public void refreshform()
        {
            ddlResource.Items.Clear(); // Clear items in ddlResource
            ddlStatus.Items.Clear();   // Clear items in ddlStatus

            ddlPlatform.Text = "";
            ddlResource.Text = "";
            txtDesc.Text = "";
            txtExpEffort.Text = "";
            txtPage.Text = "";
            txtExpEffort.Enabled = true;
            ddlExpDelDate.Enabled = true;
            txtExpEffort.Text = "";
            ddlExpDelDate.SelectedDate = null;
            
        }

        public void RefreshSession()
        {
            Session["ID"] = null;
           // Session["ProjectID"] = null;
           // Session["PlatformID"] = null;
           // Session["trk_plf_ID"] = null;
            Session["trk_AssignedEmp_ID"] = null;
           // Session["trk_prt_ID"] = null;
            Session["ExpectedDelDate"] = null;
        }

        protected void lnkreset_Click(object sender, EventArgs e)
        {
            RefreshSession();
            Response.Redirect("AddEditTracker.aspx?Id=" + 0);
            
            //ddlProject.Items.Clear(); // Clear items in ddlResource
            //ddlPlatform.Items.Clear();
            //ddlProject.Text = "";
            //ddlPlatform.Text = "";
            //Project();
            //Resource();
            
        }

        protected void ddlAppResource_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {

        }

        protected void lnkAdd_Click(object sender, EventArgs e)
        {

            string platform, resource, page, effort, expdeldate ,project,desc;
            platform = ddlPlatform.SelectedValue.ToString();
            resource = ddlResource.SelectedValue.ToString();
            effort = txtExpEffort.Text.ToString();
            page = txtPage.Text.ToString();
            expdeldate = ddlExpDelDate.SelectedDate.ToString();
            project = ddlProject.SelectedValue.ToString();
           
            desc = txtDesc.Text.ToString();
            
            try
            {


                Session["platform"] = platform;
                Session["resource"] = resource;
                Session["page"] = page;
                Session["effort"] = effort;
                Session["expdeldate"] = expdeldate;
                Session["project"] = project;
                Session["desc"] = desc;

                

            }
            catch (Exception ex)
            {

                UICommon.LogException(ex, "Add Product");
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx Page_Load()", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

            //if (ViewState["DataTable"] == null)
            //{
            //    addTable();

            //}

            addTable();
            
        }
        //public void addTable()
        //{
        //    string platform, resource, platformval, resourceval, page, effort, expdeldate, expDateval, ID;
        //    int id;

        //    DataTable dts;

        //    if (ViewState["DataTable"] == null)
        //    {
        //        dts = new DataTable();
        //        dts.Columns.Add("ID");
        //        dts.Columns.Add("Platform");
        //        dts.Columns.Add("Platformval");
        //        dts.Columns.Add("Resource");
        //        dts.Columns.Add("Resourceval");
        //        dts.Columns.Add("Page");
        //        dts.Columns.Add("Effort");
        //        dts.Columns.Add("Exp.Del.Date");
        //        dts.Columns.Add("Exp.Del.DateVal");
        //    }
        //    else
        //    {
        //        dts = (DataTable)ViewState["DataTable"];
        //    }

        //    id = GetNextId(dts); // Use a function to get the next unique ID

        //    ID = id.ToString();
        //    platform = ddlPlatform.SelectedItem.Text.ToString();
        //    platformval = ddlPlatform.SelectedValue.ToString();
        //    resource = ddlResource.SelectedItem.Text.ToString();
        //    resourceval = ddlResource.SelectedValue.ToString();
        //    page = txtPage.Text.ToString();
        //    effort = txtExpEffort.Text.ToString();
        //    expDateval  = ddlExpDelDate.SelectedDate.Value.ToString();
        //    expdeldate = DateTime.Parse(ddlExpDelDate.SelectedDate.ToString()).ToString("dd-MM-yyyy");

        //    dts.Rows.Add(ID, platform, platformval, resource, resourceval, page, effort, expdeldate, expDateval);

        //    ViewState["DataTable"] = dts;
        //    Session["DataTable"] = dts; 
        //    grvRpt.DataSource = dts;
        //    grvRpt.DataBind();

        //    ddlPlatform.Text = "";
        //    ddlResource.Text = "";
        //    txtExpEffort.Text = "";
        //    txtPage.Text = "";
        //    ddlResource.ClearSelection();
        //    ddlExpDelDate.Clear();

        //}

        // Function to get the next unique ID


        public void addTable()
        {
            string platform, resource, platformval, resourceval, page, effort, expdeldate, expDateval, ID;
            int id;

            DataTable dts;

            if (ViewState["DataTable"] == null)
            {
                dts = new DataTable();
                dts.Columns.Add("ID");
                dts.Columns.Add("Platform");
                dts.Columns.Add("Platformval");
                dts.Columns.Add("Resource");
                dts.Columns.Add("Resourceval");
                dts.Columns.Add("Page");
                dts.Columns.Add("Effort");
                dts.Columns.Add("Exp.Del.Date");
                dts.Columns.Add("Exp.Del.DateVal");
            }
            else
            {
                dts = (DataTable)ViewState["DataTable"];
            }

            id = GetNextId(dts); // Use a function to get the next unique ID

            ID = id.ToString();
            platform = ddlPlatform.SelectedItem.Text.ToString();
            platformval = ddlPlatform.SelectedValue.ToString();
            resource = ddlResource.SelectedItem != null ? ddlResource.SelectedItem.Text.ToString() : string.Empty;
            resourceval = ddlResource.SelectedValue != null ? ddlResource.SelectedValue.ToString() : string.Empty;
            page = txtPage.Text.ToString();
            effort = txtExpEffort.Text.ToString();
            expDateval = ddlExpDelDate.SelectedDate.HasValue ? ddlExpDelDate.SelectedDate.Value.ToString() : string.Empty;
            expdeldate = ddlExpDelDate.SelectedDate.HasValue ? DateTime.Parse(ddlExpDelDate.SelectedDate.ToString()).ToString("yyyy-MM-dd") : string.Empty;

            dts.Rows.Add(ID, platform, platformval, resource, resourceval, page, effort, expdeldate, expDateval);

            ViewState["DataTable"] = dts;
            Session["DataTable"] = dts;
            grvRpt.DataSource = dts;
            grvRpt.DataBind();

            ddlPlatform.Text = "";
            ddlResource.Text = "";
            txtExpEffort.Text = "";
            txtPage.Text = "";
            ddlResource.ClearSelection();
            ddlExpDelDate.Clear();
        }

        private int GetNextId(DataTable dataTable)
        {
            int nextId = 1;

            if (dataTable.Rows.Count > 0)
            {
                // Find the maximum ID in the DataTable and increment it
                nextId = dataTable.AsEnumerable().Max(row => int.Parse(row["ID"].ToString())) + 1;
            }

            return nextId;
        }
        public void SaveData()
        {
            try
            {
                string project, desc, user,AssignID;
                project = ddlProject.SelectedValue.ToString();
                desc = txtDesc.Text.ToString();
                user = UICommon.GetCurrentUserID().ToString();
                AssignID = UNASSIGNID.ToString();
                if (ResponseID.Equals("") || ResponseID == 0)
                {
                    string detail = GetItemFromGrid();


                    string[] arr = { desc, detail, user, AssignID };
                    string Value = ObjclsFrms.SaveData("sp_Tracker", "InsertTracker", project, arr);
                    int res = Int32.Parse(Value.ToString());

                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Record has been saved sucessfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                    }

                   
                }
                else if (UNASSIGNID>0)
                {
                    project = ddlProject.SelectedValue.ToString();
                    desc = txtDesc.Text.ToString();
                    user = UICommon.GetCurrentUserID().ToString();
                    string detail = GetItemFromGrid();


                    string[] arr = { desc, detail, user };
                    string Value = ObjclsFrms.SaveData("sp_Tracker", "InsertTracker", project, arr);
                    int res = Int32.Parse(Value.ToString());

                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Record has been saved sucessfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                    }
                }
                else
                {
                    string ID = ResponseID.ToString();
                    project = ddlProject.SelectedValue.ToString();
                    desc = txtDesc.Text.ToString();
                    string platform = ddlPlatform.SelectedValue.ToString();
                    string resource = ddlResource.SelectedValue.ToString();
                    string page = txtPage.Text.ToString();
                    string Effort = txtExpEffort.Text.ToString();
                    //string expdate = DateTime.Parse(ddlExpDelDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                    string expdate = ddlExpDelDate.SelectedDate?.ToString("yyyyMMdd") ?? "";
                    string status = ddlStatus.SelectedValue.ToString();
                  

                    string[] arr = { desc, platform, resource, page, Effort, expdate, status, user, ID };
                    string Value = ObjclsFrms.SaveData("sp_Tracker", "UpdateTracker", project, arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Tracker Updated Successfully');</script>", false);
                    }
                    else if (res == 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('kindly add at least one assignment and Proceed');</script>", false);
                    }
                   
                    Response.Redirect("ListTracker.aspx", false);

                }


            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }


        public void SaveDatas1()
        {
            try
            {


                string project, desc, user, AssignID;
                project = ddlProject.SelectedValue.ToString();
                desc = txtDesc.Text.ToString();
                user = UICommon.GetCurrentUserID().ToString();
                AssignID = UNASSIGNID.ToString();
                if (ResponseID.Equals("") || ResponseID == 0)
                {
                    string detail = GetItemFromGrid();
                    string[] arr = { desc, detail, user , AssignID };
                    DataTable dtRes = ObjclsFrms.loadList("InsertTracker", "sp_Tracker", project, arr);
                    if (dtRes.Rows.Count > 0)
                    {
                        int res = Int32.Parse(dtRes.Rows[0]["res"].ToString());

                        if (res > 0)
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>modelsuccess('Record has been saved sucessfully');</script>", false);
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('" + dtRes.Rows[0]["Descr"].ToString() + "');</script>", false);
                        }
                    }


                }


                else if (UNASSIGNID > 0)
                {
                    try
                    {
                        project = ddlProject.SelectedValue.ToString();
                        desc = txtDesc.Text.ToString();
                        user = UICommon.GetCurrentUserID().ToString();
                        string detail = GetItemFromGrid();

                        string[] arr = { desc, detail, user };
                        DataTable dtRes = ObjclsFrms.loadList("InsertTracker", "sp_Tracker", project, arr);
                        if (dtRes.Rows.Count > 0)
                        {
                            int res = Int32.Parse(dtRes.Rows[0]["res"].ToString());

                            if (res > 0)
                            {
                                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Record has been saved sucessfully');</script>", false);
                            }
                            else
                            {
                                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('" + dtRes.Rows[0]["Descr"].ToString() + "');</script>", false);
                            }
                        }

                    }
                    catch(Exception ex)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('" +ex.Message.ToString() + "');</script>", false);
                    }

                   
                   
                }
                else
                {
                    string ID = ResponseID.ToString();
                    project = ddlProject.SelectedValue.ToString();
                    desc = txtDesc.Text.ToString();
                    string platform = ddlPlatform.SelectedValue.ToString();
                    string resource = ddlResource.SelectedValue.ToString();
                    string page = txtPage.Text.ToString();
                    string Effort = txtExpEffort.Text.ToString();
                    string expdate = DateTime.Parse(ddlExpDelDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                    string status = ddlStatus.SelectedValue.ToString();


                    string[] arr = { desc, platform, resource, page, Effort, expdate, status, user, ID };
                    string Value = ObjclsFrms.SaveData("sp_Tracker", "UpdateTracker", project, arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Tracker Updated Successfully');</script>", false);
                    }
                    else if (res == 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('kindly add at least one assignment and Proceed');</script>", false);
                    }

                    Response.Redirect("ListTracker.aspx", false);

                }


            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }
        //public string GetItemFromGrid()
        //{
        //    using (var sw = new StringWriter())
        //    {
        //        using (var writer = XmlWriter.Create(sw))
        //        {
        //            writer.WriteStartDocument(true);
        //            writer.WriteStartElement("r");
        //            int c = 0;
        //            DataTable dsc = (DataTable)ViewState["DataTable"];
        //            foreach (DataRow row in dsc.Rows)
        //            {

        //                string ID = row["ID"].ToString();
        //                string Platform = row["Platformval"].ToString();
        //                string Resource = row["Resourceval"].ToString();
        //                string Page = row["Page"].ToString();
        //                string Effort = row["Effort"].ToString();
        //               // string Date = row["Exp.Del.DateVal"].ToString();
        //                string ExpDate = DateTime.Parse(row["Exp.Del.DateVal"].ToString()).ToString("yyyyMMdd");
        //                //string uom = row["uom"].ToString();

        //                //if (Mode.Equals("0"))
        //                //{
        //                createNode(ID, Platform, Resource, Page, Effort, ExpDate, writer);
        //                //}
        //                c++;
        //            }

        //            writer.WriteEndElement();
        //            writer.WriteEndDocument();
        //            writer.Close();

        //            if (c == 0)
        //            {

        //                return null;
        //            }
        //            else
        //            {
        //                string ss = sw.ToString();
        //                return sw.ToString();
        //            }
        //        }
        //    }
        //}


        //public string GetItemFromGrid()
        //{

        //        using (var sw = new StringWriter())
        //        {
        //            using (var writer = XmlWriter.Create(sw))
        //            {
        //                writer.WriteStartDocument(true);
        //                writer.WriteStartElement("r");
        //                int c = 0;
        //                DataTable dsc = (DataTable)ViewState["DataTable"];
        //                foreach (DataRow row in dsc.Rows)
        //                {
        //                    string ID = row["ID"].ToString();
        //                    string Platform = row["Platformval"].ToString();
        //                    string Resource = row["Resourceval"] != DBNull.Value ? row["Resourceval"].ToString() : string.Empty;
        //                    string Page = row["Page"].ToString();
        //                    string Effort = row["Effort"].ToString();
        //                    string ExpDate = row["Exp.Del.Date"].ToString();

        //                // Parse Exp.Del.DateVal if it's not DBNull

        //                try
        //                {
        //                    if (row["Exp.Del.Date"] != DBNull.Value)
        //                    {
        //                        DateTime expDateParsed;
        //                        if (DateTime.TryParseExact(row["Exp.Del.Date"].ToString(), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out expDateParsed))
        //                        {
        //                            ExpDate = expDateParsed.ToString("yyyyMMdd");
        //                        }
        //                    }
        //                }
        //                catch (Exception ex)
        //                {
        //                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('" + ex.Message.ToString() + "');</script>", false);

        //                }

        //                    createNode(ID, Platform, Resource, Page, Effort, ExpDate, writer);

        //                    c++;
        //                }

        //                writer.WriteEndElement();
        //                writer.WriteEndDocument();
        //                writer.Close();

        //                if (c == 0)
        //                {
        //                    return null;
        //                }
        //                else
        //                {
        //                    return sw.ToString();
        //                }
        //            }
        //        }
        //    }



        public string GetItemFromGrid()
        {
            using (var sw = new StringWriter())
            {
                using (var writer = XmlWriter.Create(sw))
                {
                    writer.WriteStartDocument(true);
                    writer.WriteStartElement("r");
                    int c = 0;
                    DataTable dsc = (DataTable)ViewState["DataTable"];
                    foreach (DataRow row in dsc.Rows)
                    {
                        string ID = row["ID"].ToString();
                        string Platform = row["Platformval"].ToString();
                        string Resource = row["Resourceval"] != null ? row["Resourceval"].ToString() : "";
                        string Page = row["Page"].ToString();
                        string Effort = row["Effort"].ToString();
                        string ExpDate = row["Exp.Del.Date"].ToString() != null ? row["Exp.Del.Date"].ToString() : ""; 

                        // Parse Exp.Del.DateVal if it's not DBNull
                        try
                        {
                            if (row["Exp.Del.Date"] != null)
                            {

                                ExpDate =  DateTime.Parse(row["Exp.Del.Date"].ToString()).ToString("yyyyMMdd");
                            }
                        }
                        catch (Exception ex)
                        {
                            // Log the error and throw an exception with the appropriate message
                            string errorMessage = "Error parsing Exp.Del.Date: " + ex.Message;
                        }

                        createNode(ID, Platform, Resource, Page, Effort, ExpDate, writer);
                        c++;
                    }

                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                    writer.Close();

                    if (c == 0)
                    {
                        return null;
                    }
                    else
                    {
                        return sw.ToString();
                    }
                }
            }
        }



        private void createNode(string ID, string Platform, string Resource, string Page, string Effort, string ExpDate, XmlWriter writer)
        {
            writer.WriteStartElement("Values");


            writer.WriteStartElement("ID");
            writer.WriteString(ID);
            writer.WriteEndElement();

            writer.WriteStartElement("Platform");
            writer.WriteString(Platform);
            writer.WriteEndElement();

            writer.WriteStartElement("Resource");
            writer.WriteString(Resource);
            writer.WriteEndElement();

            writer.WriteStartElement("Page");
            writer.WriteString(Page);
            writer.WriteEndElement();

            writer.WriteStartElement("Effort");
            writer.WriteString(Effort);
            writer.WriteEndElement();

            writer.WriteStartElement("ExpDate");
            writer.WriteString(ExpDate);
            writer.WriteEndElement();


            writer.WriteEndElement();
        }

        protected void BtnConfrmDelete_Click(object sender, EventArgs e)
        {
            string ID = ViewState["delID"].ToString();
            DataTable dts = (DataTable)ViewState["DataTable"];
            for (int i = dts.Rows.Count - 1; i >= 0; i--)
            {
                DataRow dr = dts.Rows[i];
                string dd = dr["ID"].ToString();
                if (dr["ID"].Equals(ID))
                    dr.Delete();
            }
            dts.AcceptChanges();
            ViewState["DataTable"] = dts;
            int x = dts.Rows.Count;
            grvRpt.DataSource = dts;
            grvRpt.DataBind();
           // Uom();
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>successModal();</script>", false);

        }

        protected void lnkdelsuccess_Click(object sender, EventArgs e)
        {

        }

        protected void ProceedContinue_Click(object sender, EventArgs e)
        {
            if (ResponseID.Equals("") || ResponseID == 0)
            {
                DataTable dsc = (DataTable)ViewState["DataTable"];
                if (dsc == null)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(),
                        "tmp", "<script type='text/javascript'>Failure('Add Atleast one record');</script>", false);
                    return;
                }
                else
                {
                    SaveDatas();

                    //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
                }
            }
            else
            {
               
                    SaveDatas();

                  

            }
        }


        public void SaveDatas()
        {
            try
            {
                string project, desc, user, AssignID;
                project = ddlProject.SelectedValue.ToString();
                desc = txtDesc.Text.ToString();
                user = UICommon.GetCurrentUserID().ToString();
                AssignID = UNASSIGNID.ToString();
                if (ResponseID.Equals("") || ResponseID == 0)
                {
                    string detail = GetItemFromGrid();


                    string[] arr = { desc, detail, user, AssignID };
                    string Value = ObjclsFrms.SaveData("sp_Tracker", "InsertTracker", project, arr);
                    int res = Int32.Parse(Value.ToString());

                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess1('Record has been saved sucessfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                    }


                }
                else if (UNASSIGNID > 0)
                {
                    project = ddlProject.SelectedValue.ToString();
                    desc = txtDesc.Text.ToString();
                    user = UICommon.GetCurrentUserID().ToString();
                    string detail = GetItemFromGrid();


                    string[] arr = { desc, detail, user };
                    string Value = ObjclsFrms.SaveData("sp_Tracker", "InsertTracker", project, arr);
                    int res = Int32.Parse(Value.ToString());

                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Record has been saved sucessfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                    }
                }
                else
                {
                    string ID = ResponseID.ToString();
                    project = ddlProject.SelectedValue.ToString();
                    desc = txtDesc.Text.ToString();
                    string platform = ddlPlatform.SelectedValue.ToString();
                    string resource = ddlResource.SelectedValue.ToString();
                    string page = txtPage.Text.ToString();
                    string Effort = txtExpEffort.Text.ToString();
                    string expdate = ddlExpDelDate.SelectedDate?.ToString("yyyyMMdd") ?? "";
                    //string expdate = DateTime.Parse(ddlExpDelDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                    string status = ddlStatus.SelectedValue.ToString();


                    string[] arr = { desc, platform, resource, page, Effort, expdate, status, user, ID };
                    string Value = ObjclsFrms.SaveData("sp_Tracker", "UpdateTracker", project, arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Tracker Updated Successfully');</script>", false);
                    }
                    else if (res == 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }

                    Response.Redirect("ListTracker.aspx", false);

                }


            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditTracker.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }

      
        protected void ok_Click(object sender, EventArgs e)
        {
            RefreshSession();
            Response.Redirect("/BO_Digits/en/AddEditTracker.aspx");

        }

        protected void lnknext_Click(object sender, EventArgs e)
        {

            string ProjetID = Session["PRO_ID"].ToString();
            DataTable lstUser = default(DataTable);
            lstUser = ObjclsFrms.loadList("GetProjectUsingID", "sp_Masters", ProjetID);
            //int Res = Int32.Parse(lstUser.ToString());
            if (lstUser.Rows.Count > 0)
            {


                if (UNASSIGNID.Equals("") || UNASSIGNID == 0)
                {
                    DataTable dsc = (DataTable)ViewState["DataTable"];
                    if (dsc == null)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(),
                            "tmp", "<script type='text/javascript'>Failure('Add Atleast one record');</script>", false);
                        return;
                    }
                    else
                    {
                        SaveDatas1();

                        //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
                    }
                }
                else
                {
                    SaveDatas1();
                    //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);

                }
            }
            else
            {
                SaveDatas1();
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>pointover();</script>", false);
               
            }
        }

        protected void goback_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListUnassignTracker.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {


            string nextUnassignId = GetNextUnassignIdForProject();


            if (string.IsNullOrEmpty(nextUnassignId))
            {
                // If nextUnassignId is empty, display a message to the user

             

                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>pointover();</script>", false);
              //  ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>showSuccessToast('Record has been saved successfully');  window.location.href = 'AddUnAssignedTracker.aspx';</script>", false);

            }
            else
            {
              
                // Redirect to AddEditTracker.aspx with the next UNASSIGNID as a parameter
                Response.Redirect("AddEditTracker.aspx?UATId=" + nextUnassignId);
            }

            // Redirect to AddEditTracker.aspx with the next UNASSIGNID as a parameter
           
        }

        private void ClearFormData()
        {
            // Clear or reset form fields or any state variables holding data
            txtDesc.Text = "";
            ddlProject.Text = "";
            ddlPlatform.Text = "";
            ddlResource.Text = "";
            txtPage.Text = "";
            txtExpEffort.Text = "";
           
            // Clear other form fields as needed
        }

        private string GetNextUnassignIdForProject()
        {
            string projectId = Session["PRO_ID"].ToString();
            DataTable nextUnassignIdData = ObjclsFrms.loadList("GetProjectUsingID", "sp_Masters", projectId);

            if (nextUnassignIdData.Rows.Count > 0)
            {
                // Assuming UNASSIGNID is stored in the first row and first column of the DataTable
                return nextUnassignIdData.Rows[0][0].ToString();
            }
            else
            {
                // If no next UNASSIGNID is found, handle accordingly (e.g., display an error message)
                return ""; // or throw an exception, or handle as per your requirement
            }
        }

    }
}