﻿using Stimulsoft.Report.Dictionary;
using Stimulsoft.Report.Web;
using Stimulsoft.Report;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static Stimulsoft.Report.Func;
using System.Data;
using static Stimulsoft.Report.Help.StiHelpProvider;
using Org.BouncyCastle.Asn1.Ocsp;

namespace DigitsTracker.BO_Digits.en
{
    
    public partial class TimeAnalysis : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var s = Server.MapPath("Dashboard/license.key");
            Stimulsoft.Base.StiLicense.LoadFromFile(s);
        }

        protected void StiWebViewer1_GetReport(object sender, StiReportDataEventArgs e)
        {
         



            var report = StiReport.CreateNewReport();
            var path = Server.MapPath("Dashboard/EmployeeTracker.mrt");
            report.Load(path);
            string DB = ConfigurationManager.AppSettings.Get("MyDB");
            ((StiSqlDatabase)report.Dictionary.Databases["MS SQL"]).ConnectionString = DB;


            e.Report = report;
        }
    }
}