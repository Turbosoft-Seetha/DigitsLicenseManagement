﻿using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Metadata.Edm;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using Telerik.Web.UI;
using Telerik.Web.UI.HtmlChart;
using Telerik.Windows.Documents.Spreadsheet.Expressions.Functions;

namespace DigitsTracker.BO_Digits.en
{
	public partial class AddEditProjects : System.Web.UI.Page
	{
		GeneralFunctions ObjclsFrms = new GeneralFunctions();
		public int ResponseID
		{
			get
			{
				int ResponseID;
				int.TryParse(Request.Params["ID"], out ResponseID);

				return ResponseID;
			}
		}
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				Customer();				
				Resourse();
				Platform();
                FillForm();
            }
		}
		public void FillForm()
		{
			try
			{
				DataTable lstDatas = ObjclsFrms.loadList("SelectProjectByID", "sp_Masters", ResponseID.ToString());
				if (lstDatas.Rows.Count > 0)
				{
                    pnlDetail.Visible = true;
					string name, status, code, desc, cusID,platform,resourse;
					name = lstDatas.Rows[0]["prt_Name"].ToString();
					code = lstDatas.Rows[0]["prt_Code"].ToString();
					desc = lstDatas.Rows[0]["prt_Desc"].ToString();
					txtcode.Enabled = false;
					status = lstDatas.Rows[0]["Status"].ToString();
					cusID = lstDatas.Rows[0]["prt_cus_ID"].ToString();
                    platform= lstDatas.Rows[0]["plf_Name"].ToString();
                    resourse = lstDatas.Rows[0]["FirstName"].ToString();
                    string[] ar = platform.Split('-');

                    string[] arry = resourse.Split('-');


                    txtcode.Text = code.ToString();
					txtname.Text = name.ToString();
					txtDesc.Text = desc.ToString();
					ddlStatus.SelectedValue = status.ToString();
					ddlCustomer.SelectedValue = cusID.ToString();

                    for (int i = 0; i < ar.Length; i++)
                    {
                        foreach (RadComboBoxItem items in ddlplatform.Items)
                        {
                            if (items.Value == ar[i])
                            {
                                items.Checked = true;
                            }
                        }
                    }

                    for (int i = 0; i < arry.Length; i++)
                    {
                        foreach (RadComboBoxItem items in ddlResourse.Items)
                        {
                            if (items.Value == arry[i])
                            {
                                items.Checked = true;
                            }
                        }
                    }






                }
                else
                {
                    pnlDetail.Visible = false;
                }
			}
			catch (Exception ex)
			{
				String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
				ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditProjects.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

			}

		}
		protected void Save()
		{
			try
			{

                ViewState["PrjID"] = "";

                string name, code, user, desc, status ,cusID;

			name = txtname.Text.ToString();
			code = txtcode.Text.ToString();
			user = UICommon.GetCurrentUserID().ToString();
			desc = txtDesc.Text.ToString();
			status = ddlStatus.SelectedValue.ToString();
			cusID = ddlCustomer.SelectedValue.ToString();
                string Resourse = GetItemFromGrid1();
                string Platform = ddlplatform.SelectedValue.ToString();              
                string platformName = ddlplatform.SelectedItem.Text.ToString();

                int ResCount = 0;              
                if (!string.IsNullOrEmpty(Resourse))
                {
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(Resourse);

                    ResCount = xml.SelectNodes("//Values").Count;
                }             

            if (ResponseID.Equals("") || ResponseID == 0)
			{                   

                string[] arr = { name.ToString(), desc.ToString(), status.ToString(), user.ToString(), cusID.ToString(), Resourse, Platform.ToString() };
				string Value = ObjclsFrms.SaveData("sp_Masters", "InsertProject", code.ToString(), arr);
                   
				int res = Int32.Parse(Value.ToString());
				if (res > 0)
				{
                        ViewState["PrjID"] = Value.ToString();
                     // pnlDetail.Visible = true;
                        grvRpt.Rebind();
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>showSuccessToast('" + ResCount + " Resources added to Platform (" + platformName + ") for Project (" + code + "-" + name + " ) successfully '); window.location.href = 'AddEditProjects.aspx?ID=" + ResponseID + "';</script>", false);

                    }
                    else
				{
                        pnlDetail.Visible = false;
					ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
				}
			}

			else
			{
				string id = ResponseID.ToString();
                    ViewState["PrjID"] = id.ToString();
                    string[] arr = { code.ToString(), name.ToString(), desc.ToString(), status.ToString(), cusID.ToString(),  Platform.ToString(), Resourse, user.ToString() };
				string Value = ObjclsFrms.SaveData("sp_Masters", "UpdateProject", id.ToString(),  arr);
				int res = Int32.Parse(Value.ToString());
				if (res > 0)

				{
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>showSuccessToast('" + ResCount + " Resources added to Platform (" + platformName + ") for Project (" + code + "-" + name + " ) successfully '); window.location.href = 'AddEditProjects.aspx?ID=" + ResponseID + "';</script>", false);

                    }
                    else  if (res == 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail('You cannot assign same resource for the same platform of same project for the second time');</script>", false);

                    }

                    else
				{
					ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
				}
			}
			}
			catch (Exception ex)
			{
				String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
				ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditProjects.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

			}
		}

        public string GetItemFromGrid1()
        {
            using (var sw = new StringWriter())
            {
                using (var writer = XmlWriter.Create(sw))
                {
                    writer.WriteStartDocument(true);
                    writer.WriteStartElement("r");

                    var ColelctionMarkets = ddlResourse.CheckedItems;
                    int c = 0;

                    foreach (var item in ColelctionMarkets)
                    {
                        // Ensure each selected item is treated separately
                        createNode1(item.Value, writer);
                        c++;
                    }

                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                    writer.Close();

                    if (c == 0)
                    {
                        return "";
                    }
                    else
                    {
                        string ss = sw.ToString();
                        return sw.ToString();
                    }
                }
            }
        }

        private void createNode1(string ID, XmlWriter writer)
        {
            writer.WriteStartElement("Values");


            writer.WriteStartElement("ID");
            writer.WriteString(ID);
            writer.WriteEndElement();



            writer.WriteEndElement();
        }

        public string GetResourseFromDrop()
        {
            using (var sw = new StringWriter())
            {
                using (var writer = XmlWriter.Create(sw))
                {
                    writer.WriteStartDocument(true);
                    writer.WriteStartElement("Resources");

                    foreach (RadComboBoxItem item in ddlResourse.CheckedItems)
                    {
                        createNodeForComboBox(item.Value, item.Text, writer);
                    }

                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                    writer.Close();

                    return sw.ToString();
                }
            }
        }

        // Example method to create a node for RadComboBox items in XML
        private void createNodeForComboBox(string value, string text, XmlWriter writer)
        {
            writer.WriteStartElement("Resource");

            writer.WriteStartElement("emp_ID");
            writer.WriteString(value);
            writer.WriteEndElement();

            writer.WriteStartElement("emp_txt");
            writer.WriteString(text);
            writer.WriteEndElement();

            writer.WriteEndElement();
        }


        public string GetPlatformFromDrop()
        {
            using (var sw = new StringWriter())
            {
                using (var writer = XmlWriter.Create(sw))
                {
                    writer.WriteStartDocument(true);
                    writer.WriteStartElement("r");
                    int c = 0;



                    // Retrieve selected items from RadComboBox
                    foreach (RadComboBoxItem item in ddlplatform.Items)
                    {
                        if (item.Checked)
                        {
                            createNode(item.Value, item.Text, writer);
                            c++; // Incrementing counter for selected RadComboBox items
                        }
                    }

                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                    writer.Close();

                    if (c == 0)
                    {
                        return "";
                    }
                    else
                    {
                        return sw.ToString();
                    }
                }
            }
        }

        // Example method to create a node for RadComboBox items in XML
        private void createNode(string value, string text, XmlWriter writer)
        {
            writer.WriteStartElement("Values");

            writer.WriteStartElement("Platfrm_ID");
            writer.WriteString(value);
            writer.WriteEndElement();

            writer.WriteStartElement("Platfrm_txt");
            writer.WriteString(text);
            writer.WriteEndElement();





            writer.WriteEndElement();
        }


        protected void save_Click(object sender, EventArgs e)
		{
			Save();
		}

		protected void btnOK_Click(object sender, EventArgs e)
		{
			Response.Redirect("AddEditProjects.aspx?Id=" + ViewState["PrjID"].ToString());
		}

		protected void lnkAdd_Click(object sender, EventArgs e)
		{
            Save();
           // ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
		}

		protected void lnkCancel_Click(object sender, EventArgs e)
		{
			Response.Redirect("ListProjects.aspx");
		}

		protected void txtcode_TextChanged(object sender, EventArgs e)
		{
			try
			{

			string code = this.txtcode.Text.ToString();
			DataTable lstCodeChecker = ObjclsFrms.loadList("CheckProjectCode", "sp_Masters", code);
			if (lstCodeChecker.Rows.Count > 0)
			{
				lblCodeDupli.Text = "Code Already Exist";
				LinkButton1.Enabled = false;
				lblCodeDupli.Visible = true;
			}
			else
			{
                    LinkButton1.Enabled = true;
				lblCodeDupli.Visible = false;
			}

			}
			catch (Exception ex)
			{
				String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
				ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditProjects.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

			}

		}
		protected void ddlcus_TextChanged(object sender, EventArgs e)
		{

		}
		public void Customer()
		{
			try
			{
				string[] arr = { ResponseID.ToString() };
				DataTable dt = ObjclsFrms.loadList("SelectCustomer", "sp_Masters");
				ddlCustomer.DataSource = dt;
				ddlCustomer.DataTextField = "cus_Name";
				ddlCustomer.DataValueField = "cus_ID";
				ddlCustomer.DataBind();
			}
			catch (Exception ex)
			{
				String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
				ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditProjects.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

			}
		}


        public void Resourse()
        {
            try
            {
                string[] ar = { ddlplatform.SelectedValue.ToString() };
                DataTable dt = ObjclsFrms.loadList("SelectResourse", "sp_Masters", ResponseID.ToString(),ar);
                ddlResourse.DataSource = dt;
                ddlResourse.DataTextField = "FirstName";
                ddlResourse.DataValueField = "ID";
                ddlResourse.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditProjects.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }

        public void Platform()
        {
            try
            {
                string[] arr = { ResponseID.ToString() };
                DataTable dt = ObjclsFrms.loadList("SelectPlatform", "sp_Masters");
                ddlplatform.DataSource = dt;
                ddlplatform.DataTextField = "plf_Name";
                ddlplatform.DataValueField = "plf_ID";
                ddlplatform.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditProjects.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }
        public void LoadList()
        {
            try
            {
                string prjctID;
                if (ResponseID > 0)
                {
                    pnlDetail.Visible = true;
                    prjctID=ResponseID.ToString();
                }
                else
                {
                    prjctID = ViewState["PrjID"].ToString();
                }
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("ListResourcePlatform", "sp_Masters", prjctID);
                grvRpt.DataSource = lstUser;
                if(ResponseID == 0 || ResponseID.ToString()=="")
                { 
                
                }

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditProjects.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }
        protected void grvRpt_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            LoadList();
        }

        protected void ddlplatform_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            Resourse();
        }

        protected void grvRpt_ItemCommand(object sender, GridCommandEventArgs e)
        {
            
            if (e.CommandName.Equals("Delete"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("epl_ID").ToString();
                ViewState["delID"] = ID;
                BtnConfrmDelete_Click();

            }
        }

        protected void BtnConfrmDelete_Click()
        {
            string ID = ViewState["delID"].ToString();
            string[] arr = { ID.ToString() };
            string Value = ObjclsFrms.SaveData("sp_Masters", "DeleteResourcePlatform", ResponseID.ToString(), arr);
            int res = Int32.Parse(Value.ToString());

            if (res > 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>showSuccessToast2('Resource Platform Mapping Deleted ');</script>", false);

            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail('Can't Delete!');</script>", false);


            }
        }
       


    }
}