﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace DigitsTracker.BO_Digits.en
{
    public partial class ReopenPoints : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " ------------------------- Starts pageload------------");
                if (Session["ID"] == null)
                {
                    Session["ID"] = "";
                    Session["ProjectID"] = "";
                    Session["PlatformID"] = "";

                }


                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 1 ");
                Resource();
                Resourses();

              


                try
                {
                    if (Session["RPRid"] != null)
                    {
                        int a = rdResourse.Items.Count;
                        string res = Session["RPRid"].ToString();
                        string[] ar = res.Split(',');
                        for (int i = 0; i < ar.Length; i++)
                        {
                            foreach (RadComboBoxItem items in rdResourse.Items)
                            {
                                if (items.Value == ar[i])
                                {
                                    items.Checked = true;
                                }
                            }
                        }


                    }
                    else
                    {
                        string res = Res();
                        string routeCondition = " trk_AssignedEmp_ID in (" + res + ")";



                    }

                    //invType

                }
                catch (Exception ex)
                {

                }
                try
                {
                    GetGridSession(grvRpt, "RO");

                    grvRpt.Rebind();
                }

                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");

                }
            }
        }

        public void GetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                string filterExpression = string.Empty;

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        if (Session[SessionPrefix + columnName] != null)

                        {

                            string filterValue = Session[SessionPrefix + columnName].ToString();



                            if (filterValue != "")
                            {

                                column.CurrentFilterValue = filterValue;



                                if (!string.IsNullOrEmpty(filterExpression))

                                {

                                    filterExpression += " AND ";

                                }

                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);

                            }

                        }

                    }

                }

                if (filterExpression != string.Empty)

                {

                    grvRpt.MasterTableView.FilterExpression = filterExpression;

                }



            }

            catch (Exception ex)

            {



            }

        }

        public void HeaderData()
        {
            string Id = Session["ID"].ToString();
            DataTable lstDatas = new DataTable();
            lstDatas = ObjclsFrms.loadList("ListTrackerLifeCycleByID", "sp_Transactions", Id);
            if (lstDatas.Rows.Count > 0)
            {
                RadPanelItem rp = RadPanelBar0.Items[0];

                Label lblTracker = (Label)rp.FindControl("lblTracker");
                Label lblRes = (Label)rp.FindControl("lblRes");
                Label lblDec = (Label)rp.FindControl("lblDec");
                Label lblpage = (Label)rp.FindControl("lblpage");
                Label lblPlf = (Label)rp.FindControl("lblPlf");
                Label lblEffort = (Label)rp.FindControl("lblEffort");




                lblTracker.Text = lstDatas.Rows[0]["trk_TicketNumber"].ToString();
                lblRes.Text = lstDatas.Rows[0]["Resource"].ToString();
                lblDec.Text = lstDatas.Rows[0]["trk_Desc"].ToString();
                lblpage.Text = lstDatas.Rows[0]["trk_Page"].ToString();
                lblPlf.Text = lstDatas.Rows[0]["plf_Name"].ToString();
                lblEffort.Text = lstDatas.Rows[0]["trk_ExpectedEffort"].ToString();


            }
        }

        public void ListData()
        {
            try
            {
                string mainCondition = "";
                mainCondition = mainConditions();
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("SelectReopenpoint", "sp_Transactions", mainCondition);
                grvRpt.DataSource = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ReopenPoints.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }

        public void SetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        string filterValue = column.CurrentFilterValue;

                        Session[SessionPrefix + columnName] = filterValue;

                    }

                }

            }

            catch (Exception ex)

            {




            }



        }

        public string mainConditions()
        {

            string Resourse = Res();


            string mainCondition = "";
            string ResourseCondition = "";
            try
            {


                if (Resourse.Equals("0"))
                {
                    ResourseCondition = "";
                }
                else
                {
                    ResourseCondition = " and trk_AssignedEmp_ID in (" + Resourse + ")";
                }

            }
            catch (Exception ex)
            {

            }
            mainCondition += ResourseCondition;
            return mainCondition;
        }

        public string Res()
        {
            var CollectionMarket = rdResourse.CheckedItems;
            string ResID = "";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        ResID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        ResID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        ResID += item.Value;
                    }
                    j++;
                }
                return ResID;
            }
            else
            {
                return "trk_AssignedEmp_ID";
            }

        }

        protected void lnkFilter_Click(object sender, EventArgs e)
        {
            try
            {



                if (Session["RPRid"] != null)
                {
                    string resourse = Res();
                    if (resourse == Session["RPRid"].ToString())
                    {
                        string res = Res();

                    }
                    else
                    {
                        string res = Res();
                        Session["RPRid"] = res;
                    }


                }
                else
                {
                    string res = Res();
                    Session["RPRid"] = res;
                }


            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");

            }
            ListData();
            grvRpt.Rebind();
        }

        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            ListData();
        }

        public void Resourses()
        {
            rdResourse.DataSource = ObjclsFrms.loadList("SelectResourseforTransaction", "sp_Transactions");
            rdResourse.DataTextField = "FirstName";
            rdResourse.DataValueField = "ID";
            rdResourse.DataBind();
        }
        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "RO");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");

            }
            if (e.CommandName.Equals("Edit"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("trk_ID").ToString();
                string PayType = e.CommandArgument.ToString();
                Response.Redirect("AddEditReopenPoints.aspx?Id=" + ID);
            }
            if (e.CommandName.Equals("LifeCycle"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("trk_ID").ToString();
                Response.Redirect("TrackerLifeCycleROP.aspx?Id=" + ID);
            }

            if (e.CommandName.Equals("MyClick1"))
            {
                try
                {
                    foreach (GridDataItem di in grvRpt.MasterTableView.Items)
                    {
                        di.BackColor = Color.Transparent;
                    }

                    GridDataItem item = grvRpt.MasterTableView.Items[Convert.ToInt32(e.CommandArgument)];
                    string ID = item.GetDataKeyValue("trk_ID").ToString();
                    string prtID = item["trk_prt_ID"].Text.ToString();
                    string plfID = item["trk_plf_ID"].Text.ToString();
                    string res = item["Resource"].Text.ToString();

                    if (res == "&nbsp;")
                    {
                        pnlEffort.Visible = false;
                        lblAddEffort.Visible = false;
                    }
                    else
                    {
                        pnlEffort.Visible = true;
                        lblAddEffort.Visible = true;

                    }
                    AdditionalEffort(ID);

                    //Session["ID"] = "";
                    //Session["ProjectID"] = "";
                    //Session["PlatformID"] = "";

                    Session["ID"] = ID.ToString();
                    Session["ProjectID"] = prtID.ToString();
                    Session["PlatformID"] = plfID.ToString();
                    item.BackColor = System.Drawing.ColorTranslator.FromHtml("#eaf8fb");

                    DataTable lstUser = default(DataTable);
                    lstUser = ObjclsFrms.loadList("SelectTrackerPointByID", "sp_Transactions", ID);
                    string resource = lstUser.Rows[0]["trk_AssignedEmp_ID"].ToString();
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 3 ");

                    Resource();
                    HeaderData();
                    ddlResource.SelectedValue = resource;


                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);

                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 4 ");

                }
                catch (Exception ex)
                {
                    String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ReopenPoints.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
                }

            }
        }
            protected void btnSave_Click(object sender, EventArgs e)
            {
                try
                {
                    string User, Resource, ID, Effort;

                    User = UICommon.GetCurrentUserID().ToString();
                    Resource = ddlResource.SelectedValue.ToString();
                    ID = Session["ID"].ToString();
                    Effort = txtAddEffort.Value.ToString();

                    string[] arr = { Resource, User, Effort };
                    DataTable lstUser = default(DataTable);
                    lstUser = ObjclsFrms.loadList("UpdateResource", "sp_Transactions", ID.ToString(), arr);
                    string res = lstUser.Rows[0]["Res"].ToString();
                    // int res = Int32.Parse(Value.ToString());
                    if (lstUser.Rows.Count > 0)
                    {
                        if (res == "1")
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Tracker updated successfully');</script>", false);
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('Something went wrong, please try again later.');</script>", false);
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('Something went wrong, please try again later.');</script>", false);
                    }

                }
                catch (Exception ex)
                {
                    String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ReopenPoints.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
                }
            }

        public void AdditionalEffort(string ID)
        {
            DataTable lstData = default(DataTable);
            lstData = ObjclsFrms.loadList("SelAdditionalEffort", "sp_Transactions", ID);


            if (lstData.Rows.Count > 0)
            {
                EffortGrid.DataSource = lstData;
                EffortGrid.DataBind();

            }
            else
            {
                EffortGrid.DataSource = new DataTable();
                EffortGrid.DataBind();
            }

        }
        public void Resource()
        {
            try
            {
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 2 ");


                string projectId = Session["ProjectID"].ToString();
                string platformId = Session["PlatformID"].ToString();
                string[] arr = { platformId.ToString() };
                ddlResource.DataSource = ObjclsFrms.loadList("SelResourceForDropdown", "sp_Transactions", projectId, arr);
                ddlResource.DataTextField = "Name";
                ddlResource.DataValueField = "ID";
                ddlResource.DataBind();
            }
            catch (Exception ex)
            {
                // Handle exceptions if needed
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ReopenPoints.aspx Resource()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/ReopenPoints.aspx");
        }

    }
}