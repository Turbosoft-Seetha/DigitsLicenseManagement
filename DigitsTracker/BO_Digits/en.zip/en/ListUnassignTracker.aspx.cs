﻿using GoogleApi.Entities.Common.Enums;
using Org.BouncyCastle.Asn1.Ocsp;
using ProcessExcel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Services.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using Telerik.Web.UI.Chat;

namespace DigitsTracker.BO_Digits.en
{
    public partial class ListUnassignTracker : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Project();
                string proID = pro();
                string project = " epl_prt_ID in (" +proID+ ")";
                Platforms(project);

                try
                {
                    if (Session["LUTProjectID"] != null)
                    {
                        string[] projectIDs = Session["LUTProjectID"].ToString().Split(',');
                        foreach (RadComboBoxItem item in rdproject.Items)
                        {
                            if (projectIDs.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                        }

                        project = " epl_prt_ID in (" + string.Join(",", projectIDs) + ")";
                        Platforms(project);
                    }
                    else
                    {
                        string pID = pro();
                        string routeCondition = " uat_prt_ID in (" + pID + ")";
                    }

                    if (Session["LUTPlatformID"] != null)
                    {
                        string platformID = Session["LUTPlatformID"].ToString();
                        foreach (RadComboBoxItem item in rdPlatform.Items)
                        {
                            if (platformID.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                            else
                            {
                                item.Checked = false;
                            }
                        }

                    }
                    else
                    {
                        string pID = pro();
                        string routeCondition = " trk_plf_ID in (" + pID + ")";
                    }
                }
                catch (Exception ex)
                {
                   
                }


                try
                {
                    GetGridSession(grvRpt, "LUT");

                    grvRpt.Rebind();
                }

                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }
            }

        }

        public void Project()
        {
            rdproject.DataSource = ObjclsFrms.loadList("SelectProjectforTransaction", "sp_Transactions");
            rdproject.DataTextField = "project";
            rdproject.DataValueField = "prt_ID";
            rdproject.DataBind();
        }

        public void Platforms(string project)
        {
            rdPlatform.DataSource = ObjclsFrms.loadList("SelectPlatformforTransaction", "sp_Transactions", project);
            rdPlatform.DataTextField = "plf_Name";
            rdPlatform.DataValueField = "epl_plf_ID";
            rdPlatform.DataBind();
        }        

        public void LoadList()
        {
            try
            {
                string mainCondition = "";
                mainCondition = mainConditions();
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("ListUnAsssignTracker", "sp_Tracker", mainCondition);
                grvRpt.DataSource = lstUser;
                Session["lstTracker"] = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListUnassignTracker.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }
        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            LoadList();
        }

        protected void lnkFilter_Click(object sender, EventArgs e)
        {
            try
            {
                string projectID = pro();
                Session["LUTProjectID"] = projectID;
                string platformID = plf();
                Session["LUTPlatformID"] = platformID;
                
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");

            }
            LoadList();
            grvRpt.Rebind();
        }

        public string mainConditions()
        {
            string Project = pro();
            string Platform = plf();
            string mainCondition = "";            
            string ProjectCondition = "";
            string PlatformCondition = "";
            try
            {
                if (Project.Equals("0"))
                {
                    ProjectCondition = "";
                }
                else
                {
                    ProjectCondition = " and uat_prt_ID in (" +Project+ ")";
                }

                if (Platform.Equals("0"))
                {
                    PlatformCondition = "";
                }
                else
                {
                    PlatformCondition = " and uat_plf_ID in (" +Platform+ ")";
                }

            }
            catch (Exception ex)
            {

            }
            mainCondition += ProjectCondition;
            mainCondition += PlatformCondition;
            return mainCondition;
        }
        public string pro()
        {
            var CollectionMarket = rdproject.CheckedItems;
            string ProID = "";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        ProID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        ProID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        ProID += item.Value;
                    }
                    j++;
                }
                return ProID;
            }
            else
            {
                return "uat_prt_ID";
            }

        }

        public string plf()
        {
            var CollectionMarket = rdPlatform.CheckedItems;
            string plfID = "";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        plfID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        plfID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        plfID += item.Value;
                    }
                    j++;
                }
                return plfID;
            }
            else
            {
                return "uat_plf_ID";
            }

        }        
        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "LUT");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }

            if (e.CommandName.Equals("MyClick1"))
            {
                try
                {
                    foreach (GridDataItem di in grvRpt.MasterTableView.Items)
                    {
                        di.BackColor = Color.Transparent;
                    }

                    GridDataItem item = grvRpt.MasterTableView.Items[Convert.ToInt32(e.CommandArgument)];
                    item.BackColor = System.Drawing.ColorTranslator.FromHtml("#eaf8fb");
                    string ID = item.GetDataKeyValue("uat_ID").ToString();
                    Response.Redirect("AddEditTracker.aspx?UATId=" + ID);
                }
                catch (Exception ex)
                {
                    String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListUnassignTracker.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
                }
            }

            if (e.CommandName.Equals("Delete"))
            {

                ViewState["DeleteID"] = null;
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("uat_ID").ToString();
                ViewState["delID"] = ID;

                string Descn = dataItem["uat_Desc"].Text.ToString();
                string PLFm = dataItem["plf_Name"].Text.ToString();
              
                string Projects = dataItem["prt_Name"].Text.ToString();
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>delConfim('" + Projects + "','" + PLFm + "','" + Descn + "');</script>", false);

            }
            if (e.CommandName.Equals("Hold"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;               
                string uat_ID = dataItem.GetDataKeyValue("uat_ID").ToString();
                ViewState["uat_ID"] = uat_ID;
                string Desc = dataItem["uat_Desc"].Text.ToString();
                string PLF = dataItem["plf_Name"].Text.ToString();
               
                string Project = dataItem["prt_Name"].Text.ToString();

                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>HoldConfim('" + Project + "','" + Desc + "','" + PLF + "');</script>", false);
            }
        }

        protected void btnHold_Confirm_Click(object sender, EventArgs e)
        {
            string ID = ViewState["uat_ID"].ToString();
            string User = UICommon.GetCurrentUserID().ToString();
            string Priority = txtpriority.Text.ToString();
            string[] arr = { User.ToString(), Priority };
            string Value = ObjclsFrms.SaveData("sp_Tracker", "HoldPointsFromUAT", ID, arr);

            int res = Int32.Parse(Value.ToString());

            if (res > 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>showSuccessToast('Point has been hold successfully');  window.location.href = 'ListUnassignTracker.aspx';</script>", false);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
            }

        }

        protected void BtnAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddUnAssignedTracker.aspx?Id=0");
        }
        
        public void SetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        string filterValue = column.CurrentFilterValue;

                        Session[SessionPrefix + columnName] = filterValue;

                    }

                }

            }

            catch (Exception ex)

            {




            }



        }
        public void GetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                string filterExpression = string.Empty;

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        if (Session[SessionPrefix + columnName] != null)

                        {

                            string filterValue = Session[SessionPrefix + columnName].ToString();



                            if (filterValue != "")
                            {

                                column.CurrentFilterValue = filterValue;



                                if (!string.IsNullOrEmpty(filterExpression))

                                {

                                    filterExpression += " AND ";

                                }

                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);

                            }

                        }

                    }

                }

                if (filterExpression != string.Empty)

                {

                    grvRpt.MasterTableView.FilterExpression = filterExpression;

                }



            }

            catch (Exception ex)

            {



            }

        }

        protected void BtnConfrmDelete_Click(object sender, EventArgs e)
        {
            string ID = ViewState["delID"].ToString();
            string User  = UICommon.GetCurrentUserID().ToString();
            string Value = ObjclsFrms.SaveData("sp_Tracker", "ClosePoints", ID);

            int res = Int32.Parse(Value.ToString());

            if (res > 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>showSuccessToast('Point closed successfully');  window.location.href = 'ListUnassignTracker.aspx';</script>", false);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
            }

        }

        protected void ok_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/ListUnassignTracker.aspx");

        }

        public void TotalPoints()
        {
            try
            {
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("ListUnAsssignTrackertotalPoints", "sp_Tracker");
                TotalTime.DataSource = lstUser;
                Session["lstData"] = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListUnassignTracker.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }

        protected void TotalTime_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            TotalPoints();
        }

        protected void TotalTime_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "LUT");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }

            if (e.CommandName == "ProjectClick")

            {

                foreach (GridDataItem di in TotalTime.MasterTableView.Items)
                {
                    di.BackColor = Color.Transparent;
                }
                int clickedIndex = Convert.ToInt32(e.CommandArgument);

               

                // Access the clicked row using masterTableView.Items
                GridDataItem clickedItem = TotalTime.MasterTableView.Items[clickedIndex] as GridDataItem;
                clickedItem.BackColor = System.Drawing.ColorTranslator.FromHtml("#eaf8fb");

                if (clickedItem != null)
                {
                    string projectID = clickedItem["prt_ID"].Text;
                    DataTable lstUser = ObjclsFrms.loadList("ListUnAsssignTrackerByProject", "sp_Tracker", projectID);
                    grvRpt.DataSource = lstUser;
                    grvRpt.Rebind();
                    
                }
            }
        }

        protected void SummaryReset_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ClearGridFilterConditions(TotalTime, "LUT");
                DataTable dt = (DataTable)Session["lstData"];
                if (dt.Rows.Count > 0)
                {
                    TotalTime.DataSource = dt;
                    TotalTime.DataBind();
                }
                else
                {
                    TotalTime.DataSource = null;
                    TotalTime.DataBind();
                }

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListUnassignTracker.aspx", "ItemsData() Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        private void ClearGridFilterConditions(RadGrid grd, string SessionPrefix)
        {
            try
            {
                foreach (GridColumn column in grd.MasterTableView.Columns)
                {
                    if (column is GridBoundColumn boundColumn)
                    {
                        string columnName = boundColumn.UniqueName;
                        column.CurrentFilterValue = string.Empty;

                        Session[SessionPrefix + columnName] = null;
                    }
                }
                grd.MasterTableView.FilterExpression = string.Empty;
            }
            catch (Exception ex)
            {


            }

        }

        protected void TrackerReset_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ClearGridFilterConditions(grvRpt, "LUT");
                foreach (RadComboBoxItem item in rdproject.Items)
                {
                    item.Checked = false;
                }
                foreach (RadComboBoxItem item in rdPlatform.Items)
                {
                    item.Checked = false;
                }
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("ListUnAsssignTracker", "sp_Tracker");
                grvRpt.DataSource = lstUser;
                grvRpt.DataBind();
                Session["lstTracker"] = lstUser;

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListUnassignTracker.aspx", "ItemsData() Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        protected void grvRpt_ItemDataBound(object sender, GridItemEventArgs e)
        {
            try
            {
                if (e.Item is GridDataItem)
                {
                    GridDataItem item = (GridDataItem)e.Item;
                    string Status = item["sts_Name"].Text;
                    ImageButton holdButton = (ImageButton)item.FindControl("HoldButton");

                    if  (Status=="Hold")
                    {
                        item.Style["background-color"] = "#FFFFCC";
                        holdButton.Enabled = false;
                        holdButton.ImageUrl = "../assets/media/icons/hold.svg"; 
                        holdButton.ToolTip = "Hold option is disabled";
                    }                   
                    else
                    {
                        item.Style["background-color"] = "#FFFFFF00";
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        protected void rdproject_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            string proID = pro();
            if (proID.Equals("epl_prt_ID"))
            {
                proID = "0";
            }
            string project = " epl_prt_ID in (" +proID+ ")";
            Platforms(project);
        }


    }
        
}