﻿using System;
using System.Data;
using System.Web.UI;
using Telerik.Web.UI;
using System.Drawing;
using ProcessExcel;
using Org.BouncyCastle.Asn1.Ocsp;
using System.Web.UI.WebControls;
using System.Diagnostics.Eventing.Reader;
using Telerik.Windows.Documents.Spreadsheet.Expressions.Functions;
using Convert = System.Convert;
using System.Linq;

namespace DigitsTracker.BO_Digits.en
{
    public partial class ListTracker : System.Web.UI.Page
    {
       
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {


                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " ------------------------- Starts pageload------------");
                ViewState["Filter"] = "";
                if (Session["ID"] == null)
                {
                    Session["ID"] = "";
                    Session["ProjectID"] = "";
                    Session["PlatformID"] = "";

                }


                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 1 ");

                Project();
                string proID = pro();
                string project = " epl_prt_ID in (" +proID+ ")";
                Platforms(project);
                string plfID = plf();
                string platform = " and epl_plf_ID in (" +plfID+ ")";
                Resourses(project, platform);

                Session["lstTracker"] = "";                             
                try
                {
                    if (Session["LTFDate"] != null)
                    {

                        rdfromDate.SelectedDate = DateTime.Parse(Session["LTFDate"].ToString());
                    }
                    else
                    {
                        rdfromDate.SelectedDate = DateTime.Now;

                    }                  
                   
                }
                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }


                try
                {
                    if (Session["LTProjectID"] != null)
                    {
                        string[] projectIDs = Session["LTProjectID"].ToString().Split(',');
                        foreach (RadComboBoxItem item in rdproject.Items)
                        {
                            if (projectIDs.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                            else
                            {
                                item.Checked = false;
                            }
                        }

                        project = " epl_prt_ID in (" + string.Join(",", projectIDs) + ")";
                        Platforms(project);
                    }
                    else
                    {
                        string pID = pro();
                        string routeCondition = " trk_prt_ID in (" +pID+ ")";
                    }

                    if (Session["LTPlatformID"] != null)
                    {
                        string projectID = Session["LTProjectID"].ToString();
                        foreach (RadComboBoxItem item in rdproject.Items)
                        {
                            if (projectID.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                            else
                            {
                                item.Checked = false;
                            }
                        }

                        project = " epl_prt_ID in (" +projectID+ ")";
                        Platforms(project);

                        string platformID = Session["LTPlatformID"].ToString();
                        foreach (RadComboBoxItem item in rdPlatform.Items)
                        {
                            if (platformID.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                            else
                            {
                                item.Checked = false;
                            }
                        }

                        platform = " and epl_plf_ID in (" +platformID+ ")";
                        Resourses(project, platform);
                    }
                    else
                    {
                        string pID = pro();
                        string routeCondition = " trk_plf_ID in (" +pID+ ")";
                    }

                    if (Session["LTResources"] != null)
                    {
                        string[] selectedResourceIDs = Session["LTResources"].ToString().Split(',');
                        foreach (RadComboBoxItem item in rdResourse.Items)
                        {
                            if (selectedResourceIDs.Contains(item.Value))
                            {
                                item.Checked = true;
                            }
                            else
                            {
                                item.Checked = false;
                            }
                        }
                    }

                    else
                    {
                        string res = Res();
                        string routeCondition = " trk_AssignedEmp_ID in (" + res + ")";
                    }
                }
                catch (Exception ex)
                {

                }
                ListData();
                try
                {
                    GetGridSession(grvRpt, "LT");                   
                    grvRpt.Rebind();
                   
                }

                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");

                }             
            }
        }
     

        public void HeaderData()
        {
           string ID = Session["ID"].ToString();
            DataTable lstDatas = new DataTable();
            lstDatas = ObjclsFrms.loadList("ListTrackerLifeCycleByID", "sp_Transactions", ID.ToString());
            if (lstDatas.Rows.Count > 0)
            {
                RadPanelItem rp = RadPanelBar0.Items[0];

                Label lblTracker = (Label)rp.FindControl("lblTracker");
                Label lblRes = (Label)rp.FindControl("lblRes");
                Label lblDec = (Label)rp.FindControl("lblDec");
                Label lblpage = (Label)rp.FindControl("lblpage");
                Label lblPlf = (Label)rp.FindControl("lblPlf");
                Label lblEffort = (Label)rp.FindControl("lblEffort");

                lblTracker.Text = lstDatas.Rows[0]["trk_TicketNumber"].ToString();
                lblRes.Text = lstDatas.Rows[0]["Resource"].ToString();
                lblDec.Text = lstDatas.Rows[0]["trk_Desc"].ToString();
                lblpage.Text = lstDatas.Rows[0]["trk_Page"].ToString();
                lblPlf.Text = lstDatas.Rows[0]["plf_Name"].ToString();
                lblEffort.Text = lstDatas.Rows[0]["trk_ExpectedEffort"].ToString();

            }
        }
        public void Platforms(string project)
        {
            rdPlatform.DataSource = ObjclsFrms.loadList("SelectPlatformforTransaction", "sp_Transactions", project);
            rdPlatform.DataTextField = "plf_Name";
            rdPlatform.DataValueField = "epl_plf_ID";
            rdPlatform.DataBind();
        }
        public void Resourses(string project, string platform)
        {
            string[] arr = { platform.ToString() };
            rdResourse.DataSource = ObjclsFrms.loadList("SelectResourseforTransaction", "sp_Transactions", project, arr);
            rdResourse.DataTextField = "FirstName";
            rdResourse.DataValueField = "ID";
            rdResourse.DataBind();
        }
        public void Resource()
        {
            try
            {
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 2 ");
                string projectId = Session["ProjectID"].ToString();
                string platformId = Session["PlatformID"].ToString();
                string[] arr = { platformId.ToString() };
                ddlResource.DataSource = ObjclsFrms.loadList("SelResourceForDropdown", "sp_Transactions", projectId, arr);
                ddlResource.DataTextField = "Name";
                ddlResource.DataValueField = "ID";
                ddlResource.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListTracker.aspx Resource()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }
        public void ListData()
        {
            try
            {
                string mainCondition = "";
                mainCondition = mainConditions();
                DataTable lstUser = default(DataTable);
               
                lstUser = ObjclsFrms.loadList("SelectTracker", "sp_Transactions", mainCondition);
                grvRpt.DataSource = lstUser;
               // grvRpt.DataBind();
                Session["lstTracker"] = lstUser;
                

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListTracker.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }



        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            ListData();
        }
       

        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;
                SetGridSession(grd, "LT");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }

            if (e.CommandName.Equals("Delete"))
            {

                ViewState["DeleteID"] = null;
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("trk_ID").ToString();
                ViewState["delID"] = ID;

                string Descn = dataItem["trk_Desc"].Text.ToString();
                string PLFm = dataItem["Platform"].Text.ToString();
                string effort = dataItem["trk_ExpectedEffort"].Text.ToString();
                string date = dataItem["ExpectedDelDate"].Text.ToString();
                string Projects = dataItem["Project"].Text.ToString();
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>delConfim('" + Projects + "','" + PLFm + "','" + Descn + "');</script>", false);

            }

            if (e.CommandName.Equals("Edit"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("trk_ID").ToString();
                string PayType = e.CommandArgument.ToString();
                Response.Redirect("AddEditTracker.aspx?Id=" + ID);
            }
            if (e.CommandName.Equals("LifeCycle"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string ID = dataItem.GetDataKeyValue("trk_ID").ToString();
                Response.Redirect("TrackerLifeCycle.aspx?Id=" + ID);
            }

            if (e.CommandName.Equals("MyClick1"))
            {
                try
                {
                    foreach (GridDataItem di in grvRpt.MasterTableView.Items)
                    {
                        di.BackColor = Color.Transparent;
                    }

                    GridDataItem item = grvRpt.MasterTableView.Items[Convert.ToInt32(e.CommandArgument)];
                    string ID = item.GetDataKeyValue("trk_ID").ToString();
                    string prtID = item["trk_prt_ID"].Text.ToString();
                    string plfID = item["trk_plf_ID"].Text.ToString();
                    string res = item["Resource"].Text.ToString();
                    
                    AdditionalEffort(ID);

                    Session["ID"] = ID.ToString();
                    Session["ProjectID"] = prtID.ToString();
                    Session["PlatformID"] = plfID.ToString();
                    item.BackColor = System.Drawing.ColorTranslator.FromHtml("#eaf8fb");

                    DataTable lstUser = default(DataTable);
                    lstUser = ObjclsFrms.loadList("SelectTrackerPointByID", "sp_Transactions", ID);
                    string resource = lstUser.Rows[0]["trk_AssignedEmp_ID"].ToString();
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 3 ");

                    Resource();
                    HeaderData();
                    ddlResource.SelectedValue = resource;
                    

                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);                   
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 4 ");

                }
                catch (Exception ex)
                {
                    String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ActionQueue.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
                }

            }
            if (e.CommandName.Equals("Hold"))
            {
                GridDataItem dataItem = e.Item as GridDataItem;
                string trk_ID = dataItem.GetDataKeyValue("trk_ID").ToString();
                ViewState["trk_ID"] = trk_ID;
               
                string Desc = dataItem["trk_Desc"].Text.ToString();
                string PLF = dataItem["Platform"].Text.ToString();
                string effort = dataItem["trk_ExpectedEffort"].Text.ToString(); 
               string date = dataItem["ExpectedDelDate"].Text.ToString();
                string Project = dataItem["Project"].Text.ToString();



                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>HoldConfim('" + Project + "','" + Desc + "','" + PLF + "');</script>", false);
            }
        }
        protected void BtnAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddEditTracker.aspx?Id=0");
        }


        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string User, Resource, ID, Effort;

                User = UICommon.GetCurrentUserID().ToString();
                Resource = ddlResource.SelectedValue.ToString();
                ID = Session["ID"].ToString();
                Effort = txtAddEffort.Value.ToString();

                string[] arr = { Resource, User, Effort };
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("UpdateResource", "sp_Transactions", ID.ToString(), arr);
                string res = lstUser.Rows[0]["Res"].ToString();
                // int res = Int32.Parse(Value.ToString());
                if (lstUser.Rows.Count > 0)
                {
                    if (res == "1")
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Tracker updated successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('Something went wrong, please try again later.');</script>", false);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure('Something went wrong, please try again later.');</script>", false);
                }

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListTracker.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

       

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("/BO_Digits/en/ListTracker.aspx");
        }

        public void Resourses()
        {
            rdResourse.DataSource = ObjclsFrms.loadList("SelectresforTracker", "sp_Transactions");
            rdResourse.DataTextField = "FirstName";
            rdResourse.DataValueField = "ID";
            rdResourse.DataBind();


            RadComboBoxItem unassignedItem = new RadComboBoxItem("Un Assigned", "NULL");
            unassignedItem.Selected = false;
            rdResourse.Items.Insert(0, unassignedItem);

        }


        public void Project()
        {
            rdproject.DataSource = ObjclsFrms.loadList("SelectProjectforTransaction", "sp_Transactions");
            rdproject.DataTextField = "project";
            rdproject.DataValueField = "prt_ID";
            rdproject.DataBind();
        }


        public string mainConditions()
        {
           
            string Resourse = Res();
            string Project = pro();
            string Platform = plf();
            string dateCondition = "";
            string mainCondition = "";
            string ResourseCondition = "";
            string ProjectCondition = "";
            string PlatformCondition = "";
            try
            {
                string fromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                if (ViewState["Filter"].ToString().Equals("Yes"))
                {
                    dateCondition = " and ( cast(trk_ExpectedDelDate as date) <= cast('" + fromDate + "' as date))";

                }
                else
                {
                    dateCondition = " and ( trk_ExpectedDelDate IS NULL OR cast(trk_ExpectedDelDate as date) <= cast('" + fromDate + "' as date))";

                }

                if (string.IsNullOrEmpty(Resourse) || Resourse.ToUpper() == " NULL,NULL")
                {
                    ResourseCondition = " AND trk_AssignedEmp_ID IS NULL";
                }
                else
                {
                    ResourseCondition = " AND (trk_AssignedEmp_ID IN (" +Resourse+ ")  OR  trk_AssignedEmp_ID IS NULL )";
                }

                if (Project.Equals("0"))
                {
                    ProjectCondition = "";
                }
                else
                {
                    ProjectCondition = " and trk_prt_ID in (" +Project+ ")";
                }
                if (Platform.Equals("0"))
                {
                    PlatformCondition = "";
                }
                else
                {
                    PlatformCondition = " and trk_plf_ID in (" +Platform+ ")";
                }

            }
            catch (Exception ex)
            {

            }
            mainCondition += ProjectCondition;
            mainCondition += ResourseCondition;
            mainCondition += PlatformCondition;
            mainCondition += dateCondition;

            return mainCondition;
        }

        public string Res()
        {
            var CollectionMarket = rdResourse.CheckedItems;
            string ResID = "";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        ResID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        ResID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        ResID += item.Value;
                    }
                    j++;
                }
                return ResID;
            }
            else
            {
                return "trk_AssignedEmp_ID";
            }

        }


        public string pro()
        {
            var CollectionMarket = rdproject.CheckedItems;
            string ProID = "";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        ProID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        ProID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        ProID += item.Value;
                    }
                    j++;
                }
                return ProID;
            }
            else
            {
                return "trk_prt_ID";
            }

        }
        public string plf()
        {
            var CollectionMarket = rdPlatform.CheckedItems;
            string plfID = "";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        plfID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        plfID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        plfID += item.Value;
                    }
                    j++;
                }
                return plfID;
            }
            else
            {
                return "trk_plf_ID";
            }

        }
        protected void lnkFilter_Click(object sender, EventArgs e)
        {
            try
            {
                ViewState["Filter"] = "Yes";
                if (Session["LTFDate"] != null)
                {
                    string fromdate = rdfromDate.SelectedDate.ToString();
                    if (fromdate == Session["LTFDate"].ToString())
                    {
                        rdfromDate.SelectedDate = (DateTime)Session["LTFDate"];
                    }
                    else
                    {
                        Session["LTFDate"] = rdfromDate.SelectedDate;
                    }
                }
                else
                {
                    //rdfromDate.SelectedDate = DateTime.Now;
                    Session["LTFDate"] = rdfromDate.SelectedDate;
                }

              //  rdfromDate.MaxDate = DateTime.Now;

                string projectID = pro();
                Session["LTProjectID"] = projectID;
                string platformID = plf();
                Session["LTPlatformID"] = platformID;
                string selectedResources = Res();
                Session["LTResources"] = selectedResources;

          
                ListData();
                grvRpt.Rebind();
                TotalTime.Rebind();
            }
            catch (Exception ex)
            {

            }
        }


        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            string mainCondition = "";
            mainCondition = mainConditions();
            DataTable dt = default(DataTable);
            dt = ObjclsFrms.loadList("ListTrackerForExcel", "sp_Transactions", mainCondition);
            BuildExcel excel = new BuildExcel();
            byte[] output = excel.SpreadSheetProcess(dt, "ListTracker");
            Response.ContentType = ContentType;
            Response.Headers.Remove("Content-Disposition");
            Response.AppendHeader("Content-Disposition", string.Format("attachment; filename={0}.{1}", "ListTracker", "Xlsx"));
            Response.BinaryWrite(output);
            Response.End();
        }

        public void AdditionalEffort(string ID)
        {
            DataTable lstData = default(DataTable);
            lstData = ObjclsFrms.loadList("SelAdditionalEffort", "sp_Transactions", ID);
            if (lstData.Rows.Count > 0)
            {
                EffortGrid.DataSource = lstData;
                EffortGrid.DataBind();
            }
            else
            {
                EffortGrid.DataSource = new DataTable();
                EffortGrid.DataBind();
            }
        }

        public void GetGridSession(RadGrid grd, string SessionPrefix)
        {
            try
            {
                string filterExpression = string.Empty;
                foreach (GridColumn column in grd.MasterTableView.Columns)
                {                    
                    if (column is GridBoundColumn boundColumn)
                    {
                        string columnName = boundColumn.UniqueName;
                        if (Session[SessionPrefix + columnName] != null)
                        {
                            string filterValue = Session[SessionPrefix + columnName].ToString();
                            if (filterValue != "")
                            {
                                column.CurrentFilterValue = filterValue;
                                if (!string.IsNullOrEmpty(filterExpression))
                                {
                                    filterExpression += " AND ";
                                }                                
                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);
                            }
                        }
                    }
                }
                if (filterExpression != string.Empty)
                {                    
                    grd.MasterTableView.FilterExpression = filterExpression;                   
                }
            }
            catch (Exception ex)
            {
            }            
        }
        public void SetGridSession(RadGrid grd, string SessionPrefix)
        {
            try
            {
                foreach (GridColumn column in grd.MasterTableView.Columns)
                {
                    if (column is GridBoundColumn boundColumn)
                    {
                        string columnName = boundColumn.UniqueName;
                        string filterValue = column.CurrentFilterValue;
                        Session[SessionPrefix + columnName] = filterValue;
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        protected void TotalTime_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            TotalEmployeeEffort();
        }

        protected void TotalTime_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;
                SetGridSession(grd, "LT");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }

            if (e.CommandName == "EmployeeClick")
            {
                foreach (GridDataItem di in TotalTime.MasterTableView.Items)
                {
                    di.BackColor = Color.Transparent;
                }

                int clickedIndex = Convert.ToInt32(e.CommandArgument);
               
                GridDataItem clickedItem = TotalTime.MasterTableView.Items[clickedIndex] as GridDataItem;
                clickedItem.BackColor = System.Drawing.ColorTranslator.FromHtml("#eaf8fb");

                if (clickedItem != null)
                {
                    string employeeID = clickedItem["ID"].Text;
                    string mainCondition = "";
                    mainCondition = mainConditions3();
                    string[] arr = { mainCondition.ToString() };
                    DataTable lstUser = ObjclsFrms.loadList("SelectTrackerByEmployee", "sp_Transactions", employeeID, arr);
                    grvRpt.DataSource = lstUser;                    
                    grvRpt.Rebind();
                }
            }
        }
        public string mainConditions2()
        {

            string Resourse = Res();
            string Project = pro();
            string Platform = plf();
            string dateCondition = "";
            string mainCondition = "";
            string ResourseCondition = "";
            string ProjectCondition = "";
            string PlatformCondition = "";
            try
            {
                string fromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                if (ViewState["Filter"].ToString().Equals("Yes"))
                {
                    dateCondition = " and (  cast(trk_ExpectedDelDate as date) <= cast('" + fromDate + "' as date))";

                }
                else
                {
                    dateCondition = " and ( trk_ExpectedDelDate IS NULL OR cast(trk_ExpectedDelDate as date) <= cast('" + fromDate + "' as date))";

                }

                if (string.IsNullOrEmpty(Resourse) || Resourse.ToUpper() == " NULL,NULL")
                {
                    ResourseCondition = " AND trk_AssignedEmp_ID IS NULL";
                }
                else
                {
                    ResourseCondition = " AND (trk_AssignedEmp_ID IN (" + Resourse + ")  )";
                }

                if (Project.Equals("0"))
                {
                    ProjectCondition = "";
                }
                else
                {
                    ProjectCondition = " and trk_prt_ID in (" + Project + ")";
                }
                if (Platform.Equals("0"))
                {
                    PlatformCondition = "";
                }
                else
                {
                    PlatformCondition = " and trk_plf_ID in (" + Platform + ")";
                }

            }
            catch (Exception ex)
            {

            }
            mainCondition += ProjectCondition;
            mainCondition += ResourseCondition;
            mainCondition += PlatformCondition;
            mainCondition += dateCondition;

            return mainCondition;
        }



        public string mainConditions3()
        {

            string Resourse = Res();
            string Project = pro();
            string Platform = plf();
            string dateCondition = "";
            string mainCondition = "";
            string ResourseCondition = "";
            string ProjectCondition = "";
            string PlatformCondition = "";
            try
            {
                string fromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                if (ViewState["Filter"].ToString().Equals("Yes"))
                {
                    dateCondition = " and (  cast(trk_ExpectedDelDate as date) <= cast('" + fromDate + "' as date))";

                }
                else
                {
                    dateCondition = " and ( trk_ExpectedDelDate IS NULL OR cast(trk_ExpectedDelDate as date) <= cast('" + fromDate + "' as date))";

                }

                if (string.IsNullOrEmpty(Resourse) || Resourse.ToUpper() == " NULL,NULL")
                {
                    ResourseCondition = " AND trk_AssignedEmp_ID IS NULL";
                }
                else
                {
                    ResourseCondition = " AND (trk_AssignedEmp_ID IN (" + Resourse + ")  )";
                }

                if (Project.Equals("0"))
                {
                    ProjectCondition = "";
                }
                else
                {
                    ProjectCondition = " and trk_prt_ID in (" + Project + ")";
                }
                if (Platform.Equals("0"))
                {
                    PlatformCondition = "";
                }
                else
                {
                    PlatformCondition = " and trk_plf_ID in (" + Platform + ")";
                }

            }
            catch (Exception ex)
            {

            }
            mainCondition += ProjectCondition;
            mainCondition += ResourseCondition;
            mainCondition += PlatformCondition;
            mainCondition += dateCondition;

            return mainCondition;
        }
        public string mainConditionsUndated()
        {

            string Resourse = Res();
            string Project = pro();
            string Platform = plf();
            string dateCondition = "";
            string mainCondition = "";
            string ResourseCondition = "";
            string ProjectCondition = "";
            string PlatformCondition = "";
            try
            {
                string fromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                dateCondition = " and ( trk_ExpectedDelDate IS NULL )";
                if (string.IsNullOrEmpty(Resourse) || Resourse.ToUpper() == " NULL,NULL")
                {
                    ResourseCondition = " AND trk_AssignedEmp_ID IS NULL";
                }
                else
                {
                    ResourseCondition = " AND (trk_AssignedEmp_ID IN (" + Resourse + ")  )";
                }

                if (Project.Equals("0"))
                {
                    ProjectCondition = "";
                }
                else
                {
                    ProjectCondition = " and trk_prt_ID in (" + Project + ")";
                }
                if (Platform.Equals("0"))
                {
                    PlatformCondition = "";
                }
                else
                {
                    PlatformCondition = " and trk_plf_ID in (" + Platform + ")";
                }

            }
            catch (Exception ex)
            {

            }
            mainCondition += ProjectCondition;
            mainCondition += ResourseCondition;
            mainCondition += PlatformCondition;
            mainCondition += dateCondition;

            return mainCondition;
        }
        public void TotalEmployeeEffort()
        {
            try
            {
                string mainCondition = "";
                mainCondition = mainConditions2();
                DataTable lstUser = default(DataTable);

                lstUser = ObjclsFrms.loadList("SelEmployeeEffort", "sp_Transactions", mainCondition);
                TotalTime.DataSource = lstUser;
                Session["lstData"] = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListTracker.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }

        protected void SummaryReset_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ClearGridFilterConditions(TotalTime, "LT");
                DataTable dt = (DataTable)Session["lstData"];
                if (dt.Rows.Count > 0)
                {
                    TotalTime.DataSource = dt;
                    TotalTime.DataBind();
                }
                else
                {
                    TotalTime.DataSource = null;
                    TotalTime.DataBind();
                }                
               
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListTracker.aspx", "ItemsData() Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        private void ClearGridFilterConditions(RadGrid grd, string SessionPrefix)
        {
            try
            {
                foreach (GridColumn column in grd.MasterTableView.Columns)
                {
                    if (column is GridBoundColumn boundColumn)
                    {
                        string columnName = boundColumn.UniqueName;                        
                        column.CurrentFilterValue = string.Empty;                       
                        Session[SessionPrefix + columnName] = null;
                    }
                }
                grd.MasterTableView.FilterExpression = string.Empty;
            }
            catch (Exception ex)
            {
               
            }
        }

        protected void TrackerReset_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ClearGridFilterConditions(grvRpt, "LT");
                string mainCondition = "";
                //rdproject.ClearSelection();
                //rdPlatform.ClearSelection();
                //rdResourse.ClearSelection();
                //Session["LTProjectID"] = "";
                //Session["LTPlatformID"] = "";
                //Session["LTResources"] = "";
                ViewState["Filter"] = "";
                foreach (RadComboBoxItem item in rdResourse.Items)
                {
                    item.Checked = false;
                }

                foreach (RadComboBoxItem item in rdproject.Items)
                {
                    item.Checked = false;
                }
                foreach (RadComboBoxItem item in rdPlatform.Items)
                {
                    item.Checked = false;
                }
                mainCondition = mainConditions();
                DataTable lstUser = default(DataTable);

                lstUser = ObjclsFrms.loadList("SelectTracker", "sp_Transactions", mainCondition);
                grvRpt.DataSource = lstUser;
                grvRpt.DataBind();
                Session["lstTracker"] = lstUser;

                DataTable lstUser2 = default(DataTable);
                string mainCondition2 = "";
                mainCondition2 = mainConditions2();
                lstUser2 = ObjclsFrms.loadList("SelEmployeeEffort", "sp_Transactions", mainCondition2);
                TotalTime.DataSource = lstUser2;
                TotalTime.DataBind();
                Session["lstData"] = lstUser2;

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListTracker.aspx", "ItemsData() Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }

        protected void grvRpt_ItemDataBound(object sender, GridItemEventArgs e)
        {
            try
            {
                if (e.Item is GridDataItem)
                {
                    GridDataItem item = (GridDataItem)e.Item;
                    string actualEffortText = item["trk_ActualEffort"].Text;
                    string expectedEffortText = item["trk_ExpectedEffort"].Text;
                    string dueDateText = item["ExpectedDelDate"].Text;
                    string today = DateTime.Now.ToString("dd-MMM-yyyy");

                    decimal actualEffort;
                    decimal expectedEffort;

                    if (actualEffortText == "&nbsp;")
                    {
                        actualEffortText = "0";
                    }

                    if (!decimal.TryParse(actualEffortText, out actualEffort))
                    {
                        Console.WriteLine("Error parsing Actual Effort: " + actualEffortText);
                        return;
                    }

                    if (!decimal.TryParse(expectedEffortText, out expectedEffort))
                    {
                        Console.WriteLine("Error parsing Expected Effort: " + expectedEffortText);
                        return;
                    }

                    if (!string.IsNullOrEmpty(dueDateText))
                    {
                        DateTime dueDate = DateTime.Parse(dueDateText);

                        // Check if the due date is before today's date
                        if (dueDate < DateTime.Today && actualEffort == 0)
                        {
                            item.Style["background-color"] = "#ffffe0";
                           
                            return; // Exit early if due date condition is met
                        }
                    }

                    // If due date condition is not met, proceed with other color conditions
                    if (actualEffort > expectedEffort)
                    {
                        item.Style["background-color"] = "#ffffe0";
                        item["trk_TicketNumber"].Style["color"] = "red";

                    }
                    else if (actualEffort < expectedEffort && actualEffort != 0)
                    {
                        item.Style["background-color"] = "#ffffe0";

                        item["trk_TicketNumber"].Style["color"] = "#70e300";
                    }
                    else if (actualEffort == expectedEffort)
                    {
                        item.Style["background-color"] = "#ffffe0";

                        item["trk_TicketNumber"].Style["color"] = "Blue";
                    }
                    else
                    {
                        item.Style["background-color"] = "#FFFFFF00";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the exception
            }
        }


        protected void XLdownlod_Click(object sender, ImageClickEventArgs e)
        {
            string mainCondition = "";
            mainCondition = mainConditions();
            DataTable dt = default(DataTable);
            dt = ObjclsFrms.loadList("SelEmployeeEffortforXL", "sp_Transactions", mainCondition);

            BuildExcel excel = new BuildExcel();
            byte[] output = excel.SpreadSheetProcess(dt, "ListTracker");
            Response.ContentType = ContentType;
            Response.Headers.Remove("Content-Disposition");
            Response.AppendHeader("Content-Disposition", string.Format("attachment; filename={0}.{1}", "ListTracker", "Xlsx"));
            Response.BinaryWrite(output);
            Response.End();
        }

        protected void btnHold_Confirm_Click(object sender, EventArgs e)
        {

            string ID = ViewState["trk_ID"].ToString();
            DataTable lstUser = default(DataTable);

            lstUser = ObjclsFrms.loadList("SelectStatusforpreviouse", "sp_Transactions", ID);
            string prvStatus = lstUser.Rows[0]["sts_Name"].ToString();
           

            string User = UICommon.GetCurrentUserID().ToString();
            string Priority = txtpriority.Text.ToString();
            string[] arr = { User.ToString() , prvStatus, Priority };
            string Value = ObjclsFrms.SaveData("sp_Tracker", "HoldPointsFromTracker", ID, arr);
            int res = Int32.Parse(Value.ToString());

            if (res > 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>showSuccessToast('Point has been hold successfully');  window.location.href = 'ListUnassignTracker.aspx';</script>", false);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
            }
        }

        protected void rdproject_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            string proID = pro();
            if (proID.Equals("epl_prt_ID"))
            {
                proID = "0";
            }
            string project = " epl_prt_ID in (" + proID + ")";
            Platforms(project);
        }

        protected void rdPlatform_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            string proID = pro();
            if (proID.Equals("epl_prt_ID"))
            {
                proID = "0";
            }
            string project = " epl_prt_ID in (" + proID + ")";
            string plfID = plf();
            if (plfID.Equals("epl_plf_ID"))
            {
                plfID = "0";
            }
            string platform = " and epl_plf_ID in (" + plfID + ")";
            Resourses(project, platform);
        }

        protected void BtnConfrmDelete_Click(object sender, EventArgs e)
        {
            string ID = ViewState["delID"].ToString();
            string User = UICommon.GetCurrentUserID().ToString();
            string Value = ObjclsFrms.SaveData("sp_Transactions", "ClosePoints", ID);

            int res = Int32.Parse(Value.ToString());

            if (res > 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>showSuccessToast('Point closed successfully');  window.location.href = 'ListTracker.aspx';</script>", false);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Fail();</script>", false);
            }
        }

        protected void NonDelDate_Click(object sender, EventArgs e)
        {
            try
            {
                string mainCondition = "";
                mainCondition = mainConditionsUndated();
                DataTable lstUser = default(DataTable);

                lstUser = ObjclsFrms.loadList("SelectTracker", "sp_Transactions", mainCondition);
                grvRpt.DataSource = lstUser;
                grvRpt.DataBind();
                Session["lstTracker"] = lstUser;


            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ListTracker.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }
        }
    }
}