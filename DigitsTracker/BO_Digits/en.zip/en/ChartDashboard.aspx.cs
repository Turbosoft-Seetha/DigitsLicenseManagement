﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Documents.SpreadsheetStreaming;
using Telerik.Web.UI;
using static Telerik.Web.Apoc.Render.Pdf.PdfRendererOptions;
using Telerik.Windows.Documents.Spreadsheet.Expressions.Functions;
using System.Drawing;
using Convert = System.Convert;
using System.Security.Cryptography;
using GoogleApi.Entities.Search.Video.Common;

namespace DigitsTracker.BO_Digits.en
{
    public partial class ChartDashboard : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        public int Mode
        {
            get
            {
                int Mode;
                int.TryParse(Request.Params["mode"], out Mode);

                return Mode;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

                TimeLineStripe();


              
              
                   
                    try
                    {
                        if (Session["CDFDate"] != null)
                        {

                            rdfromDate.SelectedDate = DateTime.Parse(Session["CDFDate"].ToString());
                        }
                        else
                        {
                            rdfromDate.SelectedDate = DateTime.Now;

                        }
                       

                        if (Session["CDTDate"] != null)
                        {

                            rdendDate.SelectedDate = DateTime.Parse(Session["CDTDate"].ToString());
                        }
                        else
                        {
                            rdendDate.SelectedDate = DateTime.Now;

                        }
                        rdendDate.MaxDate = DateTime.Now;
                    }
                    catch (Exception ex)
                    {
                        Response.Redirect("~/SignIn.aspx");
                    }
                    
                    try
                    {
                        GetGridSession(grvRpt, "CD");

                        grvRpt.Rebind();
                    }

                    catch (Exception ex)
                    {
                        Response.Redirect("~/SignIn.aspx");
                    }
                

               


            }
        }

        public void LoadData()
        {

            string mainCondition = "";

            mainCondition = mainConditions();
            DataTable lstDatas = new DataTable();
            DataTable lstDatas2 = new DataTable();
            lstDatas = ObjclsFrms.loadList("SelEmployeeActualEffort", "sp_Transactions", mainCondition); 
            grvRpt.DataSource = lstDatas;

            lstDatas2 = ObjclsFrms.loadList("SelNonWorkedEmployee", "sp_Transactions", mainCondition);
            RadGrid1.DataSource = lstDatas2;



           
          



        }


        public void LoadData1(string ID)
        {

            




            string fromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
           // string endDate = DateTime.Parse(rdendDate.SelectedDate.ToString()).ToString("dd-MMM-yyyy");
            DataTable lstDatas3 = new DataTable();
            string[] arr = { ID };
            lstDatas3 = ObjclsFrms.loadList("selectimesheetindashboard", "sp_Transactions", fromDate, arr);
            RadGrid2.DataSource = lstDatas3;
            RadGrid2.DataBind();



        }

        public string mainConditions()
        {

            string dateCondition = "";        
            string mainCondition = "";
            try
            {
                string fromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("dd-MMM-yyyy");
                string endDate = DateTime.Parse(rdendDate.SelectedDate.ToString()).ToString("dd-MMM-yyyy");
                dateCondition = "  between cast('" + fromDate + "' as date) and cast('" + endDate + "' as date)) ";                

            }
            catch (Exception ex)
            {

            }
            mainCondition += dateCondition;            
            return mainCondition;
        }


        public void TimeLineStripe()
        {
          
                DataTable lstActive = ObjclsFrms.loadList("TrackerCounts", "sp_Dashboard");
                int overdue = Int32.Parse(lstActive.Rows[0]["TotOverDuePointsToday"].ToString());
                int due = Int32.Parse(lstActive.Rows[0]["TotDuePointsToday"].ToString());
            int open = Int32.Parse(lstActive.Rows[0]["TotOpenPoints"].ToString());
            int hold = Int32.Parse(lstActive.Rows[0]["TotHoldPoints"].ToString());
            int totaltracker = Int32.Parse(lstActive.Rows[0]["TotTrackerTickets"].ToString());


            lblOverdue.Text = overdue.ToString();
            lblduetoday.Text = due.ToString();
            lblopen.Text = open.ToString();
            lblhold.Text = hold.ToString();
            lblalltickets.Text = totaltracker.ToString();
          

            DataTable lstProductive = ObjclsFrms.loadList("UnAssignedTrackerCount", "sp_Dashboard");
                int unassigned = Int32.Parse(lstProductive.Rows[0]["TotUnAssignedPoints"].ToString());
            lblunassigned.Text = unassigned.ToString();
              
            
          
        }


        protected void lnkDOwnload_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["CDFDate"] != null)
                {
                    string fromdate = rdfromDate.SelectedDate.ToString();
                    if (fromdate == Session["CDFDate"].ToString())
                    {
                        rdfromDate.SelectedDate = DateTime.Parse(Session["CDFDate"].ToString());
                    }
                    else
                    {
                        Session["CDFDate"] = DateTime.Parse(rdfromDate.SelectedDate.ToString());
                    }
                }
                else
                {
                  
                    Session["CDFDate"] = DateTime.Parse(rdfromDate.SelectedDate.ToString());

                }
                rdfromDate.MaxDate = DateTime.Now;

                if (Session["CDTDate"] != null)
                {
                    string todate = rdendDate.SelectedDate.ToString();
                    if (todate == Session["CDTDate"].ToString())
                    {
                        rdendDate.SelectedDate = DateTime.Parse(Session["CDTDate"].ToString());
                    }
                    else
                    {
                        Session["CDTDate"] = DateTime.Parse(rdendDate.SelectedDate.ToString());
                    }

                }
                else
                {
                    rdendDate.SelectedDate = DateTime.Parse(rdendDate.SelectedDate.ToString());
                    Session["CDTDate"] = DateTime.Parse(rdendDate.SelectedDate.ToString());
                }
                rdendDate.MaxDate = DateTime.Now.AddDays(1);
            }
            catch (Exception)
            {
                Response.Redirect("~/SignIn.aspx");
            }
            LoadData();
            LoadData1(ID);
            grvRpt.Rebind();
            RadGrid1.Rebind();
            RadGrid2.Rebind();
        }

        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            LoadData();

        }

        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "CD");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/SignIn.aspx");
            }

            if (e.CommandName.Equals("MyClick1"))
            {
               
                try
                {

                    foreach (GridDataItem di in grvRpt.MasterTableView.Items)
                    {
                        di.BackColor = Color.Transparent;
                    }

                    int clickedIndex = Convert.ToInt32(e.CommandArgument);

                    GridDataItem clickedItem = grvRpt.MasterTableView.Items[clickedIndex] as GridDataItem;
                    clickedItem.BackColor = System.Drawing.ColorTranslator.FromHtml("#eaf8fb");

                    GridDataItem item = grvRpt.MasterTableView.Items[Convert.ToInt32(e.CommandArgument)];
                    string ID = item["ID"].Text.ToString();

                    LoadData1( ID);
                   



                }
                catch (Exception ex)
                {
                    String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                    ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "ReadyForTesting.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
                }

            }

        }


       
        public void SetGridSession(RadGrid grd, string SessionPrefix)
        {
            try
            {
                foreach (GridColumn column in grd.MasterTableView.Columns)
                {
                    if (column is GridBoundColumn boundColumn)
                    {
                        string columnName = boundColumn.UniqueName;
                        string filterValue = column.CurrentFilterValue;
                        Session[SessionPrefix + columnName] = filterValue;                        
                    }
                }
            }

            catch (Exception ex)
            {
                Response.Redirect("~/SignIn.aspx");
            }



        }
        public void GetGridSession(RadGrid grd, string SessionPrefix)
        {            
            try
            {
                string filterExpression = string.Empty;
                foreach (GridColumn column in grd.MasterTableView.Columns)
                {                    
                    if (column is GridBoundColumn boundColumn)
                    {
                        string columnName = boundColumn.UniqueName;
                        if (Session[SessionPrefix + columnName] != null)
                        {
                            string filterValue = Session[SessionPrefix + columnName].ToString();                            
                            if (filterValue != "")
                            {
                                column.CurrentFilterValue = filterValue;
                                if (!string.IsNullOrEmpty(filterExpression))
                                {
                                    filterExpression += " AND ";
                                }
                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);
                            }
                        }
                    }
                }
                if (filterExpression != string.Empty)
                {
                    grvRpt.MasterTableView.FilterExpression = filterExpression;
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("~/SignIn.aspx");
            }            
        }

        protected void RadGrid1_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            LoadData();
        }

        protected void RadGrid1_ItemCommand(object sender, GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "CD");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/SignIn.aspx");
            }
        }

      
    }
}