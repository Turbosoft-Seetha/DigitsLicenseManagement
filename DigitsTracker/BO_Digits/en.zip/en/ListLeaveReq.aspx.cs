﻿using ProcessExcel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using Telerik.Web.UI;
using Telerik.Web.UI.Chat;

namespace DigitsTracker.BO_Digits.en
{
    public partial class ListLeaveReq : System.Web.UI.Page
    {
        GeneralFunctions obj = new GeneralFunctions();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

                try
                {
                    
                    GetGridSession(grvRpt, "LVL");

                    //grvRpt.Rebind();
                }

                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }
            }
        }

       

            public void LoadList()
        {
            try
            {
                string userID = UICommon.GetCurrentUserID().ToString();
                DataTable lstUser = default(DataTable);
                lstUser = obj.loadList("ListLeaveRequest", "sp_Masters", userID);
                grvRpt.DataSource = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                obj.LogMessageToFile(UICommon.GetLogFileName(), "ListLeaveReq.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }


        //public void LeaveType()
        //{
        //    string userID = Session["ID"].ToString();
        //    DataTable lstUser = default(DataTable);
        //    lstUser = obj.loadList("ListLeaveRequestForID", "sp_Masters", userID);

        //    if (lstUser.Rows.Count > 0)
        //    {
        //        RadPanelItem rp = RadPanelBar0.Items[0];

        //        Label lblLeaveType = (Label)rp.FindControl("lblLeaveType");

        //        lblLeaveType.Text = lstUser.Rows[0]["atd_Status"].ToString();
              

        //    }

          





        //}

        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            LoadList();
        }

        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "LVL");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }

            if (e.CommandName.Equals("MyClick1"))
            {
                try
                {

                    foreach (GridDataItem di in grvRpt.MasterTableView.Items)
                    {
                        di.BackColor = Color.Transparent;
                    }

                    GridDataItem item = grvRpt.MasterTableView.Items[Convert.ToInt32(e.CommandArgument)];
                    string ID = item.GetDataKeyValue("lvr_ID").ToString();
                    Session["ID"] = ID.ToString();
                    //Status();
                   // LeaveType();

                    DataTable lstApprovalLevel = obj.loadList("Selectleavereqapprovals", "sp_Masters", UICommon.GetCurrentUserID().ToString());
                    if (lstApprovalLevel.Rows.Count > 0)
                    {
                        int currentLevel, nextLevel;
                        currentLevel = Int32.Parse(lstApprovalLevel.Rows[0]["CurrentLevel"].ToString());
                        nextLevel = Int32.Parse(lstApprovalLevel.Rows[0]["NextLevel"].ToString());
                        ViewState["currentLevel"] = currentLevel.ToString();
                        ViewState["nextLevel"] = nextLevel.ToString();
                        if (currentLevel == 1)
                        {
                           
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confimapprove();</script>", false);
                            modelBody.Visible = true;
                            modelHeader.Visible = true;

                        }
                        else 
                        {
                           

                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confimapprove();</script>", false);
                            modelBody.Visible = true;
                            modelHeader.Visible = true;
                        }

                    }


                }
                catch (Exception ex)
                {
                    String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                    obj.LogMessageToFile(UICommon.GetLogFileName(), "ListLeaveReq.aspx", "Error : " + ex.Message.ToString() + " - " + innerMessage);
                }

            }

        }

       



        public void SetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        string filterValue = column.CurrentFilterValue;

                        Session[SessionPrefix + columnName] = filterValue;

                    }

                }

            }

            catch (Exception ex)

            {




            }



        }

        //protected void lnkAdd_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("AddLeaveRequest.aspx?Id=0");
        //}

        protected void Approve_Click(object sender, EventArgs e)
        {
            //int addCount = Int32.Parse(grvRpt.SelectedItems.Count.ToString());
            //if (addCount == 0)
            //{
            //    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>failedModals();</script>", false);
            //}
            //else
            //{

                DataTable lstApprovalLevel = obj.loadList("Selectleavereqapprovals", "sp_Masters", UICommon.GetCurrentUserID().ToString());
                if (lstApprovalLevel.Rows.Count > 0)
                {
                    int currentLevel, nextLevel;
                    currentLevel = Int32.Parse(lstApprovalLevel.Rows[0]["CurrentLevel"].ToString());
                    nextLevel = Int32.Parse(lstApprovalLevel.Rows[0]["NextLevel"].ToString());
                    ViewState["currentLevel"] = currentLevel.ToString();
                    ViewState["nextLevel"] = nextLevel.ToString();
                    if (currentLevel == 1)
                    {
                        
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim('You are the final approver,Do you want to continue?');</script>", false);
                    }
                    else if (nextLevel > 0)
                    {
                         
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim('The Approval request will go to the next level user, Do you want to continue?');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>failedModal();</script>", false);

                    }
                }

           // }
        }

        protected void save_Click(object sender, EventArgs e)
        {
           

            string user = UICommon.GetCurrentUserID().ToString();

            string Req = Session["ID"].ToString();

           string  Remark = txtRemarks.InnerText.ToString();
            string LevType = ddlLeaveType.SelectedValue.ToString();

            string current = ViewState["currentLevel"].ToString();
            string[] arr = { user, current, LevType, Remark };
            string Value = obj.SaveData("sp_Masters", "ApproveLeaveRequest", Req, arr);
            int res = Int32.Parse(Value.ToString());
            if (res > 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>successModal('Approved Successfully');</script>", false);
            }

            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>failedModal();</script>", false);
            }
        }




        public string GetItemFromGrid()
        {
            using (var sw = new StringWriter())
            {
                using (var writer = XmlWriter.Create(sw))
                {
                    writer.WriteStartDocument(true);
                    writer.WriteStartElement("r");
                    int c = 0;

                    var ColelctionMarkets = grvRpt.SelectedItems;
                    string cusIDs = "";
                    int i = 0;
                    int MarCount = ColelctionMarkets.Count;
                    if (ColelctionMarkets.Count > 0)
                    {
                        foreach (GridDataItem dr in ColelctionMarkets)
                        {
                            //where 1 = 1
                            string lvr_ID = dr.GetDataKeyValue("lvr_ID").ToString();

                            createNode(lvr_ID, writer);
                            c++;

                        }
                    }

                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                    writer.Close();
                    if (c == 0)
                    {
                        return "";
                    }
                    else
                    {
                        string ss = sw.ToString();
                        return sw.ToString();
                    }
                }
            }
        }

        private void createNode(string lvr_ID, XmlWriter writer)
        {
            writer.WriteStartElement("Values");

            writer.WriteStartElement("lvr_ID");
            writer.WriteString(lvr_ID);
            writer.WriteEndElement();



            writer.WriteEndElement();
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListLeaveReq.aspx");

        }

        protected void lnkReject_Click(object sender, EventArgs e)
        {
           
           
           
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Reject();</script>", false);

            
        }

        protected void btnRejectSave_Click(object sender, EventArgs e)
        {
            string user = UICommon.GetCurrentUserID().ToString();

            string Req = Session["ID"].ToString();


            string[] arr = { user };
            string Value = obj.SaveData("sp_Masters", "RejectLeaveRequest", Req, arr);
            int res = Int32.Parse(Value.ToString());
            if (res > 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>successModal('Rejected Successfully');</script>", false);
            }

            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>failedModal();</script>", false);
            }
        }

        protected void XlDownload_Click(object sender, ImageClickEventArgs e)
        {
            string userID = UICommon.GetCurrentUserID().ToString();
            DataTable dt = default(DataTable);
            dt = obj.loadList("ListLeaveRequestforXl", "sp_Masters", userID);

            BuildExcel excel = new BuildExcel();

            byte[] output = excel.SpreadSheetProcess(dt, "LeaveRequest");

            Response.ContentType = ContentType;

            Response.Headers.Remove("Content-Disposition");

            Response.AppendHeader("Content-Disposition", string.Format("attachment; filename={0}.{1}", "LeaveRequest", "Xlsx"));

            Response.BinaryWrite(output);

            Response.End();
        }

        public void GetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                string filterExpression = string.Empty;

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        if (Session[SessionPrefix + columnName] != null)

                        {

                            string filterValue = Session[SessionPrefix + columnName].ToString();



                            if (filterValue != "")
                            {

                                column.CurrentFilterValue = filterValue;



                                if (!string.IsNullOrEmpty(filterExpression))

                                {

                                    filterExpression += " AND ";

                                }

                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);

                            }

                        }

                    }

                }

                if (filterExpression != string.Empty)

                {

                    grvRpt.MasterTableView.FilterExpression = filterExpression;

                }



            }

            catch (Exception ex)

            {



            }

        }

        protected void grvRpt_ItemDataBound(object sender, GridItemEventArgs e)
        {
            //if (e.Item is GridDataItem)
            //{

            //    GridDataItem item = (GridDataItem)e.Item;

            //    // Find the DropDownList within the current grid item
            //    string leaveType = item["atd_Status"].Text.ToString();
            //    DropDownList ddlLeaveType = (DropDownList)item.FindControl("ddlLeaveType");


            //    if (leaveType != null)
            //    {
            //        // Get the value bound to the data field "atd_Status" for the current grid item


            //        // Find the corresponding ListItem in the DropDownList and set it as selected
            //        ddlLeaveType.SelectedValue = leaveType;
            //    }
            //}
        }
    }
}