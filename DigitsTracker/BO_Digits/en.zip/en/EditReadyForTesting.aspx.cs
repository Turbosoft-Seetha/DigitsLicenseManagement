﻿using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace DigitsTracker.BO_Digits.en
{
    public partial class EditReadyForTesting : System.Web.UI.Page
    {
        GeneralFunctions obj = new GeneralFunctions();
        public int ResponseID
        {
            get
            {
                int ResponseID;
                int.TryParse(Request.Params["ID"], out ResponseID);

                return ResponseID;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Status();
            }
        }

        protected void lnkAdd_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);

        }


        public void Status()
        {
            try
            {
                string  User = UICommon.GetCurrentUserID().ToString();
                ddlStatus.DataSource = obj.loadList("SelStatusForDropdown", "sp_Transactions", User);
                ddlStatus.DataTextField = "sts_Name";
                ddlStatus.DataValueField = "sts_Code";
                ddlStatus.DataBind();
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                obj.LogMessageToFile(UICommon.GetLogFileName(), "EditReadyForTesting.aspx Status()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }
        protected void Save()
        {
            try
            {
                string Status, user;

               
                user = UICommon.GetCurrentUserID().ToString();
                Status = ddlStatus.SelectedValue.ToString();
                string id = ResponseID.ToString();
                string[] arr = { Status.ToString() };
                string Value = obj.SaveData("sp_Transactions", "UpdateStatus", id.ToString(), arr);
                int res = Int32.Parse(Value.ToString());
                if (res > 0)

                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Status Updated Successfully');</script>", false);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                }
            }

           
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                obj.LogMessageToFile(UICommon.GetLogFileName(), "AddEditStatus.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }


        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("ReadyForTesting.aspx");
        }

        protected void save_Click(object sender, EventArgs e)
        {
            Save();
        }

        protected void lnkCancel_Click(object sender, EventArgs e)
        {

        }
    }
}