﻿//using DocumentFormat.OpenXml.Wordprocessing;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using Telerik.Web.UI;
using Telerik.Web.UI.Skins;
using Telerik.Windows.Documents.Spreadsheet.Expressions.Functions;

namespace DigitsTracker.BO_Digits.en
{
    public partial class AttendanceForm : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //rdfromDate.MinDate = DateTime.Now.AddDays(-2);
                rdfromDate.SelectedDate = DateTime.Now;
                rdfromDate.MaxDate = DateTime.Now;
                // Session["AttDate"] = "";
                ViewState["ID"] = "";


              
            }


        }

        protected void rdfromDate_SelectedDateChanged(object sender, Telerik.Web.UI.Calendar.SelectedDateChangedEventArgs e)
        {

           
            ListData();
            grvRpt.Rebind();
            //Session["AttDate"] = rdfromDate.SelectedDate.ToString();
        }


       

        public void ListData()
        {
           
           
            DataTable lstUser = default(DataTable);
            string Date = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
            lstUser = ObjclsFrms.loadList("SelectEmpAttendance", "sp_Attendance", Date);
            string Today = DateTime.Parse(DateTime.Now.ToString()).ToString("yyyyMMdd");
            grvRpt.DataSource = lstUser;
            if (lstUser.Rows.Count > 0)
            {   
                string IsSave = lstUser.Rows[0]["savemode"].ToString();
                if (Date == Today)
                {
                    lnkSave.Visible = true;
                }
                else if (IsSave == "N")
                {
                    lnkSave.Visible = false;
                    radSelectAllPresent.Visible = false;
                  
                    // item["Remarks"].Visible = true;
                }
                else
                {
                    lnkSave.Visible = true;
                    radSelectAllPresent.Visible = true;
                    //item["Remarks"].Visible = false;
                }
                
            }

        }
        protected void lnkSave_Click(object sender, EventArgs e)
        {
           
            int checkedcount = GetCheckedRadioCount();
            if (checkedcount == grvRpt.Items.Count)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);

            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'> Failure();</script>", false);


            }
        }



        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            ListData();
        }

        protected void grvRpt_ItemDataBound(object sender, Telerik.Web.UI.GridItemEventArgs e)
        {

            DataTable lstUser = default(DataTable);
            string Date = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
            lstUser = ObjclsFrms.loadList("SelectEmpAttendance", "sp_Attendance", Date);
            string Today = DateTime.Parse(DateTime.Now.ToString()).ToString("yyyyMMdd");
            grvRpt.DataSource = lstUser;
            if (lstUser.Rows.Count > 0)
            {
                string IsSave = lstUser.Rows[0]["savemode"].ToString();
                if (Date == Today)
                {
                    lnkSave.Visible = true;
                }
                else if (IsSave == "N")
                {

                    foreach (GridDataItem item in grvRpt.Items)
                    {

                        RadioButton radPresent = (RadioButton)item.FindControl("radPresent");
                        RadioButton radHD = (RadioButton)item.FindControl("radHD");
                        RadioButton radPL = (RadioButton)item.FindControl("radPL");
                        RadioButton radUL = (RadioButton)item.FindControl("radUL");
                        RadioButton radAL = (RadioButton)item.FindControl("radAL");
                        RadioButton radPH = (RadioButton)item.FindControl("radPH");

                        // Disable each radio button
                        radPresent.Enabled = false;
                        radHD.Enabled = false;
                        radPL.Enabled = false;
                        radUL.Enabled = false;
                        radAL.Enabled = false;
                        radPH.Enabled = false;

                        radPresent.CssClass = "disabled-radio";
                        radHD.CssClass = "disabled-radio";
                        radPL.CssClass = "disabled-radio";
                        radUL.CssClass = "disabled-radio";
                        radAL.CssClass = "disabled-radio";
                        radPH.CssClass = "disabled-radio";
                    }

                    // item["Remarks"].Visible = true;
                }
                else
                {
                   
                }

            }


            if (e.Item is GridDataItem)
            {

                GridDataItem item = (GridDataItem)e.Item;
                RadioButton radbtnP = (RadioButton)item.FindControl("radPresent");
                RadioButton radHD = (RadioButton)item.FindControl("radHD");
                RadioButton radPL = (RadioButton)item.FindControl("radPL");
                RadioButton radUL = (RadioButton)item.FindControl("radUL");
                RadioButton radAL = (RadioButton)item.FindControl("radAL");
                RadioButton radPH = (RadioButton)item.FindControl("radPH");
                RadTextBox txtRemarks = (RadTextBox)item.FindControl("txtRemarks");

                if ((item["Flag"].Text.Equals("1")))
                {
                    item.BackColor = System.Drawing.Color.AntiqueWhite;
                    item.Enabled = false;
                    
                    // grvRpt.ClientSettings.ClientEvents.OnRowClick = "OnRowClick";

                }
                else
                {
                    // grvRpt.ClientSettings.ClientEvents.OnRowClick = string.Empty; // Set to an empty string to remove the event

                }

                if ((item["Status"].Text.Equals("P")))
                {
                    radbtnP.Checked = true;
                }
                else if ((item["Status"].Text.Equals("AL")))
                {
                    radAL.Checked = true;

                }
                else if ((item["Status"].Text.Equals("HD")))
                {
                    radHD.Checked = true;

                }
                else if ((item["Status"].Text.Equals("PL")))
                {
                    radPL.Checked = true;

                }
                else if ((item["Status"].Text.Equals("UL")))
                {
                    radUL.Checked = true;

                }
                else if ((item["Status"].Text.Equals("PH")))
                {
                    radPH.Checked = true;

                }
                else
                {
                    radbtnP.Checked = false;
                    radAL.Checked = false;
                    radHD.Checked = false;
                    radPL.Checked = false;
                    radUL.Checked = false;
                    radPH.Checked = false;
                }
                if (txtRemarks != null)
                {
                    // Assuming 'YourDataTable' is your data source
                    DataRowView row = (DataRowView)item.DataItem;

                    // Assuming 'Remarks' is the column name in your DataTable
                    string remarksValue = row["Remarks"].ToString();

                    // Bind the database value to the RadTextBox
                    txtRemarks.Text = remarksValue;
                }

            }

        }
        public string GetItemFromGrid()
        {
            using (var sw = new StringWriter())
            {
                using (var writer = XmlWriter.Create(sw))
                {

                    writer.WriteStartDocument(true);
                    writer.WriteStartElement("r");
                    int c = 0;
                    int p = grvRpt.PageCount;


                    foreach (GridDataItem item in grvRpt.Items)
                    {

                        RadioButton radbtnP = (RadioButton)item.FindControl("radPresent");
                        RadioButton radHD = (RadioButton)item.FindControl("radHD");
                        RadioButton radPL = (RadioButton)item.FindControl("radPL");
                        RadioButton radUL = (RadioButton)item.FindControl("radUL");
                        RadioButton radAL = (RadioButton)item.FindControl("radAL");
                        RadioButton radPH = (RadioButton)item.FindControl("radPH");
                        RadTextBox Remark = (RadTextBox)item.FindControl("txtRemarks");
                       
                        string Remarks = Remark.Text.ToString();
                        string Status = "";
                        if (radbtnP.Checked == true)
                        {
                            Status = "P";
                        }
                        if (radHD.Checked == true)
                        {
                            Status = "HD";
                        }
                        if (radPL.Checked == true)
                        {
                            Status = "PL";
                        }
                        if (radUL.Checked == true)
                        {
                            Status = "UL";
                        }
                        if (radAL.Checked == true)
                        {
                            Status = "AL";
                        }
                        if (radPH.Checked == true)
                        {
                            Status = "PH";
                        }

                        string ID = item.GetDataKeyValue("ID").ToString();
                        

                        createNode(ID, Status, Remarks, writer);


                        c++;


                    }
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                    writer.Close();
                    if (c == 0)
                    {
                        return "";
                    }
                    else
                    {
                        string ss = sw.ToString();
                        return sw.ToString();
                    }
                }
            }
        }

        private void createNode(string ID, string Status,string Remarks, XmlWriter writer)
        {
            writer.WriteStartElement("Values");
            writer.WriteStartElement("ID");
            writer.WriteString(ID);
            writer.WriteEndElement();

            writer.WriteStartElement("Status");
            writer.WriteString(Status);
            writer.WriteEndElement();

            writer.WriteStartElement("Remarks");
            writer.WriteString(Remarks);
            writer.WriteEndElement();

            writer.WriteEndElement();
        }

        private int GetCheckedRadioCount()
        {
            int checkedRadioCount = 0;

            foreach (GridItem item in grvRpt.Items)
            {
                if (item is GridDataItem)
                {
                    GridDataItem dataItem = (GridDataItem)item;

                    // Assuming the radio buttons are in the first column of the grid
                    RadioButton radPresent = dataItem.FindControl("radPresent") as RadioButton;
                    RadioButton radHD = dataItem.FindControl("radHD") as RadioButton;
                    RadioButton radPL = dataItem.FindControl("radPL") as RadioButton;
                    RadioButton radUL = dataItem.FindControl("radUL") as RadioButton;
                    RadioButton radAL = dataItem.FindControl("radAL") as RadioButton;
                    RadioButton radPH = dataItem.FindControl("radPH") as RadioButton;


                    if (radPresent.Checked || radHD.Checked || radPL.Checked || radUL.Checked || radAL.Checked || radPH.Checked)
                    {
                        checkedRadioCount++;
                    }
                }
            }

            return checkedRadioCount;
        }
        private int GetPresentCheckedRadioCount()
        {
            int checkedRadioCount = 0;

            foreach (GridItem item in grvRpt.Items)
            {
                if (item is GridDataItem)
                {
                    GridDataItem dataItem = (GridDataItem)item;

                    // Assuming the radio buttons are in the first column of the grid
                    RadioButton radPresent = dataItem.FindControl("radPresent") as RadioButton;


                    if (radPresent.Checked)
                    {
                        checkedRadioCount++;
                    }
                }
            }

            return checkedRadioCount;
        }
        public void Save()
        {
            

            string date = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
            string Today= DateTime.Parse(DateTime.Now.ToString()).ToString("yyyyMMdd");

            string user = UICommon.GetCurrentUserID().ToString();
            string Attendance = GetItemFromGrid();
            string[] ar = { date, user };

            if (date==Today)
            {
                DataTable lstUser = default(DataTable);
                lstUser = ObjclsFrms.loadList("SelectEmpAttendance", "sp_Attendance", date);
                grvRpt.DataSource = lstUser;
                if (lstUser.Rows.Count > 0)
                {
                    string IsSave = lstUser.Rows[0]["savemode"].ToString();
                    
                    if (IsSave == "N")
                    {
                        lstUser = ObjclsFrms.loadList("DeleteAttenance", "sp_Attendance",date);
                        string Value = ObjclsFrms.SaveData("sp_Attendance", "InsertDailyAttendance", Attendance, ar);
                        int res = Int32.Parse(Value.ToString());
                        if (res > 0)
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Attendance Registered Successfully');</script>", false);
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                        }

                    }
                    else
                    {
                        string Value = ObjclsFrms.SaveData("sp_Attendance", "InsertDailyAttendance", Attendance, ar);
                        int res = Int32.Parse(Value.ToString());
                        if (res > 0)
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Attendance Registered Successfully');</script>", false);
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                        }

                    }
                    


                }
                else
                {
                    string Value = ObjclsFrms.SaveData("sp_Attendance", "InsertDailyAttendance", Attendance, ar);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Attendance Registered Successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }

                }

            }
            else
            {
                string Value = ObjclsFrms.SaveData("sp_Attendance", "InsertDailyAttendance", Attendance, ar);
                int res = Int32.Parse(Value.ToString());
                if (res > 0)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Attendance Registered Successfully');</script>", false);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                }
            }
            



        }

        protected void save_Click(object sender, EventArgs e)
        {
            Save();
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("AttendanceForm.aspx");
        }

        protected void grvRpt_ItemCommand(object sender, GridCommandEventArgs e)
        {
            


        }

        protected void lnksavechange_Click(object sender, EventArgs e)
        {
            string targetID = ViewState["ID"].ToString();
            string name = "";
            // Loop through each item in the grid to find the target item
            foreach (GridDataItem item in grvRpt.MasterTableView.Items)
            {
                // Access the unique identifier from a specific column, e.g., "ID"
                string itemID = item.GetDataKeyValue("ID").ToString();
                 name = item["UserName"].Text.ToString(); 
                if (itemID == targetID)
                {
                    // Enable the controls within the target item
                    item.Enabled = true;
                  

                    // Perform any additional actions if needed
                    break; // Exit the loop once the target item is found
                }
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>editsuccess('Edit enabled for Employee : " + name+"..');</script>", false);

        }

        protected void radSelectAllPresent_CheckedChanged(object sender, EventArgs e)
        {
            if (radSelectAllPresent.Checked)
            {
                foreach (GridDataItem item in grvRpt.Items)
                {
                    RadioButton radPresent = (RadioButton)item.FindControl("radPresent");
                    RadioButton radHD = (RadioButton)item.FindControl("radHD") as RadioButton;
                    RadioButton radPL = (RadioButton)item.FindControl("radPL") as RadioButton;
                    RadioButton radUL = (RadioButton)item.FindControl("radUL") as RadioButton;
                    RadioButton radAL = (RadioButton)item.FindControl("radAL") as RadioButton;
                    RadioButton radPH = (RadioButton)item.FindControl("radPH") as RadioButton;
                    radPresent.Checked = true;
                    radHD.Checked = false;
                    radPL.Checked = false;
                    radUL.Checked = false;
                    radAL.Checked = false;
                    radPH.Checked = false;

                }
            }
        }

        protected void radHD_CheckedChanged(object sender, EventArgs e)
        {
            radSelectAllPresent.Checked= false;
        }

        protected void radPL_CheckedChanged(object sender, EventArgs e)
        {
            radSelectAllPresent.Checked = false;
        }

        protected void radUL_CheckedChanged(object sender, EventArgs e)
        {
            radSelectAllPresent.Checked = false;
        }

        protected void radAL_CheckedChanged(object sender, EventArgs e)
        {
            radSelectAllPresent.Checked = false;
        }

        protected void radPH_CheckedChanged(object sender, EventArgs e)
        {
            radSelectAllPresent.Checked = false;
        }

        protected void radPresent_CheckedChanged(object sender, EventArgs e)
        {
            int checkedcount = GetPresentCheckedRadioCount();
            if (checkedcount == grvRpt.Items.Count)
            {
                radSelectAllPresent.Checked = true;
            }
        }
    }
}