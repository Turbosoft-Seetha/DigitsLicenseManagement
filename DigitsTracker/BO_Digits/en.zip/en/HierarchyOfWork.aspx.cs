﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using System.IO;
using System.Drawing;
using ProcessExcel;
using Telerik.Windows.Documents.Spreadsheet.Expressions.Functions;

namespace DigitsTracker.BO_Digits.en
{
    public partial class HierarchyOfWork : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " ------------------------- Starts pageload------------");
                rdfromDate.SelectedDate = DateTime.Now;
                rdtoDate.SelectedDate = DateTime.Now;
                if (Session["ID"] == null)
                {
                    Session["ID"] = "";
                    Session["ProjectID"] = "";
                    Session["PlatformID"] = "";

                }


                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "session ", "Error : " + " 1 ");

                Resourses();




                try
                {
                    if (Session["HWFDate"] != null)
                    {

                        rdfromDate.SelectedDate = DateTime.Parse(Session["HWFDate"].ToString());
                    }
                    else
                    {
                        rdfromDate.SelectedDate = DateTime.Now;


                    }
                    rdfromDate.MaxDate = DateTime.Now;

                    if (Session["HWTDate"] != null)
                    {

                        rdtoDate.SelectedDate = DateTime.Parse(Session["HWTDate"].ToString());
                    }
                    else
                    {
                        rdtoDate.SelectedDate = DateTime.Now;

                    }
                    rdtoDate.MaxDate = DateTime.Now;
                }
                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }


                try
                {
                    if (Session["HWRid"] != null)
                    {
                        int a = rdResourse.Items.Count;
                        string res = Session["HWRid"].ToString();
                        string[] ar = res.Split(',');
                        for (int i = 0; i < ar.Length; i++)
                        {
                            foreach (RadComboBoxItem items in rdResourse.Items)
                            {
                                if (items.Value == ar[i])
                                {
                                    items.Checked = true;
                                }
                            }
                        }


                    }
                    else
                    {
                        string res = Res();
                        string routeCondition = " trk_AssignedEmp_ID in (" + res + ")";



                    }

                    //invType

                }
                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }
                try
                {
                    GetGridSession(grvRpt, "HW");

                    grvRpt.Rebind();
                }

                catch (Exception ex)
                {
                    Response.Redirect("~/Login.aspx");
                }

            }



            
        }
      
        
        public void ListData()
        {
            try
            {
                string User;
                User = UICommon.GetCurrentUserID().ToString();
                string fromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
                string toDate = DateTime.Parse(rdtoDate.SelectedDate.ToString()).ToString("yyyyMMdd");

                string mainCondition = "";
                mainCondition = mainConditions();
                string[] arr = { mainCondition.ToString(),fromDate,toDate };
                DataTable lstUser = default(DataTable);

                lstUser = ObjclsFrms.loadList("SelectWorkHierarchy", "sp_Transactions", User, arr);
                grvRpt.DataSource = lstUser;
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "HierarchyOfWork.aspx ListData()", "Error : " + ex.Message.ToString() + " - " + innerMessage);
            }

        }



        protected void grvRpt_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            ListData();
        }

        protected void grvRpt_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {

            try
            {
                RadGrid grd = (RadGrid)sender;

                SetGridSession(grd, "HW");
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");
            }
        }
       
        public void Resourses()
        {
            string User;
            User = UICommon.GetCurrentUserID().ToString();

            rdResourse.DataSource = ObjclsFrms.loadList("SelectResourseforWorkMonitor", "sp_Transactions", User);
            rdResourse.DataTextField = "FirstName";
            rdResourse.DataValueField = "ID";
            rdResourse.DataBind();
        }


        public string mainConditions()
        {
            string User;
            User = UICommon.GetCurrentUserID().ToString();
            string Resourse = Res();
            string mainCondition = "";
            string ResourseCondition = "";
            
            
            try
            {


                if (Resourse.Equals("0"))
                {
                    ResourseCondition = "";
                }
                else
                {
                    ResourseCondition =  "(" + Resourse + ")";
                }

            }
            catch (Exception ex)
            {

            }
            mainCondition += ResourseCondition;
            return mainCondition;
        }

        public string Res()
        {
            string User;
            User = UICommon.GetCurrentUserID().ToString();
            var CollectionMarket = rdResourse.CheckedItems;
            string ResID = " ";
            int j = 0;
            int MarCount = CollectionMarket.Count;
            if (CollectionMarket.Count > 0)
            {
                foreach (var item in CollectionMarket)
                {
                    if (j == 0)
                    {
                        ResID += item.Value + ",";
                    }
                    else if (j > 0)
                    {
                        ResID += item.Value + ",";
                    }
                    if (j == (MarCount - 1))
                    {
                        ResID += item.Value;
                    }
                    j++;
                }
                return ResID;
            }
            else
            {
                return "trk_AssignedEmp_ID" ;
            }

        }

        protected void lnkFilter_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["HWFDate"] != null)
                {
                    string fromdate = rdfromDate.SelectedDate.ToString();
                    if (fromdate == Session["HWFDate"].ToString())
                    {
                        rdfromDate.SelectedDate = DateTime.Parse(Session["HWFDate"].ToString());
                    }
                    else
                    {
                        Session["HWFDate"] = DateTime.Parse(rdfromDate.SelectedDate.ToString());
                    }
                }
                else
                {
                    rdfromDate.SelectedDate = DateTime.Parse(rdfromDate.SelectedDate.ToString());
                    Session["HWFDate"] = DateTime.Parse(rdfromDate.SelectedDate.ToString());

                }
                rdfromDate.MaxDate = DateTime.Now;

                if (Session["HWTDate"] != null)
                {
                    string todate = rdtoDate.SelectedDate.ToString();
                    if (todate == Session["HWTDate"].ToString())
                    {
                        rdtoDate.SelectedDate = DateTime.Parse(Session["HWTDate"].ToString());
                    }
                    else
                    {
                        Session["HWTDate"] = DateTime.Parse(rdtoDate.SelectedDate.ToString());
                    }

                }
                else
                {
                    rdtoDate.SelectedDate = DateTime.Parse(rdtoDate.SelectedDate.ToString());
                    Session["HWTDate"] = DateTime.Parse(rdtoDate.SelectedDate.ToString());
                }
                rdtoDate.MaxDate = DateTime.Now.AddDays(1);


                if (Session["HWRid"] != null)
                {
                    string resourse = Res();
                    if (resourse == Session["HWRid"].ToString())
                    {
                        string res = Res();

                    }
                    else
                    {
                        string res = Res();
                        Session["HWRid"] = res;
                    }


                }
                else
                {
                    string res = Res();
                    Session["HWRid"] = res;
                }



            }
            catch (Exception ex)
            {
                Response.Redirect("~/Login.aspx");

            }

            ListData();
            grvRpt.Rebind();
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            string User;
            User = UICommon.GetCurrentUserID().ToString();
            string fromDate = DateTime.Parse(rdfromDate.SelectedDate.ToString()).ToString("yyyyMMdd");
            string toDate = DateTime.Parse(rdtoDate.SelectedDate.ToString()).ToString("yyyyMMdd");

            string mainCondition = "";
            mainCondition = mainConditions();
            string[] arr = { mainCondition.ToString(), fromDate, toDate };

            DataTable dt = default(DataTable);
            dt = ObjclsFrms.loadList("SelectWorkHierarchyForXl", "sp_Transactions", User, arr);

            BuildExcel excel = new BuildExcel();

            byte[] output = excel.SpreadSheetProcess(dt, "ReadyForTesting");

            Response.ContentType = ContentType;

            Response.Headers.Remove("Content-Disposition");

            Response.AppendHeader("Content-Disposition", string.Format("attachment; filename={0}.{1}", "ReadyForTesting", "Xlsx"));

            Response.BinaryWrite(output);

            Response.End();
        }

        protected void rdtoDate_SelectedDateChanged(object sender, Telerik.Web.UI.Calendar.SelectedDateChangedEventArgs e)
        {

        }

        protected void rdfromDate_SelectedDateChanged(object sender, Telerik.Web.UI.Calendar.SelectedDateChangedEventArgs e)
        {

        }


        public void SetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        string filterValue = column.CurrentFilterValue;

                        Session[SessionPrefix + columnName] = filterValue;

                    }

                }

            }

            catch (Exception ex)

            {




            }



        }
        public void GetGridSession(RadGrid grd, string SessionPrefix)

        {

            try

            {

                string filterExpression = string.Empty;

                foreach (GridColumn column in grd.MasterTableView.Columns)

                {

                    if (column is GridBoundColumn boundColumn)

                    {

                        string columnName = boundColumn.UniqueName;

                        if (Session[SessionPrefix + columnName] != null)

                        {

                            string filterValue = Session[SessionPrefix + columnName].ToString();



                            if (filterValue != "")
                            {

                                column.CurrentFilterValue = filterValue;



                                if (!string.IsNullOrEmpty(filterExpression))

                                {

                                    filterExpression += " AND ";

                                }

                                filterExpression += string.Format("{0} LIKE '%{1}%'", column.UniqueName, column.CurrentFilterValue);

                            }

                        }

                    }

                }

                if (filterExpression != string.Empty)

                {

                    grvRpt.MasterTableView.FilterExpression = filterExpression;

                }



            }

            catch (Exception ex)

            {



            }

        }
    }
}