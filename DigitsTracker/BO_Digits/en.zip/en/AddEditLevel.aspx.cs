﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Metadata.Edm;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using Telerik.Web.UI;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace DigitsTracker.BO_Digits.en
{
    public partial class AddEditLevel : System.Web.UI.Page
    {
        GeneralFunctions ObjclsFrms = new GeneralFunctions();
        public int ResponseID
        {
            get
            {
                int ResponseID;
                int.TryParse(Request.Params["ID"], out ResponseID);

                return ResponseID;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
              
                FillForm();
            }
        }
        public void FillForm()
        {
            try
            {
                DataTable lstDatas = ObjclsFrms.loadList("SelectLevelByID", "sp_Masters", ResponseID.ToString());
                if (lstDatas.Rows.Count > 0)
                {
                    string level, status,desc;
                    level = lstDatas.Rows[0]["lvl_Level"].ToString();
                    status = lstDatas.Rows[0]["Status"].ToString();
                    desc= lstDatas.Rows[0]["lvl_Desc"].ToString();
                    txtLevel.Text = level.ToString();
                    ddlStatus.SelectedValue = status.ToString();
                    txtDesc.Text = desc.ToString();




                }
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditLevel.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }

        }
        protected void Save()
        {
            try
            {



                string level, status,user,desc;
                level = txtLevel.Text.ToString();
                user = UICommon.GetCurrentUserID().ToString();
                status = ddlStatus.SelectedValue.ToString();
               desc= txtDesc.Text.ToString();

                if (ResponseID.Equals("") || ResponseID == 0)
                {


                    string[] arr = {  status.ToString(), user.ToString() ,desc.ToString()};
                    string Value = ObjclsFrms.SaveData("sp_Masters", "InsertLevel", level.ToString(), arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Level has been saved successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }
                }

                else
                {
                    string id = ResponseID.ToString();
                    string[] arr = { level.ToString(), status.ToString(), user.ToString(), desc.ToString() };
                    string Value = ObjclsFrms.SaveData("sp_Masters", "UpdateLevel", id.ToString(), arr);
                    int res = Int32.Parse(Value.ToString());
                    if (res > 0)

                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Succcess('Level Updated Successfully');</script>", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Failure();</script>", false);
                    }
                }
            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditLevel.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }




       
        protected void save_Click(object sender, EventArgs e)
        {
            Save();
        }

        protected void btnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListLevel.aspx");
        }

        protected void lnkAdd_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "tmp", "<script type='text/javascript'>Confim();</script>", false);
        }

        protected void lnkCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListLevel.aspx");
        }

        protected void txtLevel_TextChanged(object sender, EventArgs e)
        {
            try
            {

                string code = this.txtLevel.Text.ToString();
                DataTable lstCodeChecker = ObjclsFrms.loadList("CheckLevel", "sp_Masters", code);
                if (lstCodeChecker.Rows.Count > 0)
                {
                    lblLevelDupli.Text = "Level Already Exist";
                    lnkAdd.Enabled = false;
                    lblLevelDupli.Visible = true;
                }
                else
                {
                    lnkAdd.Enabled = true;
                    lblLevelDupli.Visible = false;
                }

            }
            catch (Exception ex)
            {
                String innerMessage = (ex.InnerException != null) ? ex.InnerException.Message : "";
                ObjclsFrms.LogMessageToFile(UICommon.GetLogFileName(), "AddEditLevel.aspx ", "Error : " + ex.Message.ToString() + " - " + innerMessage);

            }
        }
    }
}